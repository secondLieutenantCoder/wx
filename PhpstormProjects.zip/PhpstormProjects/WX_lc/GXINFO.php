<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/5/22
 * Time: 09:29
 */


require "./lib/BmobObject.class.php";

// 1.取bmob数据
$bmobObj = new BmobObject("ProxyOBDMaster ");
//  $timestamp = time()+7000;
//  $objID = 'a0c44d19d4';
//  $openid = $resObj-> openid;

/*
$studentID = "o7XC90jGgVsu2ra0omYf2UY900Yo";
$queryStr = "where={\"coach_id\":\"{$studentID}\"}";
$res=$bmobObj->get("",array("$queryStr"));
$res1 = $res->results;
*/


/*
$GX_res = $bmobObj->get("Ktq95556");

// 总课时 proxy_name
// 总收益  coach_id
//var_dump($res);
$GX_time = $GX_res->proxy_name;

$GX_money = $GX_res->coach_id;

$GX_newtime = $GX_time + 1;
$GX_newmoney = $GX_money+ 10;

$bmobObj->update("Ktq95556",array("proxy_name"=>"$GX_newtime","coach_id"=>"$GX_newmoney"));
*/


?>



<!
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>共享考车详情</title>
</head>
<body>



</body>
</html>
