<?php


require "../lib/BmobObject.class.php";

// 1.取bmob数据
$bmobObj = new BmobObject("ProxyPayrecord");
//  $timestamp = time()+7000;
//  $objID = 'a0c44d19d4';
//  $openid = $resObj-> openid;
//$openID = $_GET['openID'];

$openID = "o7XC90jGgVsu2ra0omYf2UY900Yo";
$queryStr = "where={\"studentID\":\"{$openID}\"}";
$res=$bmobObj->get("",array("$queryStr"));
$res1 = $res->results;


// 含有中文的 数组转 json
//  一个好用的函数，对数组中的中文内容进行 urlencode 编码 数组转成json之后，再将其中的中文内容转码回来。
function ch_json_encode($data) {
    function ch_urlencode($data) {
        if (is_array ( $data ) || is_object ( $data )) {
            foreach ( $data as $k => $v ) {
                if (is_scalar ( $v )) {
                    if (is_array ( $data )) {
                        $data [$k] = urlencode ( $v );
                    } else if (is_object ( $data )) {
                        $data->$k = urlencode ( $v );
                    }
                } else if (is_array ( $data )) {
                    $data [$k] = ch_urlencode( $v ); // 递归调用该函数
                } else if (is_object ( $data )) {
                    $data->$k = ch_urlencode( $v );
                }
            }
        }
        return $data;
    }
    $ret = ch_urlencode( $data );
    $ret = json_encode ( $ret );
    return urldecode ( $ret );
} // 数组  转 json end
$phpJson1 = array_reverse($res1);
$phpJson = ch_json_encode($phpJson1); // 调用函数，获取到 json


//echo $phpJson;

?>
<!doctype html>

<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script type="text/javascript" src="a_js.js"></script>

    <!--    // 引入jQuery-->
    <script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
    <!--    <link rel="stylesheet" type="text/css" href="../phpTest/css/style.css" media="screen"/>-->
    <!--    <script src="../phpTest/jquery.paginate.js" type="text/javascript"></script>-->

    <link rel="stylesheet" type="text/css" href="./3rd/style.css" />
    <script type="text/javascript" src="./3rd/jquery.paginate.js"></script>
    <!--    CSS-->
    <style>

        #orderContainer{
            margin-left: 0;
            margin-right: 0;
            width: 100%;
            background: white;
            font-size: 12px;
        }

        .listID{
            text-align: center;
            width:3%;
            background: lightcyan;
            height: 40px;
            margin-top: 10px;
        }
        .listKind{
            background: ghostwhite;
            width: 8%;
            color: black;
            text-align: center;
            white-space: nowrap;
            /*border-radius: 3px;*/
        }
        .listState{
            background: whitesmoke;
            width:10%;
            text-align: center;
            /*border-radius: 8px;*/
        }
        .listProductNum{
            background: whitesmoke;
            width: 10%;
            /*border-radius: 8px;*/
            /*text-align: center;*/
            text-align: center;
            white-space: nowrap;  /* 字体自适应宽度，不换行*/
        }
        .listSaleman{
            text-align: center;
            background: ghostwhite;

        }

        .listCustomer{
            text-align: center;
            background: ghostwhite;
        }

        .listSpecification{
            text-align: center;
            background: ghostwhite;
        }
        .listExpectedTime{
            background: ghostwhite;
            white-space: nowrap;     /*字体自适应宽度，不换行*/
            width:10%;
            text-align: center;
        }

        /*设置标题*/
        .title{
            text-align: center;
            white-space: nowrap;
            background: lightseagreen;
            font-size: 13px;
            /*height: 45px;*/
        }
        #header{

            background: lightseagreen;
            height: 38px;
            padding-top: 10px;
            font-size: 18px;
            border-radius: 10px;
        }
        button{
            width:46%;
            height: 35px;
            margin-left: 2%;
            /*background: lightseagreen;*/
        }
        .demo{
            width:100%;
            padding:10px;
            margin:10px auto;
            border: 1px solid #fff;
            background-color:white;
        }
    </style>
    <style type="text/css">
        #page_title{height:32px; line-height:32px; text-align:center}
        .demo{width:100%; margin:10px auto}
        .demo h4{height:24px; line-height:24px; font-size:14px}
        #pagetxt{ height:160px; border:1px solid #999; padding:4px;}
        #pagetxt p{line-height:24px; font-size:14px}
        #pagetxt p span{float:right; color:#999}
    </style>

</head>
<body>

<!--头-->
<!--<div id="header">-->
<!--    <div style="float: left; margin-left: 30px">-->
<!--        <img src="./images/intcoLogo.png"-->
<!--             style="width: 30px;height: 30px">-->
<!--    </div>-->
<!--    &nbsp; 龙创科技-->
<!--</div>-->
<!--<div>-->
<!--    <p></p>-->
<!--    <button>我的评审单</button>-->

<!--    <button>待评审订单</button>-->
<!--    <p></p>-->
<!--</div>-->

<h5 style="text-align: center; border: 2px solid lightseagreen;margin-top: 0;margin-bottom: 0">我的共享考车充值记录</h5>
<div id="orderContainer">
    <table id="listTable" >
        <tr onclick="testAction()" >
            <td class="listID title">主机号</td>
            <td class="listKind title">课时数</td>
            <td class="listState title">验证码</td>
            <!--            <td class="listProductNum title">总课时</td>-->
            <!--            <td class="listCustomer title">单价</td>-->
            <!--            <td class="listSaleman title"><button>业务员</button></td>-->
            <!--            <td class="listSpecification title">规格</td>-->
            <!--            <td class="listExpectedTime title">期望交期</td>-->
        </tr>
        <tr>
            <td class="listID">-</td>
            <td class="listKind">-</td>
            <td class="listState">-</td>
            <!--            <td class="listProductNum">-</td>-->
            <!--            <td class="listCustomer">-</td>-->
            <!--            <td class="listSaleman">-</td>-->
            <!--            <td class="listSpecification">-</td>-->
            <!--            <td class="listExpectedTime">-</td>-->
        </tr>
        <tr>
            <td class="listID">-</td>
            <td class="listKind">-</td>
            <td class="listState">-</td>
            <!--            <td class="listProductNum">-</td>-->
            <!--            <td class="listCustomer">-</td>-->
            <!--            <td class="listSaleman">-</td>-->
            <!--            <td class="listSpecification">-</td>-->
            <!--            <td class="listExpectedTime">-</td>-->
        </tr>
        <tr>
            <td class="listID">-</td>
            <td class="listKind">-</td>
            <td class="listState">-</td>
            <!--            <td class="listProductNum">-</td>-->
            <!--            <td class="listCustomer">-</td>-->
            <!--            <td class="listSaleman">-</td>-->
            <!--            <td class="listSpecification">-</td>-->
            <!--            <td class="listExpectedTime">-</td>-->
        </tr>

    </table>

</div>
<!--p标签 分隔开分页符和数据和页面选择-->
<p style="color: red; text-align: center">* 仅显示最近三次记录</p>
<!--<div id="demo3" style="width: 100%;"></div>-->

<!--<div id="backTest" style="background: darkgoldenrod;">000000</div>-->
<!--<div id="foot" style="background: darksalmon;">1111111111</div>-->

<script type="text/javascript">

    var gxTotal = 100;
    var gxToken = 30;
    var access  = gxTotal-gxToken;

    var tMoney = document.getElementById('totalMoney');
    tMoney.innerHTML = gxTotal+' 元';
    var alMoney = document.getElementById('alreadyMoney');
    alMoney.innerHTML = gxToken+' 元';
    var acMoney = document.getElementById('accessMoney');
    acMoney.innerHTML = access+' 元';


    $(function(){


        var data1 = '<?php echo $phpJson; ?>';
        var objFromJson1 = JSON.parse(data1);

        // var totalCount;
        var num = 3;

//                totalCount = Number(data); // Number (); string 转 int
//                totalCount = 21/5;   JS 相除 自动 进一
        //        totalCount = Number(data)/5;

        var totalCount = Math.ceil(objFromJson1.length/10);
        alert(totalCount);
        if (totalCount<6){
            num = 3;
        }else {
            num = 6;
        }


        $("#demo3").paginate({
            count 		: totalCount,
            start 		: 1,
            display     : num,
            border					: true,
            border_color			: '#BEF8B8',
            text_color  			: '#79B5E3',
            background_color    	: '#E3F2E1',
            border_hover_color		: '#68BA64',
            text_hover_color  		: '#2573AF',
            background_hover_color	: '#CAE6C6',
            images					: false,
            mouse					: 'press',
            onChange     			: function(page){

                var data = '<?php echo $phpJson; ?>';
                var objFromJson = JSON.parse(data);
                // 每页显示 5 条数据 ，如果数据不足 5 条 则按照实际数量显示。
                var orderCount    = 0;
                var leftC = objFromJson.length-(page-1)*10;
                alert('llll'+page);
                if (leftC>=10){
                    orderCount = 10;
                }else {
                    orderCount = leftC;
                    var tb = document.getElementById('listTable');
                    //  alert(orderCount);
                    for (var i=orderCount;i<=10;i++){
//                               tb.deleteRow(i);
                        alert('cccc');
                        tb.rows[i].childNodes[1].innerText = '-';
                        tb.rows[i].childNodes[3].innerHTML = '-';
                        tb.rows[i].childNodes[5].innerHTML = '-';
                        tb.rows[i].childNodes[7].innerHTML = '-';
                        tb.rows[i].childNodes[9].innerText = '-';
                        tb.rows[i].childNodes[11].innerText = '-';
                        tb.rows[i].childNodes[13].innerHTML = '-';
                        tb.rows[i].childNodes[15].innerText = '-';
                    }
                }
                // 循环遍历，创建table
                // JudgeType,SalesmanCode,CustomerCode,ProductCode,FormatType,ExpectedTime,ApproveType
                var idArray = new Array();

                for ( var j = 0;j<orderCount;j++){
                    //   alert(j);
                    var rowNum         = j+1;
                    var index          = objFromJson[j+(page-1)*10].MasterID;
                    var kind           = objFromJson[j+(page-1)*10].coach_name;
                    var state          = objFromJson[j+(page-1)*10].coach_tel;
                    var saleman        = objFromJson[j+(page-1)*10].MasterID;
                    var customer       = objFromJson[j+(page-1)*10].coach_price;
                    var productNum     = objFromJson[j+(page-1)*10].MasterID;
                    var specification  = objFromJson[j+(page-1)*10].orderID;
                    var expectedTime   = objFromJson[j+(page-1)*10].studentID;



                    // idArray.push(index);
                    addAction(index,kind,state,saleman,customer,productNum,specification,expectedTime,rowNum);
                }

                Test(idArray);
                //    }
                //   });
            }
        });
        $("#pagetxt").ajaxSend(function(event, request, settings){
            $(this).html("<img src='loading.gif' /> 正在读取。。。");
        });
    });
</script>

<script type="text/javascript">

    function addAction(seriNum,kind,state,saleman,customer,productNum,specification,expectedTime,rowNum) {

        var primaryTB   = document.getElementById('listTable');
        // 向table写入新数据
//            document.getElementById('foot').innerHTML = rowNum;
        primaryTB.rows[rowNum].childNodes[1].innerText = seriNum;
        primaryTB.rows[rowNum].childNodes[3].innerHTML = kind;
        primaryTB.rows[rowNum].childNodes[5].innerHTML = state;
        primaryTB.rows[rowNum].childNodes[7].innerHTML = productNum;
        primaryTB.rows[rowNum].childNodes[9].innerHTML = customer;
        primaryTB.rows[rowNum].childNodes[11].innerText=saleman;
        primaryTB.rows[rowNum].childNodes[13].innerHTML=specification;
        primaryTB.rows[rowNum].childNodes[15].innerHTML= "xxxxxx";
//expectedTime.date.substr(0,10);
        // 添加点击事件

    }
    window.onload = function(){ // 页面加载完毕之后，调用函数为 TR 添加点击事件（onclick）

        initAction();

    };
    function testAction() {
        alert('title！');
    }
    // 为 每一个tr 添加点击事件 的函数 ，在 window.onload 之后调用。
    function Test(idArray ){
//        var string = localStorage.getItem('idArray');
//        document.getElementById('foot').innerHTML = string+'nnn';
//        var ss     = string.split('-=-',5);
//        document.getElementById('foot').innerHTML = ss;
        var rows=document.getElementById("listTable").rows;
        if(rows.length>0){
            for(var i=1;i<=idArray.length;i++){
                (function(i){
                    var obj=rows[i];
                    obj.onclick=function () {
//                        orderDetailAction(rows.length-i);
                        orderDetailAction(idArray[idArray.length-i]);
                    };
                })(i)
            }
        }
    }
    // 初始化，加载第一页的数据。
    function initAction() {

//                document.getElementById('backTest').innerHTML = data;
        var data = '<?php echo $phpJson; ?>';
        var objFromJson = JSON.parse(data);
        //  alert(objFromJson);
        // 每页显示 5 条数据 ，如果数据不足 5 条 则按照实际数量显示。
        var orderCount    = 0;
        if (objFromJson.length>=10){
            orderCount = 10;
        }else {
            orderCount = objFromJson.length;
//                           var tb = document.getElementById('listTable');
//                        for (var i=orderCount;i<=5;i++){
////                               tb.deleteRow(i);
//                            tb.rows[i].opacity = 0;
//                        }
        }
        // 循环遍历，创建table
        // JudgeType,SalesmanCode,CustomerCode,ProductCode,FormatType,ExpectedTime,ApproveType
        var idArray = new Array();   // 存放当前页的记录的数据库 id
        //  alert(JSON.stringify(objFromJson));
        var totalC = objFromJson.length;
           alert(totalC);
        for (var i=0;i<orderCount;i++){
            var rowNum         = i+1;
            var index          = objFromJson[i].MasterID;
            var kind           = objFromJson[i].class_count;
            var state          = objFromJson[i].yzm;
            var saleman        = objFromJson[i].classCount;
            var customer       = objFromJson[i].coach_price;
            var productNum     = objFromJson[i].classCount;
            var specification  = objFromJson[i].coach_price;
            var expectedTime   = objFromJson[i].coach_price;
            // 调用函数，向表格写入数据。
            idArray.push(index);
            addAction(index,kind,state,saleman,customer,productNum,specification,expectedTime,rowNum);
        }
        // >  添加点击事件
        //      Test(idArray);

    }
</script>

</body>
</html>