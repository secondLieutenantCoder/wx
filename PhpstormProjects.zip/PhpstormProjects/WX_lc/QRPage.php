<?php
//$a = '111111';
// 科目一科目四首页

//require './localPHP/jssdk.php';
//require "./lib/BmobObject.class.php";

//$jss = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

//$token = $jss->getAccessToken();




?>

<!
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<div>

    <h3>输入主机号生成二维码</h3>
    <p id = "priceKS"><button  style="width: 25%;height: 40px;border: white;background: whitesmoke;">主机号:</button><input type="text" name="namePrice" id="priceID" style="margin-left: 3%;width: 65%;height: 40px;"></p>

    <button onclick="showPrice()" style="margin-left: 30%;width: 40%;height: 40px;background-color: #8EE5EE;border: white;border-radius: 5px">生成二维码</button>
</div>

</body>

<script>

    // 课时单价
   // var price  =  document.getElementById('priceID').value;
   // alert(price);

    function showPrice() {

        var token = '<?php echo $token; ?>';
        alert(token);

        var price  =  document.getElementById('priceID').value;
        // alert(price);
       // alert(price);

        location.href = './shareQR.php?zID='+price+'&token='+token;

    }

</script>
</html>
