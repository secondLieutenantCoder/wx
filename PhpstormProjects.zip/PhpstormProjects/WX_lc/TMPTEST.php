<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/3/30
 * Time: 13:56
 */


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>龙创交规</title>
</head>

<style>



</style>

<body onload="shareLoadAction()">

<div style="width: 100%;height: 360px;background-color: red">


    <h1>zongbaxihubixizi,danzhuangnongmozongxiangyi</h1>

    <p><button style="color: darkblue;" onclick="infoAction()">显示弹窗</button></p>




</div>



<script>



    var GameScore = Bmob.Object.extend("WX_user");
    var query = new Bmob.Query(GameScore);
    alert('save =======!');

    // 这个 id 是要修改条目的 id，你在生成这个存储并成功时可以获取到，请看前面的文档
    var objId = object.get('objectId');
    alert(objId);
    query.get(objId, {
        success: function(gameScore) {
            // 回调中可以取得这个 GameScore 对象的一个实例，然后就可以修改它了
            alert('save ********!');
            gameScore.set('phone', phone);
            gameScore.set('realname', name);
            gameScore.save();

            // The object was retrieved successfully.
        },
        error: function(object, error) {
            alert(error);
        }
    });


    function shareLoadAction() {

        var ph = localStorage.getItem('phone');
        var isPhone = checkPhone();
        if (isPhone === 'true'){


        }else {

            infoAction();
        }
    }

    function infoAction() {

        alert(JSON.stringify());
        var mask = document.createElement('div');
        mask.id = "mask";
        mask.style.backgroundColor = 'lightblue';
        mask.style.width = "90%";
        mask.style.height = "100%";
        mask.style.position = "absolute";
        mask.style.top  = "0px";
        mask.style.left = "5%";
        //  mask.style.filter = 'alpha(opacity=5%)';
        //        mask.style.opacity=0.4;
        //      mask.style.zIndex = 20;
        mask.style.backgroundColor = "rgba(0,0,0,0.5)";
        document.body.appendChild(mask);


        var alertWin = document.createElement('div');
        alertWin.id = "alertWin";
        alertWin.style.width = "90%";
        alertWin.style.height = "auto";
        //    alertWin.position = "absolute";
        alertWin.style.marginTop = "30%";
        alertWin.style.left = '0px';
        alertWin.style.backgroundColor = 'lightskyblue';
        alertWin.style.opacity=1;
        alertWin.style.borderRadius = "5px";
        //       alertWin.style.zIndex = 30;
        mask.appendChild(alertWin);



        var title = document.createElement('p');
        title.textContent = "完善个人信息";
        title.style.textAlign = 'center';
        alertWin.appendChild(title);

localStorage.setItem('phone',phoneWW);

        var tips = document.createElement('label');
        tips.textContent = "请完善您的个人信息，让更多的学员找到您";
        tips.style.color = 'red';
        alertWin.appendChild(tips);

        var nameC = document.createElement('p');
        nameC.textContent = " 真实姓名  ";
        nameC.style.marginLeft = "5%";
        alertWin.appendChild(nameC);

        var nameInput     = document.createElement('input');
        nameInput.name  = 'rName';
        nameInput.id = 'iName';
        nameInput.type    = 'text';
        nameInput.style.width = "60%";
        nameInput.style.height = "30px";
        nameC.appendChild(nameInput);

        var cPhone = document.createElement('p');
        cPhone.textContent = '  手机号码  ';
        cPhone.style.marginLeft = '5%';
      //  cPhone.style.height = '30px';
        alertWin.appendChild(cPhone);

        var phone = document.createElement('input');
        phone.name = 'phone';
        phone.type = 'text';
        phone.id = 'iPhone';
        phone.style.width = '60%';
        phone.style.height = "30px";
        cPhone.appendChild(phone);

        var saveBtn = document.createElement('button');
        saveBtn.textContent = "保存1";
        saveBtn.style.width = '30%';
        saveBtn.style.marginLeft = '15%';
        saveBtn.style.border = 'white';
        saveBtn.style.height = '36px';
        saveBtn.style.backgroundColor = "ghostwhite";
        saveBtn.style.font = "20px";
        saveBtn.style.color = "white";
        //  saveBtn.style.position = 'ablolute';
        alertWin.appendChild(saveBtn);


        var cancel = document.createElement('button');
        cancel.textContent = "取消";
        cancel.style.border = "white";
        cancel.style.width = "30%";
        cancel.style.height = '36px';
        cancel.style.marginLeft = '10%';
        cancel.style.backgroundColor = "ghostwhite";
       cancel.status.fontSize = "20px";
       cancel.style.color  = "white";
        alertWin.appendChild(cancel);
        cancel.addEventListener('click',cancelAction);
        saveBtn.addEventListener('click',saveAction);

        var space1 = document.createElement('p');
        space1.textContent = ' 1  ';
        alertWin.appendChild(space1);

    }

    function saveAction() {


        var name = document.getElementById('iName').value;
        var phone = document.getElementById('iPhone').value;

        var isphone = checkPhone(phone);

       if (isphone === 'true'){

           alert('save success!');

       }else {

           alert('phone error!');

       }






    }

    function cancelAction() {

        document.body.removeChild(document.getElementById('mask'));
    }

    function checkPhone(phone){
      //  var phone = document.getElementById('phone').value;
        if(!(/^1[34578]\d{9}$/.test(phone))){
            alert("手机号码有误，请重填");
            return false;
        }else {
            return true;
        }
    }

</script>


</body>


</html>



