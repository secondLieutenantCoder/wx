<?php
ini_set('date.timezone','Asia/Shanghai');
error_reporting(E_ERROR);

require_once "../lib/WxPay.Api.php";
require_once '../lib/WxPay.Notify.php';
require_once 'log.php';

//初始化日志
$logHandler= new CLogFileHandler("../logs/".date('Y-m-d').'.log');
$log = Log::Init($logHandler, 15);

class PayNotifyCallBack extends WxPayNotify
{
	//查询订单
	public function Queryorder($transaction_id)
	{
		$input = new WxPayOrderQuery();
		$input->SetTransaction_id($transaction_id);
		$result = WxPayApi::orderQuery($input);
		Log::DEBUG("query:" . json_encode($result));
		if(array_key_exists("return_code", $result)
			&& array_key_exists("result_code", $result)
			&& $result["return_code"] == "SUCCESS"
			&& $result["result_code"] == "SUCCESS")
		{
			return true;
		}
		return false;
	}
	
	//重写回调处理函数
	public function NotifyProcess($data, &$msg)
	{
		Log::DEBUG("call back:" . json_encode($data));
		$notfiyOutput = array();
		
		if(!array_key_exists("transaction_id", $data)){
			$msg = "输入参数不正确";
			return false;
		}
		//查询订单，判断订单真实性
		if(!$this->Queryorder($data["transaction_id"])){
			$msg = "订单查询失败";


			return false;
		}
		return true;
	}
}

Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle(false);


$resParam = $notify->GetValues();
if ($resParam['return_code'] === 'SUCCESS' && $resParam['return_msg'] === 'ok'){

    $raw_xml = file_get_contents("php://input");
    libxml_disable_entity_loader(true);
   // $res = json_decode(json_encode(simplexml_load_string($raw_xml,'simpleXMLElement',LIBXML_NOCDATA)));
    $resObj = simplexml_load_string($raw_xml);
    require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";
    // 1.取bmob数据
    $bmobObj = new BmobObject("WX_user");

    $currentOpenID = $resObj->openid;
    $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
    $res    = $bmobObj->get("",array("$queryStr"));
    $res1   = $res->results;
    $currentObj = $res1[0];

    // objectId
    $cObjID = $currentObj->objectId;

  //  $timestamp = time()+7000;
    $objID = 'a0c44d19d4';
    $resUpdatae  = $bmobObj->update($objID,array("openID"=>"$resObj->appid","p1"=>$resParam['return_msg']));

    //$currentObj = '';


    // 收到通知，更新状态，对应openid lc_state = 1
    $fee = $resObj->total_fee;
    // 学员的实际缴费 38 、68
    $fee1 = $fee/100;
    // 过期时间戳
    $d = date("Y/m/d").'  ----  '.date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d"))));
    $t = strtotime($d);
    $endT = 0;
    if ($fee1 == 38){
        $endT = strtotime(date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d")))));
    }else{
        $endT = strtotime(date("Y/m/d",strtotime("+60 days",strtotime(date("Y/m/d")))));
    }
    //if($days == 30) {echo date("Y/m/d").'  ----  '.date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d"))));} else { echo date("Y/m/d").'  ----  '.date("Y/m/d",strtotime("+60 days",strtotime(date("Y/m/d"))));}
    $resUpdatae  = $bmobObj->update($cObjID,array("lc_state"=>"1","endTime"=>"$fee1"));


    // $res=$bmobObj->get("",array('where={"orderID":"$orderid"}'));
    $queryStr = "where={\"orderID\":\"{$orderid}\"}";
    $resQuery = $bmobObj->get("",array("$queryStr"));
    $res1Q = $resQuery->results;
    if (count($res1Q)>0){



    }else{

        echo 'aaa';
    }



    // 给"我"的上级提成
$p1  = $currentObj->p1;
$queryp1 = "where={\"openID\":\"{$p1}\"}";
$resp1 = $bmobObj->get("",array($queryp1));
$resp11 = $resp1->results;
$objp1  = $resp11[0];
$objidp1 = $objp1->objectId;
$moneyp1 = $objp1->money;
$newmoneyp1 = $moneyp1+$fee1;
$updatep1 = $bmobObj->update($objidp1,array("money"=>"$newmoneyp1"));

$p2  = $currentObj->p2;
    $queryp2 = "where={\"openID\":\"{$p2}\"}";
    $resp2 = $bmobObj->get("",array($queryp2));
    $resp22 = $resp2->results;
    $objp2  = $resp22[0];
    $objidp2 = $objp2->objectId;
    $moneyp2 = $objp2->money;
    $newmoneyp2 = $moneyp2+$fee1;
    $updatep2 = $bmobObj->update($objidp2,array("money"=>"$newmoneyp2"));

$p3  = $currentObj->p3;
    $queryp3 = "where={\"openID\":\"{$p3}\"}";
    $resp3 = $bmobObj->get("",array($queryp3));
    $resp33 = $resp3->results;
    $objp3  = $resp33[0];
    $objidp3 = $objp3->objectId;
    $moneyp3 = $objp3->money;
    $newmoneyp3 = $moneyp3+$fee1;
    $updatep3 = $bmobObj->update($objidp3,array("money"=>"$newmoneyp3"));

    if(strlen($p3)>10){

        echo '字符串长度大于10';

    }

// 查询更新
}

//   正式后台
//if ($resParam['return_code'] === 'SUCCESS' && $resParam['return_msg'] === 'OK'){
//
//    $raw_xml = file_get_contents("php://input");
//    libxml_disable_entity_loader(true);
//    // $res = json_decode(json_encode(simplexml_load_string($raw_xml,'simpleXMLElement',LIBXML_NOCDATA)));
//    $resObj = simplexml_load_string($raw_xml);
//
//    require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";
//    // 1.取bmob数据
//    $bmobObj = new BmobObject("WX_user");
//    //  $timestamp = time()+7000;
//    //  $objID = 'a0c44d19d4';
//    //  $openid = $resObj-> openid;
//
//    $currentOpenID = $resObj->openid;
//    $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
//    $res=$bmobObj->get("",array("$queryStr"));
//    $res1 = $res->results;
//    $currentObj =  $res1[0];
//
//    // objectId
//    $cObjID = $currentObj->objectId;
//
//    $resUpdatae  = $bmobObj->update($cObjID,array("lc_state"=>"1"));
//
//}