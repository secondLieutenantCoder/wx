<?php
include './Base.php';
include './Rsa.php';
/*
 * 黎明互联
 * https://www.liminghulian.com/
 */
//echo "888888";
class WxComPay extends Base
{
    private $params;
    const PAYURL = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
    const SEPAYURL = "https://api.mch.weixin.qq.com/mmpaymkttransfers/gettransferinfo";
    const PKURL = "https://fraud.mch.weixin.qq.com/risk/getpublickey";
    const BANKPAY = "https://api.mch.weixin.qq.com/mmpaysptrans/pay_bank";
    public function getPuyKey(){

        $this->params = array(
            'mch_id'    => self::MCHID,//商户ID
            'nonce_str' => md5(time()),
            'sign_type' => 'MD5'
        );
        /*
                $this->params = [
                    'mch_id'    => self::MCHID,//商户ID
                    'nonce_str' => md5(time()),
                    'sign_type' => 'MD5'
                ];
        */

        return $this->send(self::PKURL);
    }

    /*
    public function comPay($data){
        //构建原始数据
        $this->params = [
            'mch_appid'         => self::APPID,//APPid,
            'mchid'             => self::MCHID,//商户号,
            'nonce_str'         => md5(time()), //随机字符串
            'partner_trade_no'  => date('YmdHis'), //商户订单号
            'openid'            => $data['openid'], //用户openid
            'check_name'        => 'NO_CHECK',//校验用户姓名选项 NO_CHECK：不校验真实姓名 FORCE_CHECK：强校验真实姓名
            //'re_user_name'    => '',//收款用户姓名  如果check_name设置为FORCE_CHECK，则必填用户真实姓名
            'amount'            => $data['price'],//金额 单位分
            'desc'              => '测试付款',//付款描述
            'spbill_create_ip'  => $_SERVER['SERVER_ADDR'],//调用接口机器的ip地址
        ];
        //将数据发送到接口地址
        return $this->send(self::PAYURL);
    }*/

    public function bankPay($data){

        $this->params = array(

            'mch_id'    => self::MCHID,//商户号
            'partner_trade_no'   => date('YmdHis'),//商户付款单号
            'nonce_str'           => md5(time()), //随机串
            'enc_bank_no'         => $data['enc_bank_no'],//收款方银行卡号RSA加密
            'enc_true_name'       => $data['enc_true_name'],//收款方姓名RSA加密
            'bank_code'           => $data['bank_code'],//收款方开户行
            'amount'              => $data['amount'],//付款金额
        );
        /*
                $this->params = [
                    'mch_id'    => self::MCHID,//商户号
                    'partner_trade_no'   => date('YmdHis'),//商户付款单号
                    'nonce_str'           => md5(time()), //随机串
                    'enc_bank_no'         => $data['enc_bank_no'],//收款方银行卡号RSA加密
                    'enc_true_name'       => $data['enc_true_name'],//收款方姓名RSA加密
                    'bank_code'           => $data['bank_code'],//收款方开户行
                    'amount'              => $data['amount'],//付款金额
                ];
        */
        //将数据发送到接口地址
        return $this->send(self::BANKPAY);
    }

    public function searchPay($oid){

        $this->params = array(
            'nonce_str'  => md5(time()),//随机串
            'partner_trade_no'  => $oid, //商户订单号
            'mch_id'  => self::MCHID,//商户号
            'appid'  => self::APPID //APPID
        );
        /*
                $this->params = [
                    'nonce_str'  => md5(time()),//随机串
                    'partner_trade_no'  => $oid, //商户订单号
                    'mch_id'  => self::MCHID,//商户号
                    'appid'  => self::APPID //APPID
                ];
        */
        //将数据发送到接口地址
        return $this->send(self::SEPAYURL);
    }


    public function sign(){

//echo '444444444444444';
        //  var_dump($this->params);
//echo '5555555555555555';
        return $this->setSign($this->params);
    }

    public function send($url){
        $res = $this->sign();
// echo 'wwwwwwwww';

        //      var_dump($res);

        //      echo 'oooooooooo';
        $xml = $this->ArrToXml($res);

//        $xmlM = "<xml>
//<mch_id><![CDATA[%s]]></mch_id>
//<nonce_str><![CDATA[%s]]></nonce_str>
//<sign><![CDATA[%s]]></sign>
//<sign_type><![CDATA[%s]]></sign_type>
//</xml>";

//        $responseSubsxribe = printf($xmlM,$res->mch_id,$res->nonce_str,$res->sign,$res->sign_type);
//        echo $responseSubsxribe;


        $returnData = $this->postData($url, $xml);
        return $this->XmlToArr($returnData);
    }
}

$obj = new WxComPay();
/*
 * 付款到零钱
 */
/*
$data = [
    'openid'  => 'oPNkhv1TzPiJ3FGau0_1MHIfnpB4',
    'price'   => '100'
];
$res = $obj->comPay($data);
*/

//查询

$oid = "20180408143756";
$resSearch = $obj->searchPay($oid);

var_dump($resSearch);

//获取公钥
/*
$res = $obj->getPuyKey();
echo '------';
var_dump($res);
echo '======';
//   ./cert/pubkey.pem
file_put_contents('./pubkey.pem', $res['pub_key']);

openssl rsa -RSAPublicKey_in -in pubkey.pem -out  newPubkey.pem ;
*/
//企业付款到银行卡

$rsa = new RSA(file_get_contents('./pcs8.pem'), '');


//$ccc =  file_get_contents('./pubkey.pem');
//echo 'ccc'.$ccc;

$data = array(
    'enc_bank_no'         => $rsa->public_encrypt('6228480298410843577'),//收款方银行卡号RSA加密
    'enc_true_name'       => $rsa->public_encrypt('王伟'),//收款方姓名RSA加密
    'bank_code'           => '1005',//收款方开户行
    'amount'              => '100' //付款金额
);

/*
$data = [
    'enc_bank_no'         => $rsa->public_encrypt('6228480298410843577'),//收款方银行卡号RSA加密
    'enc_true_name'       => $rsa->public_encrypt('王伟'),//收款方姓名RSA加密
    'bank_code'           => '1005',//收款方开户行
    'amount'              => '1',//付款金额
];
*/


$res = $obj->bankPay($data);
echo '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!++++++++++!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!';
var_dump($res);

echo '<pre>';

echo $res;
//print_r($res);