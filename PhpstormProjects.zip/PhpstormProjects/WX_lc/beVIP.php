<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/1/30
 * Time: 11:29
 */




?>

<!DOCTYPE HTML>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title></title>
</head>
<body>

<div id="contain" style="margin-top: 30px;">
    <label>  开通系统后，您将获得龙创交规的全部服务功能，包括习题技巧详解，语音播报等。</label>
    <hr style="color: #8EE5EE">
    <h4 style="color: #0066ee">开通费用</h4>
    <ul>
        <li>1.开通系统30天，38元。</li>
        <li>2.开通系统60天，60元</li>
    </ul>
    <br>
    <label>系统过期后，需重新开通才能再次获取到功能。</label>

   <p><label>
           <input onclick="checkJudgeAction(this)"  id="ch1" type="checkbox"  name="38">
       </label> <label style="color: red;">30天/38元</label></p>
    <p><label>
            <input onclick="checkJudgeAction(this)" id="ch2"  type="checkbox">
        </label> <label style="color: red;">60天/68元</label></p>


</div>
<br>
<br>
<button onclick="beVIPAction()" style="margin-left: 20%;width: 60%; height: 40px;border: white;background-color: limegreen;color: white;border-radius: 8px;font-size: 18px">点击开通</button>

<?php
require './localPHP/jssdk.php';

$jsSDK = new JSSDK('wx62732b3c3460b3b1','cc05112ee2e8f53d80970d0d988398cd');

$packet = $jsSDK->getSignPackage();
$pacObj = json_encode($packet);
$p = 'pppppppp';
//echo '000000'.json_encode($packet);
?>

<!--<h5>--><?php //echo $p; ?><!--</h5>-->

</body>

<script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.2.0.js"></script>
<script type="text/javascript">


    wx.config({

        debug:true,
        appId:"<?php echo $packet; ?>",
        timestamp: "<?php echo $packet->timestamp; ?>",
        nonceStr: "<?php echo $packet->nonceStr; ?>",
        signature: "<?php echo $packet->signature; ?>",
        jsApiList: ['chooseWXPay']
    });

    wx.ready({

        wx.chooseWXPay({


    });

    })

</script>
<script type="text/javascript">

    function Click(){

        if(event.button==2){alert

        ('屏蔽右键菜单');

        }}

    document.onmousedown=Click;

    var c1 = document.getElementById('ch1');
    c1.checked = true;

    function checkJudgeAction(ch) {

        var c1 = document.getElementById('ch1');
        var c2 = document.getElementById('ch2');

        c1.checked = false;
        c2.checked = false;

        ch.checked = true;

    }

    // 开通会员事件
    function beVIPAction() {

         alert('xxxxx');

        var c1 = document.getElementById('ch1');
        var c2 = document.getElementById('ch2');
        // c2.checked = true;
        var money=0;
        if (c1.checked === true){
            money = 38;
        } else {

            money = 68;
        }

        location.href = "./weixinPay/jsapi.php?days="+money;

        //var n =document.createElement("label");
        //n.innerHTML = "<?php //echo $p; ?>//";
        //
        //var d = document.getElementById('contain');
        //d.appendChild(n);
    }



</script>

</html>
