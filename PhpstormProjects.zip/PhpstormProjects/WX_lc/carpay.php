<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/4/25
 * Time: 09:06
 */


$xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
$responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
echo $responseSubsxribe;


//$modal = "<xml></xml>";