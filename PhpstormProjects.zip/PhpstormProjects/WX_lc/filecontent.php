<?php


     function get_php_file($filename) {
        return trim(substr(file_get_contents($filename), 15));
    }

     function set_php_file($filename, $content) {
        $fp = fopen($filename, "w");
        fwrite($fp, "<?php exit();?>" . $content);
        fclose($fp);
    }

//function getJsApiTicket() {
    // jsapi_ticket 应该全局存储与更新，以下代码以写入到文件中做示例
    $data = json_decode(get_php_file("ticket.php"));
    $ticket = '11111111';
    if ($data->expire_time < time()) {

        // 如果是企业号用以下 URL 获取 ticket
        // $url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=$accessToken";
//        $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
//        $res = json_decode($this->httpGet($url));
//        $ticket = $res->ticket;
        $ticket = 'rrrrrrrrrrrr';
//        if ($ticket) {
            $data->expire_time = time() + 7000;
            $data->jsapi_ticket = $ticket;
            set_php_file("ticket.php", json_encode($data));
//        }
    } else {
//        $ticket = $data->jsapi_ticket;
        $ticket = '333333333';
    }

//    return $ticket;
//}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

<button onclick="getfileAction()" style="width: 60%;height: 50px;"> 取文件数据 </button>
<h3 id="test">66666666</h3>


</body>
<script>

    function getfileAction() {

        alert('文件操作');

        var yyy = "<?php echo $ticket; ?>";
        var hh = document.getElementById('test');
        hh.innerHTML = yyy;
    }

</script>
</html>

