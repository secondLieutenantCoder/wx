<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/2/11
 * Time: 08:19
 */

$id = $_GET['id'];

if($id==001){

    //

    echo json_encode(array('id'=>001,'name'=>'zhangsan','CC'=>'Hello world!'));

}

if($id==002){

    echo json_encode(array('id'=>002,'name'=>'lisi'));

}

if($id==003){

    echo json_encode(array('id'=>003,'name'=>'wangwu'));

}

//echo "<br/><input type='button' value='提交'/>";


?>

