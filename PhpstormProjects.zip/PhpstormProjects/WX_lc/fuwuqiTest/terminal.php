<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/2/11
 * Time: 08:20
 */

$res = file_get_contents('http://192.168.1.106/fuwuqiTest/server.php?id=001');

echo $res;
$res1 = json_decode($res);

//var_dump($res1);