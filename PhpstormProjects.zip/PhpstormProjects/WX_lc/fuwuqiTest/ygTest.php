<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/2/11
 * Time: 14:48
 */
//
//http://192.168.1.106/fuwuqiTest/server.php
$res = file_get_contents('http://192.168.1.108:7777/Service1.asmx?op=selectAllCargoInfor');

echo $res;
$res1 = json_decode($res);


/**
 * 发送post请求
 * @param string $url 请求地址
 * @param array $post_data post键值对数据
 * @return string
 */
//function send_post($url, $post_data) {
//    $postdata = <a href="https://www.baidu.com/s?wd=http_build_query&tn=44039180_cpr&fenlei=mv6quAkxTZn0IZRqIHckPjm4nH00T1YLuyf3rHF9mHbvPyc3ujNh0ZwV5Hcvrjm3rH6sPfKWUMw85HfYnjn4nH6sgvPsT6KdThsqpZwYTjCEQLGCpyw9Uz4Bmy-bIi4WUvYETgN-TLwGUv3EnWT4rj6srHbk" target="_blank" class="baidu-highlight">http_build_query</a>($post_data);
//      $options = array(
//          'http' => array(
//              'method' => 'POST',
//              'header' => 'Content-type:application/x-www-form-urlencoded',
//              'content' => $postdata,
//              'timeout' => 15 * 60 // 超时时间（单位:s）
//          )
//      );
//        $context = stream_context_create($options);
//        $result = file_get_contents($url, false, $context);
//        return $result;
//}