<?php
require "./lib/BmobObject.class.php";

// 1.取bmob数据
$bmobObj = new BmobObject("ProxyOBDMaster ");
//  $timestamp = time()+7000;
//  $objID = 'a0c44d19d4';
//  $openid = $resObj-> openid;

$studentID = "o7XC90jGgVsu2ra0omYf2UY900Yo1";
$queryStr = "where={\"proxy_id\":\"{$studentID}\"}";
$res=$bmobObj->get("",array("$queryStr"));
$res1 = $res->results;
$proxy = count($res1);
echo $proxy;
echo '*****';
$isProxy =false;
if ($proxy > 0){
    // 代理
    echo '代理';
    $isProxy = true;
}

$coachID = "o7XC90jGgVsu2ra0omYf2UY900Yo1";
$queryCoach = "where={\"coach_id\":\"{$coachID}\"}";
$coachRes=$bmobObj->get("",array("$queryCoach"));
$coachRes1 = $coachRes->results;
$coach = count($coachRes1);
echo $coach;
$isCoach =false;
if ($coach >0){
    // 教练
    echo '教练';
$isCoach = true;
}

//strlen()

?>

<!
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>Document</title>
</head>

<style>
    .inPort{

        border: white;
        width: 60%;
        height: 45px;
        background: skyblue;
        font-size: 14px;
        border-radius: 5px;
        margin-left: 20%;
        color: white;

    }
</style>
<body>

<div id="suc" style="background-color: lightseagreen">

    <hr>
    <br>
    <div  >

        <p><button class="inPort" id="proxy" onclick="proxyAction()">代理</button></p>
        <p><button class="inPort" id="coach" onclick="coachAction()">教练</button></p>

    </div>
    <br>
</div>


<div id="fail" style="background-color: lightseagreen;height: 120px;width: 100%;">


    <br>
<h3 style="text-align: center">您不是共享考车用户!</h3>
</div>
<div style="width: 100%;margin-top: 0">

    <img style="width: 100%;" src="./PageShow/gongxiangPic.jpg">



</div>


</body>

<script>

    var openID = '<?php echo  $studentID; ?>';

var isProxy = '<?php echo $isProxy;?>';
var isCoach = '<?php echo $isCoach; ?>';
//alert(isProxy);
//alert(isCoach);
//var a = 1;
    var proxyBtn = document.getElementById('proxy');
    var coachBtn = document.getElementById('coach');

    var suc = document.getElementById('suc');
    var fail = document.getElementById('fail');

    fail.innerHTML =

if (isProxy == false  && isCoach == false){

    suc.hidden = true;
   // alert('不是共享考车用户，请联系龙创科技！');


}else if (isProxy == true && isCoach != true){

    //alert('代理');
    fail.hidden = true;
    coachBtn.hidden = true;

}else if(isProxy != true && isCoach == true){

   // alert('教练');
    fail.hidden = true;
    proxyBtn.hidden = true;

}else {

   // alert('代理+教练！');
    fail.hidden = true;


}

function coachAction() {

  location.href = "./PageShow/coachIndex.php";
}

function proxyAction() {

    location.href = "./PageShow/proxyIndex.php";
}
  //  alert('紧张开发中。。。');
   // WeixinJSBridge.call('closeWindow');



</script>
</html>
