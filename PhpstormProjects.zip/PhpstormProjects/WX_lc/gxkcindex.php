<?php
////$a = '111111';
//// 科目一科目四首页
//
//$xxx = 'xxxxxxx';
////echo $xxx;
//$authObj = new htmlAuth();
//// 获取用户的 openID
//$openid = $authObj->getWXAccesstoken();
////$wwTest = '000';
//echo  $openid;
//$authToken = $authObj->getToken();
////echo '-----'.$authToken;
//// 拉取用户信息
//$url="https://api.weixin.qq.com/sns/userinfo?access_token=$authToken&openid=$openid&lang=zh_CN";
//$html = file_get_contents($url);
//
//$htmlObj = json_decode($html);
//// echo $html;
//echo "<br>";
//echo $htmlObj->nickname;
//
//// $mID = $_GET['mID'];
//$mID = '000002';
//$authObj-> queryMainEngine($mID);
//
///*
////echo "====--===";
////echo $htmlObj->nickname;
//$authObj->saveUserInfo($openid,$htmlObj->nickname,$htmlObj->province,$htmlObj->headimgurl);
//$phone  =   $authObj->phone;
////echo $htmlObj;
////echo $phone;
////$userObjID = $html->objectId;
////echo $userObjID;
//$isVIP = $authObj->isVip;
////var_dump($authObj);
//$parent = $authObj->topOpenID;
//$wwBobjID = $authObj-> wwBmobObjID;
//
//*/
//
//// ========工具类=======
//class htmlAuth {
//    var $token;
//    var $isVip;
//    var $phone;
//
//    var  $wwBmobObjID;
//// 我的上级的     openID
//    var $topOpenID;
//
//    public function __construct() {
//
//    }
//    function getToken (){
//
//        return $this->token;
//    }
//
//// ============查询主机信息，代理、教练等=========
//    public function  queryMainEngine($mID){
//
////        require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";
//        // 1.取bmob数据
//        $bmobObj = new BmobObject("ProxyOBDMaster");
//        $queryStr = "where={\"MasterID\":\"{$mID}\"}";
//        $res=$bmobObj->get("",array("$queryStr"));
//        $res1 = $res->results;
//
//
//
//if (count($res1)>0){
//    $currentObj =  $res1[0];
//    //var_dump($res);
//    $jx = $currentObj->jiaxiao;
//    echo $jx;
//}else{
//
//    echo '该主机未注册！';
//}
//
//    }
//
//// 写入用户信息==================1111===================
//
//    public function saveUserInfo ($oid,$name,$province,$hurl){
////echo '写入用户信息';
////        require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";
//        // 1.取bmob数据
//        $bmobObj = new BmobObject("WX_user");
//        //  $timestamp = time()+7000;
//        //  $objID = 'a0c44d19d4';
//        //  $openid = $resObj-> openid;
//
//        $currentOpenID = $oid;
////echo $oid;
//        $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
//        $res=$bmobObj->get("",array("$queryStr"));
//        $res1 = $res->results;
//        $currentObj =  $res1[0];
////var_dump($res);
//        $endTime = $currentObj->endTime;
////echo $endTime;
//        // objectIda
//        $cObjID = $currentObj->objectId;
//        //  往Bmob写用户数据
//        $res=$bmobObj->update($cObjID, array("nickname"=>$name,"province"=>$province,"headimgurl"=>$hurl));
//
////  $bmobObjR = new BmobObject("WX_percentageRecord");
////echo 'Record1';
////$feeee = 39;
//        //     $resR = $bmobObjR->create(array("stuOpenID"=>"$currentOpenID","percentMoney"=>39,"coachOpenID"=>"2222","levelRelationship"=>"三级学员","topUpMoney"=>"3333","orderID"=>"66666",));
//
//
//        //  获取到当前的会员状态，是否已经开通？ 是否已经过期？
////var_dump($currentObj);
////$isVIP= 0;
//        $this->phone = $currentObj->phone;
//        $this->topOpenID = $currentObj->p1;
//
//        $this->wwBmobObjID =  $cObjID;
////echo 'phone';
////echo   $currentObj->phone;
//        if ($endTime < time()){
//            // 过期
//            $this->isVip = 0;
//        }else{
//            // 木过期
//            $this->isVip = 1;
//        }
//
//    }
//
//    // ==================- 获取网页授权 access-token -=============
//    public function getWXAccesstoken(){
//
//        $authCode = $_GET['code'];
//        $authState = $_GET['state'];
//
////echo $autoCode;
////echo $authState;
//
//        $appID = "wx62732b3c3460b3b1";
//        $appSecret = 'cc05112ee2e8f53d80970d0d988398cd';
////        $accessUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appID.'&secret='.$appSecret;
//        $accessUrl = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appID.'&secret='.$appSecret.'&code='.$authCode.'&grant_type=authorization_code';
//
//        $pageInfo  = file_get_contents($accessUrl);
//
//        $infoObj   = json_decode($pageInfo);
//
//        $this->token = $infoObj->access_token;
//
//        $expireIn    = $infoObj->expires_in;
//        $reat        = $infoObj->refresh_token;
//        $scope       = $infoObj->scope;
//
//        $opID = $infoObj->openid;
//
//        return $opID;
//    }//getWXAccessToken end
//}
//
//
//?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>龙创共享考车</title>


</head>


<body>



<div style="width: 100%;">
    <h2 style="text-align: center">设置代理</h2>

    <h3>共享考车号: 100001</h3>

    <p><button style="width: 25%;height: 40px;border: white;background: whitesmoke;">所属驾校:</button><input type="text" name="nameName" id="nameID" style="position: relative;float: left;margin-left: 3%; width: 70%;height: 40px;"></p>
    <p><button style="width: 25%;height: 40px;border: white;background: whitesmoke;">代理姓名:</button><input type="text" name="nameJX" id="jxID" style="width: 70%;height: 30px;"></p>
    <p><button style="width: 25%;height: 40px;border: white;background: whitesmoke;">代理电话:</button><input type="text" name="nameTEL" id="telID" style="width: 70%;height: 30px;"></p>
    <p><button style="width: 25%;height: 35px;border: white;background: whitesmoke;">姓名:</button><input type="text" name="nameName" id="nameID" style="width: 70%;height: 30px;"></p>

<button onclick="submitAction()" style="margin-left: 30%;width: 40%;height: 40px;background-color: #8EE5EE;border: white;border-radius: 5px">提交</button>
</div>

<div id="Student" style="top: 20%; margin-top: 30px;">

    <h3>共享考车编号</h3>

    <p><label>课时单价: 20元/小时</label></p>
<!--     ======= 课时数量 =======    -->
    <p><button style="width: 25%;height: 35px;border: white;background: whitesmoke;">请填写充值课时数量:</button>
        <input type="text" name="nameClass" id="classID" style="width: 70%;height: 30px;"></p>
    <p><label id="totalM">共计金额：00元</label></p>
    <button onclick="submitAction()" style="margin-left: 30%;width: 40%;height: 40px;background-color: #8EE5EE;border: white;border-radius: 5px">提交</button>

</div>



</body>

<script type="text/javascript" >

    function submitAction() {

        var  name = document.getElementById('nameID');
        alert(name.value);
        name.innerHTML =

name.
    = '';
        var mObjectId = <?php echo $mObjectId; ?>;

        //mObjectId.length
        if (1){

        }else if (

        )

        var ProxyOBD = Bmob.Object.extend("ProxyOBDMaster");
        var query = new Bmob.Query(ProxyOBD);

// 这个 id 是要修改条目的 id，你在生成这个存储并成功时可以获取到，请看前面的文档
        query.get(mObjectId, {
            success: function(proxyOBD) {
                // 回调中可以取得这个 GameScore 对象的一个实例，然后就可以修改它了
                proxyOBD.set('proxy_tel', "138!");
                proxyOBD.set('proxy_name','ppppp');
                proxyOBD.save();

                // The object was retrieved successfully.
            },
            error: function(object, error) {

            }
        });
    }


</script>
</html>
