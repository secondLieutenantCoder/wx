<?php

//require_once "../localPHP/jssdk.php";
//=================
//$yzmUtil = new YZMUtil();
//$yzm =$yzmUtil->getzcmAction("10000100010001");
$newc = 5;
$cishu = str_pad($newc,4,"0",STR_PAD_LEFT);
$shulian = str_pad(9,4,"0",STR_PAD_LEFT);
$gxMID = "000001";
$DATA1 = $gxMID.$cishu.$shulian;

$yzmUtil = new YZMUtil();
$yzm =$yzmUtil->getzcmAction( $DATA1);
// accesstoken

//$jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

// get accessToken
//$accessToken = $jssdk->getAccessToken();
$yzmUtil ->getNewTicket("o7XC90jGgVsu2ra0omYf2UY900Yo","9_pnwyajevBdGlYMa2gC7zAQSOfeBkpJv5ZVuPKkD50I2QswryQtqzagA84ZROeQ62UZDi68Hin0fP11b9-3dN0EkxHaVf4eEQzhP0Y4Lz0Ik2AQQ7Y2L6HqqWGf0FB_mCv9JoBh7ddyEk7eEcWAHbAIACGN",$yzm);

class YZMUtil {

    public function __construct() {

    }
//=========================================== 生成验证码 =========================================
    public function getzcmAction($DATA1) {

        $myrand= array(
            '0x96','0xD5','0xAC','0xC6','0x92','0xDB','0xF6','0x78','0xC0','0xE1','0x6D','0x52','0x9B','0x80','0xCB','0x24',
            '0x3C','0xA7','0x7C','0x4C','0x52','0x3C','0xFB','0x5D','0xA9','0x66','0xC1','0x0B','0xEF','0xD4','0x5F','0xDA',
            '0xDF','0xD3','0x57','0x89','0x45','0xF9','0x83','0x2C','0xD9','0x19','0x44','0x97','0x62','0xBD','0xE9','0x54',
            '0x9F','0xCC','0xA3','0x81','0x9D','0x39','0xFB','0x77','0xC8','0x2A','0x71','0xD7','0x91','0x15','0xC8','0xAA',
            '0x23','0x53','0xA0','0x85','0x0B','0x64','0xF5','0x20','0x76','0x9F','0x79','0xCF','0xC9','0xD6','0x52','0x73',
            '0xC3','0x62','0xA3','0x7C','0xD7','0xFB','0xC7','0x24','0x49','0xC6','0xE6','0x79','0x89','0x26','0xBC','0xF5',
            '0x1D','0x88','0xBF','0x9C','0x21','0xB9','0xB9','0xED','0xE3','0x68','0xE2','0x30','0xBF','0x95','0x56','0x23',
            '0x43','0xC5','0x2A','0xDE','0xBA','0x29','0xE2','0x67','0x9D','0xB3','0xE2','0x33','0x93','0xC9','0xA2','0x3D',
            '0x71','0x18','0x65','0x43','0xF1','0xAF','0x45','0xE7','0x5E','0x22','0x24','0x5E','0x53','0xED','0x34','0x9A',
            '0x75','0x49','0x56','0x63','0x69','0xA5','0xBD','0x43','0xDE','0xAA','0xD2','0xD7','0x5D','0x4B','0x82','0xBE',
            '0x91','0xDB','0xAD','0x9D','0xE8','0xDC','0xA3','0x33','0x8C','0x4F','0x76','0x9C','0xF5','0x23','0xF9','0x16',
            '0xD1','0xB2','0x1F','0xAF','0xEC','0x40','0xD9','0x4A','0x35','0x80','0x6B','0x57','0xF0','0x46','0xBE','0x13',
            '0xF0','0xEA','0x8C','0xAE','0x0F','0x9C','0x5A','0x8E','0xF6','0x94','0x78','0x32','0xE5','0x0B','0xEE','0xCD',
            '0xDE','0x42','0x60','0x0D','0xD2','0xD4','0x26','0x7F','0xF3','0x23','0xCF','0x47','0x66','0xDF','0x65','0x45',
            '0xA1','0x99','0xDF','0x71','0x0B','0xAF','0x75','0xB9','0x7C','0xAB','0x38','0x99','0x3D','0x4A','0x9F','0x8F',
            '0x2F','0x6B','0x86','0x2C','0xFF','0x97','0xD0','0x11','0xAF','0x4A','0x3E','0xCF','0x21','0x80','0x13','0x2A');

        $rand = rand(0,35);

        $caculate = array(0,0,0,0,0,0,0,0,0,0,0,0);
// rand  $rand
        $caculate[11] = 10;
        $DATA1 = $DATA1 *1;
//    DATA1 = 0;
        $DATA1 = $DATA1 + 10000000000000;
//   DATA1 = "20000100040002";
        $cs1 = $myrand[$caculate[11]];
        $deHex = hexdec($cs1);
        $DATA3 = $DATA1 * $deHex;

        $caculate[0] =  floor(($DATA3/pow(36, 10)));
        $caculate[1] =  floor(($DATA3%pow(36, 10)/pow(36, 9)));
        $caculate[2] =  floor(($DATA3%pow(36, 9)/pow(36, 8)));
        $caculate[3] =  floor(($DATA3%pow(36, 8)/pow(36, 7)));
        $caculate[4] =  floor(($DATA3%pow(36, 7)/pow(36, 6)));
        $caculate[5] =  floor(($DATA3%pow(36, 6)/pow(36, 5)));
        $caculate[6] =  floor(($DATA3%pow(36, 5)/pow(36, 4)));
        $caculate[7] =  floor(($DATA3%pow(36, 4)/pow(36, 3)));
        $caculate[8] =  floor(($DATA3%pow(36, 3)/pow(36, 2)));
        $caculate[9] =  floor(($DATA3%pow(36, 2)/pow(36, 1)));
        $caculate[10] = floor(($DATA3%pow(36, 1)/pow(36, 0)));

        $zf = array("0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z");
//alert(caculate);
        $return_data ="";
        for($j = 0;$j < count($caculate);$j++)
        {

            $return_data .= $zf[$caculate[$j]];
        }
        return 	$return_data;

    }

// =======================发送客服消息 ==================
    public function getNewTicket($wwOpenid,$accessTokenR,$contentStr){

//  echo $wwOpenid;
        echo $accessTokenR;

//  $jsonData2 = '{"kf_account": "GXKF@LongChuangDriveExam", "nickname": "共享考车客服", "password":"gongxiangkf"}';
        $jsonData2 = '{"touser":'."\"".$wwOpenid."\"".', "msgtype": "text", "text":{"content":'."\"".$contentStr."\"".'}}';

//echo '********';
        echo $jsonData2;
//echo '********';
//$jj = json_encode($jsonData2);
//$jsonData = "{'expire_seconds': 604800, 'action_name': 'QR_STR_SCENE', 'action_info': {'scene': {'scene_str': {$openidWW}}}}";
// $qrURL = "https://api.weixin.qq.com/customservice/kfaccount/add?access_token=$accessTokenR";
        $qrURL = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=$accessTokenR";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "$qrURL");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// 跟踪重定向属性
        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Expect:'));

        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData2 );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
        }

        curl_close($ch);

//echo $tmpInfo;
    }

}