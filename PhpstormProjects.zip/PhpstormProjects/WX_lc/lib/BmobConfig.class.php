<?php

/**
 * bmobConfig 配置文件
 * @author newjueqi

 * @license http://www.gnu.org/copyleft/lesser.html Distributed under the Lesser General Public License (LGPL)
 */
class BmobConfig
{
     const APPID = '70935608c3e10802d71ff99ba5c0e4ad';  //后台"应用密钥"中的Application ID
     const RESTKEY = '319e26040d6e57b68fbf98b972ba6f6e';  //后台"应用密钥"中的REST API Key
     const BMOBURL = 'https://api.bmob.cn/1/';  //请勿修改
     const BMOBURLTWO = 'https://api.bmob.cn/2/';  //请勿修改




}
