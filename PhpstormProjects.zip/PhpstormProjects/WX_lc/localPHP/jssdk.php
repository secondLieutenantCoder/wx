<?php

//include '../lib/BmobObject.class.php';
?>

<?php
//include_once (dirname(__FILE__)."../lib/BmobObject.class.php");
//include_once '../lib/BmobUser.class.php';
//include_once '../lib/BmobBatch.class.php';
//include_once '../lib/BmobFile.class.php';
//include_once '../lib/BmobImage.class.php';
//include_once '../lib/BmobRole.class.php';
//include_once '../lib/BmobPush.class.php';
//include_once '../lib/BmobPay.class.php';
//include_once '../lib/BmobSms.class.php';
//include_once '../lib/BmobApp.class.php';
//include_once '../lib/BmobSchemas.class.php';
//include_once '../lib/BmobTimestamp.class.php';
//include_once '../lib/BmobCloudCode.class.php';
//include_once '../lib/BmobBql.class.php';



class JSSDK {


  private $appId;
  private $appSecret;

  public function __construct($appId, $appSecret) {
    $this->appId = $appId;
    $this->appSecret = $appSecret;


  }

  public function getSignPackage() {
    $jsapiTicket = $this->getJsApiTicket();

    // 注意 URL 一定要动态获取，不能 hardcode.
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
    $url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
//    echo '|||||===='."$protocol".'||||==='."$_SERVER[HTTP_HOST]".'|||---'."$_SERVER[REQUEST_URI]";
    $timestamp = time();
    $nonceStr = $this->createNonceStr();

    // 这里参数的顺序要按照 key 值 ASCII 码升序排序
    $string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

    $signature = sha1($string);

    $signPackage = array(
      "appId"     => $this->appId,
      "nonceStr"  => $nonceStr,
      "timestamp" => $timestamp,
      "url"       => $url,
      "signature" => $signature,
      "rawString" => $string
    );
    return $signPackage;
  }

  private function createNonceStr($length = 16) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
      $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
  }

  // 获取 Ticket  本地存储
  private function getJsApiTicket() {
    // jsapi_ticket 应该全局存储与更新，以下代码以写入到文件中做示例
//    $data = json_decode($this->get_php_file("jsapi_ticket.php"));
    // 读文件内容

require "./lib/BmobObject.class.php";
      // 1.取bmob数据
      $bmobObj = new BmobObject("Time_limitData");
      $res = $bmobObj->get("",array('where={"namekey":"jsapi_ticket"}'));
      $res1 = $res->results;
//      echo '********'.json_encode($res);
      $data = $res1[0];
//      $expire = $res2->expire_time;
//      echo '=================';
//        echo $expire;
      $ticket = '';
    if ($data->expire_time < time()) {
        echo 'ticket过期';
      $accessToken = $this->getAccessToken();
      // 如果是企业号用以下 URL 获取 ticket
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=$accessToken";
      $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
      $res = json_decode($this->httpGet($url));
      $ticket = $res->ticket;
//      echo json_encode($res);
      if ($ticket) {
//        $data->expire_time = time() + 7000;
//        $data->jsapi_ticket = $ticket;
//        $this->set_php_file("jsapi_ticket.php", json_encode($data));
          $timestamp = time()+7000;
          $objID = $data->objectId;
    $resUpdatae  = $bmobObj->update($objID,array("value"=>"$ticket","expire_time"=>"$timestamp"));
    echo json_encode($resUpdatae);
    echo '========'.$objID;
    echo $ticket;

      }
    } else {
      $ticket = $data->value;
//echo '直接获取-未过期';
    }

    return $ticket;
  }
/** 获取 access——token */
  public function getAccessToken() {
    // access_token 应该全局存储与更新，以下代码以写入到文件中做示例
    //$data = json_decode($this->get_php_file("access_token.php"));
    // 旧方法，读取文件数据

//      require "./lib/BmobObject.class.php";
      // 1.取bmob数据
      $bmobObj = new BmobObject("Time_limitData");
      $res = $bmobObj->get("",array('where={"namekey":"access_token"}'));
      $res1 = $res->results;
//      echo '********'.json_encode($res);
      $datatoken = $res1[0];

    if ($datatoken->expire_time < time()) {
        echo 'token过期';
        echo '==    =='.$datatoken->expire_time;
        echo '==== ----'.time();
      // 如果是企业号用以下URL获取access_token
      // $url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=$this->appId&corpsecret=$this->appSecret";
      $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
      $res = json_decode($this->httpGet($url));
      $access_token = $res->access_token;
      if ($access_token) {
//        $data->expire_time = time() + 7000;
//        $data->access_token = $access_token;
//        $this->set_php_file("access_token.php", json_encode($data));

          $timestamp = time()+7000;
          $objID = $datatoken->objectId;
          $resUpdatae  = $bmobObj->update($objID,array("value"=>"$access_token","expire_time"=>"$timestamp"));
          echo json_encode($resUpdatae);
          echo '------'.$objID;
          echo $access_token;

      }
    } else {
      $access_token = $datatoken->value;
      echo '未过期-取bmob数据';
    }
    return $access_token;
  }

  private function httpGet($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 500);
    // 为保证第三方服务器与微信服务器之间数据传输的安全性，所有微信接口采用https方式调用，必须使用下面2行代码打开ssl安全校验。
    // 如果在部署过程中代码在此处验证失败，请到 http://curl.haxx.se/ca/cacert.pem 下载新的证书判别文件。
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 2);
    curl_setopt($curl,CURLOPT_CAPATH,'http://longchuangkeji.com/lcjg/exam/cacert.pem');
    curl_setopt($curl, CURLOPT_URL, $url);

    $res = curl_exec($curl);
    curl_close($curl);

    return $res;
  }

  private function get_php_file($filename) {
    return trim(substr(file_get_contents($filename), 15));
  }
  private function set_php_file($filename, $content) {
    $fp = fopen($filename, "w");
    fwrite($fp, "<?php exit();?>" . $content);
//    echo 'Content==='.$content;
    fclose($fp);
  }
}

