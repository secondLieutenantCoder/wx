<?php
//$a = '111111';
//



$authObj = new htmlAuth();
// 获取用户的 openID
$openid = $authObj->getWXAccesstoken();
//$wwTest = '000';

$authToken = $authObj->getToken();
var_dump($authObj);
// 拉取用户信息
$url="https://api.weixin.qq.com/sns/userinfo?access_token=$authToken&openid=$openid&lang=zh_CN";
$html = file_get_contents($url);
echo $html;
$d = date("Y/m/d").'  ----  '.date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d"))));
$t = strtotime($d);
$endTime=0;
if ($endTime < time()){
    // 过期
$endTime = 0;
}else{
$endTime = 1;

}
$isVIP= 0;
if ($endTime < time()){
    // 过期
    $isVIP = 0;
}else{
    // 木过期
    $isVIP = 1;
}

//var_dump()


class htmlAuth {

    var $token;
    public function __construct() {

    }

    function getToken (){

        return $this->token;
    }

    // ==================- 获取网页授权 access-token -=============
    public function getWXAccesstoken(){

        $authCode = $_GET['code'];
        $authState = $_GET['state'];

        $appID = "wx62732b3c3460b3b1";
        $appSecret = 'cc05112ee2e8f53d80970d0d988398cd';
//        $accessUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appID.'&secret='.$appSecret;
        $accessUrl = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appID.'&secret='.$appSecret.'&code='.$authCode.'&grant_type=authorization_code';

        $pageInfo  = file_get_contents($accessUrl);

        $infoObj   = json_decode($pageInfo);

        $token = $infoObj->access_token;
        echo '*****'.$token;
        $expireIn    = $infoObj->expires_in;
        $reat        = $infoObj->refresh_token;
        $scope       = $infoObj->scope;

        $opID = $infoObj->openid;


        return $opID;
    }//getWXAccessToken end
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>龙创交规</title>
</head>

<style>

 @media screen and (max-width: 500px) {

     #centerBtn{

         width: 30vw;
         height: 30vw;
         background: deepskyblue;
         top: 65px;
         left: 35%;
     }
     .titleMoney{

         width: 20vw;
         height: 20vw;
         color: gray;

         margin-left: 10vw;
         /*width: 25%;*/
         /*padding-bottom: 100%;*/

     }

     /*body{*/
        /*text-align: center;*/
         /*background-color: yellow;*/
     /*}*/

 }
 @media screen and (min-width: 500px) {

     #centerBtn{
         text-align: center;
         left: 38%;
         width:  130px;
         height: 130px;
         background: deepskyblue;
         top: 65px;
     }
     .titleMoney{

         width: 85px;
         height: 85px;
         color: white;
         /*width: 25%;*/
         /*padding-bottom: 100%;*/
     }
     #firCircle{

         margin-left: 145px;
     }
 }


    .title1{

        width: 19%;
        height: 30px;
        font-size: 10px;
        font-size-adjust: inherit;
        background: cornflowerblue;
    }
    .title1:active{

        color: white;
        background-color: lightskyblue;

    }

    /*sudo apachectl -k start    启动apache*/
    .fourItem{
        box-shadow: 1px 1px 3px  deepskyblue;
    }

    /*底部导航*/
 .nav {
     background: deepskyblue;
     padding: 10px 0 6px 0;
     width: 100%;
     position: fixed;
     left: 0;
     bottom: 0;
     /*z-index: 99;*/
 }
 .nav ul {
     height: 0;
 }
 .nav ul li {
     float: left;
     width: 33%;
     text-align: center;
     list-style-type: none;
     margin: 0;
     padding: 0;

 }
 .nav ul li span {
     display: block;
     color: black;
     font-size: 14px;
     /*font-family: "微软雅黑";*/
     line-height: 22px;
 }
 a {
     color: #000;
     text-decoration: none;
 }
 * {
     padding: 0;
     margin: 0;
     list-style: none;
     font-weight: normal;
 }

</style>

<body>


<!--<h1>服务号选择页面</h1>-->
<!--<h2> Apache 服务器 </h2>-->
<!--/Library/WebServer/Documents-->

<!--<button id="ct4" onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 5%;margin-top: 25px;color: white;font-size: 18px">错题练习</button>-->

<!--<button id="ct" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 20%;margin-top: 25px;color: white;font-size: 18px">错题练习</button>-->

<!--<button onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 20%;margin-top: 25px;color: white;font-size: 18px">11</button>-->

<div style="width: 100%; height: 270px; background: lightblue;">

    <button id="km1" class="title1" onclick="selectedFunc(this)" style=" border: saddlebrown;" value="xxxx">  科目一  </button>
    <button id="km4" class="title1" onclick="selectedFunc(this)" style="background: cornflowerblue;   border: yellow;">  科目四  </button>
    <button id="ctlx" class="title1" onclick="selectedFunc(this)" style="background: cornflowerblue;   border: goldenrod;"> 错题练习 </button>
    <button id="zxhf" class="title1" onclick="selectedFunc(this)" style="background: cornflowerblue;   border: whitesmoke;">注销恢复</button>
    <button id="zgz" class="title1" onclick="selectedFunc(this)" style="background: cornflowerblue;   border: whitesmoke;">  资格证  </button>



<!--分类-->
    <br>
    <hr>
    <div style="margin-left: 10%;float: left;width: 20%;">
        <img src="../imgs/icon3.png" alt="xxxxxx" style="width: 60px; height: 60px;position: relative;left: 20%;">
        <br>

        <label style="position: relative;left: 20%;top: -5px; width: 80px;height: 25px; background: whitesmoke; font-size: 10px; margin-top: 2px" >小车C1/C2/C3
        </label>
    </div>
    <div style="float: left;width: 20%;">
        <img src="../imgs/icon3.png" alt="xxxxxx" style="width: 60px; height: 60px;position: relative;left: 20%;">
        <br>

        <label style="position: relative; left: 20%;top: -5px;width: 80px;height: 25px; background: whitesmoke; font-size: 10px; margin-top: 2px" >货车A/B2
        </label>
    </div>
    <div style="float: left;width: 20%;">
        <img src="../imgs/icon3.png" alt="xxxxxx" style="width: 60px; height: 60px;position: relative;left: 20%;">
        <br>

        <label style="position: relative;left: 20%;top: -5px; width: 80px;height: 25px; background: whitesmoke; font-size: 10px; margin-top: 2px" >客车A1/A3/B1
        </label>
    </div>
    <div style="float: left;width: 20%;">
        <img src="../imgs/icon3.png" alt="xxxxxx" style="width: 60px; height: 60px;position: relative;left: 20%;">
        <br>

        <label style="position: relative;left: 20%;top: -5px;width: 80px;height: 25px; background: whitesmoke; font-size: 10px; margin-top: 2px" >摩托车D/E/F
        </label>
    </div>
    <!-- 权限 -->
<!--    <h1> --><?php // echo $nick;   ?><!-- </h1>-->
    <br>
    <!--width: 20%;height: 20vw;border-radius: 50%;-->
    <button id="firCircle" class="titleMoney" style=" margin-top: 20px;border-style: solid;float: left;border-radius: 50%;border-width: 15px; border-color: lightgreen;background-color: green; ">
        免费体验 </button>
    <button class="titleMoney" style="margin-top: 20px;border-style: solid;float: left;border-radius: 50%;  border-width: 15px; border-color: yellow; background: gold;"> 开通系统 </button>
    <button class="titleMoney" style="margin-top: 20px; border-style: solid; float: left; border-radius: 50%;  border-width: 15px; border-color: mistyrose;background: orangered;"> 分享好友 </button>

    <button style="width: 90px; height: 60px;border-radius: 30px">000000000</button>
</div>

<br>
<div style="position: relative;">

    <!--学习课程-->
<!--1-->
    <button onclick="regularTest()" class="fourItem"  style ="width: 40%;height: 90px; background-color: ghostwhite;margin-left: 5%;float: left; margin-top: 20px; border:sandybrown;">
        <img src="../imgs/icon3.png"  style="width: 30px; height: 30px;margin-top: -20px">
        <br>
        <label style="background: goldenrod;"> 分类学习 </label>
    </button>
<!--2-->
    <button onclick="temptTest()"  class="fourItem"  style="float: left;width: 40%;height: 90px; background-color: ghostwhite; margin-left: 10%;margin-top: 20px;border:sandybrown;">

        <img src="../imgs/icon3.png"  style="width: 30px; height: 30px;margin-top: -20px">
        <br>
        <label style="background: goldenrod;"> 模拟考试 </label>
    </button>
<!--3-->
    <button onclick="reAction()" class="fourItem" style=" float: left;width: 40%;height: 90px; background-color: ghostwhite;margin-left: 5%; margin-top: 20px;border:sandybrown;">

        <img src="../imgs/icon3.png"  style="width: 30px; height: 30px;margin-top: -20px">
        <br>
        <label style="background: goldenrod;"> 错题重做 </label>
    </button>
<!--4-->
    <button  class="fourItem" onclick="gradeAction()" style=" float: left;width: 40%;height: 90px; background-color: ghostwhite;margin-left: 10%; margin-top: 20px;border:sandybrown;">
        <img src="../imgs/icon3.png"  style="width: 30px; height: 30px;margin-top: -20px">
        <br>
        <label style="background: goldenrod;"> 模拟成绩 </label>
    </button>
    <br>
    <button  id="centerBtn" onclick="centerAction()" style="border-style:solid; border-color: lightcyan;font-weight: bold;color: white;border-width: 10px;border-radius: 50%; position: absolute; "> 顺序练习 </button>
</div>

<!--底部导航-->
<div class="nav">
    <ul>

        <li onclick="previousAction()">
            <a href="#"><span><img src="../imgs/icon3.png" height="20"></span><span>公司客服 <?php echo $openid ?></span></a>
        </li>
        <li style="position:relative;" onclick="changePic1()">
            <a href="#"><span><img src="../imgs/icon3.png" height="20"></span><span>后台管理</span></a>
        </li>
        <li onclick="changePic2()">
            <!--<audio src=".../imgs/jiao"></audio>-->

            <a href="#"><span><img src="../imgs/icon3.png" height="20"></span><span>我的订单</span></a>
        </li>

    </ul>
</div>


</body>
<script>



    var isVIP = <?php echo "$isVIP"; ?>;

    if (isVIP === 1){

// JSON.stringify()

    }else {


    }

    var currentOpenID = <?php echo $openid; ?>;
    localStorage.setItem('currentOpenID',currentOpenID);

  //  var currentOpenID = localStorage.getItem('currentOpenID');


    // 获取网页授权信息
    localStorage.setItem('openid','<?php echo $openid; ?>');
</script>

<script language="JavaScript" type="text/javascript">
/// 弹窗
    function clickFunction() {
        alert("点击按钮");
    }
    /// 跳转
    function goNextFunc() {

        window.location.href='index.html';
    }

    /// 后退
    function backFunc() {

        history.back();
    }
    
    // button的选中效果
    function selectedFunc(a) {

        var b1 = document.getElementById('km1');
        var b2 = document.getElementById('km4');
        var b3 = document.getElementById('ctlx');
        var b4 = document.getElementById('zxhf');
        var b5 = document.getElementById('zgz');
        b1.style.color = 'black';
        b2.style.color = 'black';
        b3.style.color = 'black';
        b4.style.color = 'black';
        b5.style.color = 'black';

        b1.style.backgroundColor = 'cornflowerblue';
        b2.style.backgroundColor = 'cornflowerblue';
        b3.style.backgroundColor = 'cornflowerblue';
        b4.style.backgroundColor = 'cornflowerblue';
        b5.style.backgroundColor = 'cornflowerblue';

        a.style.backgroundColor = 'blue';
        a.style.color = 'white';

      //  alert(a.value);
        // alert(a.value);
    }
    // 分类学习
    function regularTest() {
        window.location.assign("./xuanze/chooseWithPic.html"+'?'+'p1='+'regular'+'&'+'p2='+'sick');
    }
    // 模拟考试
    function temptTest() {
        alert('模拟考试');
    }

    // 错题重做
function reAction() {
    alert('错题重做');
    // location.href = "share.php?openid=$openid";

}

    // 模拟成绩
    function gradeAction() {
        alert('模拟成绩');
    }

    // 中间圆形按钮
    function centerAction() {

        // window.open('detailClass.html');
        window.location.href = 'detailClass.html';
    }


</script>

</html>


