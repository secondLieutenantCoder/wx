<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/3/10
 * Time: 10:09
 */

/*
require_once "./lib/BmobObject.class.php";
require_once './lib/BmobBql.class.php';

$bmobBql = new BmobBql();

$res = $bmobBql->query(array('bql=select * from WX_question where type2=1'));

var_dump($res);
*/
// wxResource/bmobPhpSdk/
require_once 'lib/BmobBql.class.php';
$bmobBqlX = new BmobBql();
// SELECT * FROM T_USER  ORDER BY  RAND() LIMIT 10
// select * from WX_question where type2='860' limit 2
//  select top N * from tableName order by newid()
// select  top  10  *  from  表  order  by  newid()
// SELECT * FROM `table` AS t1 JOIN (SELECT ROUND(RAND() * (SELECT MAX(id) FROM `table`)) AS id) AS t2
// WHERE t1.id >= t2.id
//ORDER BY t1.id ASC LIMIT 5
// SELECT top 1 * FROM [tablename]
//  where id>=(select max(*) from tablename)*rand()
$res = $bmobBqlX->query(array('bql'=>"SELECT * FROM WX_question  where type2 = '853' or type2 ='855' or type2 ='856' or type2 ='857' or type2 ='858' or type2 ='862' or type2 ='863' or type2 ='864' or type2 = '868' limit 1000 "));

$totalArray = $res->results;
// 40 个随机索引
$tmpArray = array_rand($totalArray,40);

// var_dump($tmpArray);
// 取出的40道题目
$wxRes = array();
foreach ($tmpArray as $index){

    array_push($wxRes,$totalArray[$index]);

}

// 取出10道多选题目
$bmobTen = new BmobBql();
$resTen = $bmobTen->query(array('bql'=>"SELECT * FROM WX_question  where type2 = '860' limit 1000"));
$totalTenArray = $resTen->results;
$tmpTen = array_rand($totalTenArray,10);
//$wxTen = array();
foreach ($tmpTen as $tenIndex){
    array_push($wxRes,$totalTenArray[$tenIndex]);
}
//var_dump($wxRes);
//var_dump($tmpArray);
$jsonData = json_encode($wxRes);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>龙创交规 </title>
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <!--<script type="text/javascript" src="../bmob_jssdk/bmob-min.js"></script>-->
    <!--<script type="text/javascript" src="../bmob_jssdk/bmob.js"></script>-->
    <script type="text/javascript" src="wxResource/bmob_jssdk/jquery.min.js"></script>
    <script type="text/javascript" src="wxResource/bmob_jssdk/bmob.js"></script>



    <link rel="stylesheet" type="text/css" href="thirdHelp/tanchuang/css/jquery.my-modal.1.1.winStyle.css" />
</head>

<!--引入jQuery库-->
<script src="http://www.jq22.com/jquery/jquery-1.10.2.js"></script>
<!--引入本地的jQuery文件-->
<script type="text/javascript" src="thirdHelp/tanchuang/js/jquery.my-modal.1.1.js"></script>

<style>

    .nav {
        background: lightskyblue;
        padding: 10px 0 6px 0;
        width: 100%;
        position: fixed;
        left: 0;
        bottom: 0;
        /*z-index: 99;*/
    }
    .nav ul {
        height: 0;
    }
    .nav ul li {
        float: left;
        width: 20%;
        text-align: center;
        list-style-type: none;
        margin: 0;
        padding: 0;

    }
    .nav ul li span {
        display: block;
        color: black;
        font-size: 14px;
        /*font-family: "微软雅黑";*/
        line-height: 22px;
    }
    a {
        color: #000;
        text-decoration: none;
    }
    * {
        padding: 0;
        margin: 0;
        list-style: none;
        font-weight: normal;
    }
    .content{

        /*margin: 0 auto;*/
        bottom: 35px;

    }
    a:hover{text-decoration:underline;color:#227bd6;}
    .item{

        padding: 5px;
        width  : 100%;
        /*font-size: 16px;*/
    }
    .index{
        /*A B C D样式*/
        width: 23px;
        height: 23px;
        border-radius: 50%;
        border-width: 0.5px;
        border-style: solid;
        text-align: center;
        font-size: 15px;
        /*background: ;*/
    }
    #yy{
        color: orangered;
        font-size: 15px;
        font-weight: bold;
    }


</style>

<body onload="loadData()">

<div>
    <button onclick="submitAction()" style="width: 30%; height: 30px; background: lightskyblue; color: white; float: right;border-radius: 5px;border: wheat;margin-right: 3px;margin-top: 3px">交卷</button>
    <button id="time" style="width: 30%;height: 30px;color: white;background: lightskyblue;border: gainsboro; float: right;border-radius: 5px; margin-right: 5px;margin-top: 3px;" >考试计时</button>
</div>

<div class="content" style="width: 100%;height: auto;background-color: ghostwhite">

    <br>
    <!-- 隐藏横向滚动条  overflow-x: hidden  -->
    <div id="scrollContent" style="margin-top: 20px;width: 100%; position: relative;overflow: auto;overflow-x: hidden;overflow-y: inherit">
        <div style="padding-left: 5px;"><label id="qIndex">1</label>. <button id="wwtype" style="border-width: 1px;width: 50px;height: 20px;border-color: gray;border-style: solid;border-radius: 5px;padding: 2px;"> 选择题 </button><label id="question"></label> </div>
        <br>
        <br>
        <a><img id="mainPic" style="margin-left: 20%;width: 60%;" ></a>
        <br>
        <div onclick="answerAction(this)" id="A" class="item"><button class="index" id="aItem">A</button><label id="aaa" > </label></div>

        <div onclick="answerAction(this)" id="B" class="item"><button class="index" id="bItem">B</button><label id="bbb" > </label></div>

        <div onclick="answerAction(this)" id="C" class="item"><button class="index" id="cItem">C</button><label id="ccc" >  </label></div>

        <div onclick="answerAction(this)" id="D" class="item"><button class="index" id="dItem">D</button><label id="ddd" > </label></div>

    </div>
    <!--controls="controls"-->
    <audio id="tip">
        <source src="./test.mp3" type="audio/mp3">
    </audio>
    <audio id="hc">
        <source src="" type="audio/mp3" >
    </audio>

</div>
<!--底部导航栏-->
<div class="nav">
    <ul>

        <li onclick="previousAction()">
            <a href="#"><span><img src="wxResource/imgs/pre.png" height="20"></span><span style="color: white;">上一题<?php echo '000' ?></span></a>
        </li>
        <li style="position:relative;" onclick="createPrompt()">
            <a href="#"><span><img src="wxResource/imgs/detail.png" height="20"></span><span id="testIndex" style="color: white;">1/100</span></a>
        </li>
        <li onclick="yyAction()">
            <!--<audio src=".../imgs/jiao"></audio>-->

            <a href="#"><span><img src="wxResource/imgs/yy.png" height="20"></span><span id="yy">技巧讲解</span></a>
        </li>
        <li onclick="helpTipsAction()">
            <a href="#"><span><img src="wxResource/imgs/help.png" height="20"></span><span style="color: white;">帮助</span></a>
        </li>
        <li onclick="nextAction()">
            <a href="#"><span><img src="wxResource/imgs/next.png" height="20"></span><span style="color: white;">下一题</span></a>
        </li>
    </ul>
</div>

<!--
        	描述：下面为模板
        -->
<div class="m-modal">
    <div class="m-modal-dialog">
        <div class="m-top">
            <h4 class="m-modal-title" style="font-size: 15px">
                龙创交规
            </h4>
            <span class="m-modal-close">&times;</span>
        </div>
        <div class="m-middle">
            <!--content-->
            <p id="nnn">红灯停jQuery是一个快速、简洁的JavaScript框架，是继Prototype之后又一个优秀的JavaScript代码库（或JavaScript框架）。jQuery设计的宗旨是“write Less，Do More”，即倡导写更少的代码，做更多的事情。它封装JavaScript常用的功能代码，提供一种简便的JavaScript设计模式，优化HTML文档操作、事件处理、动画设计和Ajax交互。</p>
            <img hidden="true" id='explainPic' style="width:100%;height:100%" src ='http://bmob-cdn-216.b0.upaiyun.com/2017/07/14/d120602940604fd280a600ab37e6dff4.jpg'>
        </div>
        <div class="m-bottom">
            <button class="m-btn-sure">确定</button>
            <!--<button class="m-btn-cancel">取消</button>-->
        </div>
    </div>
</div>

<script>
    var jiaojuan = 1;
    var m1 = new MyModal.modal(function() {
        // alert("你点击了确定");
        if(jiaojuan === 1){
            //    location.reload();
            // location.href = (-1);
            history.back();
            jiaojuan = 0;
        }
    });
    $('.btn1').on("click", function() {
        m1.show();
    });

    function selfAction(msg) {
        var n6 = document.getElementById('nnn');
//alert(msg);
        n6.innerHTML = msg;
        m1.show();
    }
</script>

<script type="text/javascript">

    // var sc = document.getElementById('scrollContent');
    // sc.style.height = "100%-50px";

    // 记录多选题 的 答案值 = 1 2 4 8 => 3 6 9 7 5 ... 15
    var multiAnswer = 0;

    var isReload; // 是否刷新界面
    // xxxwangwei 4c2f5fe1bcd717a9232981343a8b8b8e  6a3852634b7483a097d837d49b847c0c
    Bmob.initialize("70935608c3e10802d71ff99ba5c0e4ad","319e26040d6e57b68fbf98b972ba6f6e");

    // 建立数组，记录答题的对错情况
    var myAnswers = [];
    // 页面加载的时候读取数据
    function loadData() {

        // alert('---------1---------');
        var questions = <?php echo $jsonData; ?>;
//  alert('----2------------');
        //    var jsQues = quesions.toArray();
//       alert(questions);
        //      alert(questions.length);
//alert(questions[0]);
        var fq = questions[0];
//        alert('fq'+fq);

// alert(JSON.stringify(questions));
//        alert(JSON.stringify(fq));
//  alert(fq.title);
//alert('==========');

//alert(fq);
        //  alert('title');
        //  alert("bmob");
        //   alert("共查询到 " + results.length + " 条记录");
        //   alert('创建成功');
        totalCount = questions.length;
        // alert(totalCount);
        var i;
        for (i = 0;i< questions.length;i++){

            var obj = questions[i];
            var j = i+1;

            // alert(results.length);
            //              alert(obj);
            //              alert(JSON.stringify(obj));
            // 题干
            localStorage.setItem('questionTitleC'+j,obj.title);
            //   alert(obj.get('title'));
            // 是不是选择题
            // alert(j);
            localStorage.setItem('title_typeC'+j,obj.titleType);
            // 选项
            //localStorage.setItem('item'+j,obj.get('chooseItem'));
//alert('============');
            //     alert(obj.titleType);

//alert('============');
            if (obj.titleType=== '1'){
                localStorage.setItem('answer_aC'+j,"对");
                localStorage.setItem('answer_bC'+j,"错");
                localStorage.setItem('answer_cC'+j,"111");
                localStorage.setItem('answer_dC'+j,"222");

            }
            if (obj.titleType=== '0'){
                //    alert('answer1');
                //     alert(obj.answer1);
                localStorage.setItem('answer_aC'+j,obj.answer1);
                localStorage.setItem('answer_bC'+j,obj.answer2);
                localStorage.setItem('answer_cC'+j,obj.answer3);
                localStorage.setItem('answer_dC'+j,obj.answer4);

            }
            if (obj.titleType === '2'){

                localStorage.setItem('answer_aC'+j,obj.answer1);
                localStorage.setItem('answer_bC'+j,obj.answer2);
                localStorage.setItem('answer_cC'+j,obj.answer3);
                localStorage.setItem('answer_dC'+j,obj.answer4);

            }


            // 图片
            var picFile = obj.mainPic;
            //     alert(JSON.stringify(picFile));
            var sss = JSON.stringify(picFile);
//alert('图片分析');
            //               alert(sss);

            if (sss === undefined){

                //           alert('uuuuuu');
                localStorage.setItem('picC'+j,'111');
            }else {

                // 如果有图片再重新赋值
                if (picFile.url.length > 10){
                    //               alert('取到图片');
                    localStorage.setItem('picC'+j,picFile.url);

                }
            }
            // 答案
            //    alert('11111');
            //     alert(picFile);
            // 先全部给到无图片时的值
            // ===========-提示图片-===============
            // var skillPic = obj.get('explain_picture');
            //
            // var explain = JSON.stringify(skillPic);
            // if (explain === undefined){
            //
            //     localStorage.setItem('explainPic'+j,'111');
            // }else {
            //
            //     if (skillPic._url.length>10){
            //
            //         localStorage.setItem('explainPic'+j,skillPic._url);
            //     }
            // }

            // alert(picFile._url);
            localStorage.setItem('answerC'+j ,obj.answer);
            // 是否多选
            // localStorage.setItem('isDuoXuan'+j ,obj.get('isDuoXuan'));
            // 答题提示
            localStorage.setItem('explainC'+j,obj.explain);
            // alert('img'+j);
            if (i === 0){
                nextAction();

            }

        }

        // nextAction();
        // 答题状态 0 未答  1 答对 2 打错
        // 初始值 全部赋值 0 未答
        for (var a=0;a<totalCount;a++){
            myAnswers[a] = "0";
//alert('---------');

        }
//alert('===myAnswer===');
        // 当前答道第几道题目
        var ti = document.getElementById('testIndex');
        ti.innerHTML = '1/'+totalCount;
        //    alert(myAnswers);

        // alert('next');


        // 设置答题区 frame
        // var content = document.getElementsByClassName('content');
        // var sh = document.body.offsetHeight;
        // alert(sh);
        // content.style.height = sh-35+'px';
        // alert('xxx');

        // 页面跳转信息
        /*
        var furl = location.href;
        var pStr = furl.split('?')[1];
        var ps1 = pStr.split('&')[0];
        var ps2 = pStr.split('&')[1];

        var p1 = ps1.split('=')[1];
        var p2 = ps2.split('=')[1];

        //    alert(p1+p2);
*/
    }
</script>

</body>

<script>

    var index = 0;
    var  totalCount;
    var isNext;


    function goToPage() {
        window.location.href = 'noPic.html';
    }


    function changePic1() {
        var pic = document.getElementById('mainPic');
        // pic.src = 'http://5b0988e595225.cdn.sohucs.com/images/20180111/bef578dea7e44070b3b7b873cd9f83ae.jpeg';

        var freeStr = localStorage.getItem('free');
        var objs =  freeStr.toArray();
        pic.src   = objs.get('imagURL');
        //     alert('cccccc');
    }
    function changePic2() {

        var a = document.getElementById('tip');
        a.play();

        var pic = document.getElementById('mainPic');
        pic.src = 'http://5b0988e595225.cdn.sohucs.com/images/20180111/e30025124ee642acbb452534a9c82ea3.jpeg';
        //  pic.hidden = true;

    }
    var totalTime = 2700;
    // 计时器
    var timer = setInterval(function (){timerAction()} ,1000);
    // 1s 执行一次
    function timerAction() {
        totalTime --;
        var t = document.getElementById('time');
        if (totalTime<=0){

            t.innerHTML = '00 : 00';
            alert('时间到，考试结束');

            clearInterval(timer);
        }else {
            //var d = new Date();
            //var t = d.toLocaleDateString();
            var min = parseInt(totalTime/60);
            var sec = totalTime%60;
            min = min<10?('0'+min):min;
            sec = sec<10?('0'+sec):sec;
            t.innerHTML = min +' '+':'+' '+sec;
        }

    }
    // 语音播报提示信息
    function yyAction() {

        //  alert('xxx');
        //  window.location.href = 'examDetail.html';
        // window.navigate("examDetail.html");
        //  window.location.href = '../examDetail.html';
        // window.open('./examDetail.html');
        // localStorage.setItem('seeDetail','1');
        // this -> createPrompt();

        // 显示技巧图片
        var  ppic = document.getElementById('explainPic');
        //     ppic.hidden = false;
        //防止页面不正常刷新
        jiaojuan = 0;
        var ad1 = document.getElementById('hc');
        ad1.src = 'audio.mp3';
        ad1.play();

//explainPic
        var  ePic = document.getElementById('explainPic');
        var  pUrl = localStorage.getItem('explainPic'+index);

        ePic.src = pUrl;
        var tip = localStorage.getItem('explainC'+index);
        //   alert(tip);
        selfAction(tip);

    }
    // 帮助
    function helpTipsAction() {
        // 显示技巧图片
        var  ppic = document.getElementById('explainPic');
        //   ppic.hidden = false;
//防止页面不正常刷新
        jiaojuan = 0;
        var tip = localStorage.getItem('explainC'+index);
        //   alert(tip);
        selfAction(tip);
    }

    //上一题
    function previousAction() {

        var ad1 = document.getElementById('hc');

        ad1.pause();

// alert('index');
        if (index>1){
            index--;
            //     alert(index+'==--------==');
            var ques = document.getElementById('question');
            ques.innerHTML = localStorage.getItem("questionTitleC"+index);

            var qIndex = document.getElementById('qIndex');
            qIndex.innerHTML = index;

            // var itemStr =   localStorage.getItem('item'+index);

            // var items = itemStr.split("#");
            // document.getElementById('aaa').innerHTML =' : '+ items[0];
            // document.getElementById('bbb').innerHTML =' : '+ items[1];
            // document.getElementById('ccc').innerHTML =' : '+ items[2];
            // document.getElementById('ddd').innerHTML =' : '+ items[3];

            var pic = document.getElementById('mainPic');
            var title_type = localStorage.getItem('title_typeC'+index);
            var cItem = document.getElementById('ccc');
            var dItem = document.getElementById('ddd');
            var t = document.getElementById('wwtype');
            // C D
            var C = document.getElementById('cItem');
            var D = document.getElementById('dItem');
            // 图片路径
            var imgurl = localStorage.getItem('picC'+index);
            if (imgurl.length >10){

                pic.hidden = false;
                pic.src = imgurl;
            }else {
                pic.hidden = true;
            }
//   alert(title_type+'------------');
            // 判断题目类型
            if (title_type === '0'){
                // alert('赋值选择题');
                // pic.hidden = false;
                cItem.hidden = false;
                dItem.hidden = false;
                C.hidden     = false;
                D.hidden     = false;
                t.innerHTML = '选择题';
                document.getElementById('aaa').innerHTML =' : '+ localStorage.getItem('answer_aC'+index);
                document.getElementById('bbb').innerHTML =' : '+ localStorage.getItem('answer_bC'+index);
                document.getElementById('ccc').innerHTML =' : '+ localStorage.getItem('answer_cC'+index);
                document.getElementById('ddd').innerHTML =' : '+ localStorage.getItem('answer_dC'+index);

            }
            if (title_type === '1'){
                // alert('判断');
                // pic.hidden = true;
                cItem.hidden = true;
                dItem.hidden = true;
                C.hidden     = true;
                D.hidden     = true;
                t.innerHTML = '判断题';
                document.getElementById('aaa').innerHTML =' : '+ localStorage.getItem('answer_aC'+index);
                document.getElementById('bbb').innerHTML =' : '+ localStorage.getItem('answer_bC'+index);
                // document.getElementById('ccc').innerHTML =' : '+ localStorage.getItem('answer_c'+index);
                // document.getElementById('ddd').innerHTML =' : '+ localStorage.getItem('answer_d'+index);
            }
            if (title_type === '2'){
                cItem.hidden = false;
                dItem.hidden = false;
                C.hidden     = false;
                D.hidden     = false;
                t.innerHTML = '多选题';
                document.getElementById('aaa').innerHTML =' : '+ localStorage.getItem('answer_aC'+index);
                document.getElementById('bbb').innerHTML =' : '+ localStorage.getItem('answer_bC'+index);
                document.getElementById('ccc').innerHTML =' : '+ localStorage.getItem('answer_cC'+index);
                document.getElementById('ddd').innerHTML =' : '+ localStorage.getItem('answer_dC'+index);
            }
            //    alert(localStorage.getItem("question"+index));
            // index --;
        }else {

            // index ++;
            alert('这是第一道题');
        }
        //  alert('666666666');
        //恢复选项的状态
        var AD = document.getElementById('A');
        var BD = document.getElementById('B');
        var CD = document.getElementById('C');
        var DD = document.getElementById('D');
        var A = document.getElementById('aItem');
        var B = document.getElementById('bItem');
        AD.style.backgroundColor = 'ghostwhite';
        BD.style.backgroundColor = 'ghostwhite';
        CD.style.backgroundColor = 'ghostwhite';
        DD.style.backgroundColor = 'ghostwhite';

        A.style.color = 'black';
        A.style.backgroundColor = 'white';
        A.innerHTML = 'A';
        B.style.color = 'black';
        B.style.backgroundColor = 'white';
        B.innerHTML = 'B';
        C.style.color = 'black';
        C.style.backgroundColor = 'white';
        C.innerHTML = 'C';
        D.style.color = 'black';
        D.style.backgroundColor = 'white';
        D.innerHTML  = 'D';

        //            alert('77777777777');
        // 当前答道哪一题
        var ti = document.getElementById('testIndex');
        ti.innerHTML = index+'/'+totalCount;

        var tex = localStorage.getItem('explainC'+index);
        // var tex = '对赫罗纳的比赛，梅西、苏亚雷斯乃至库蒂尼奥都成为了令人瞩目的主角，这几位球员都取得了进球';
        // var eTex = encodeURI(tex);
        // document.write(eTex);
        var url = "./testDeal.php?tex="+tex;
        $.get(url,function(data,status){
            // alert('77777777777');
            //     alert("数据: " + data + "\n状态: " + status);

        });
        //     alert('success');
    }
    // 下一题
    function nextAction() {

        var A = document.getElementById('aItem');
        var B = document.getElementById('bItem');
        var C = document.getElementById('cItem');
        var D = document.getElementById('dItem');

        // 题目类型 1判断 0选择 2多选
        var title_typeWW = localStorage.getItem('title_typeC'+index);

//alert(title_typeWW+'newTitleType');


        if (title_typeWW === '2' ){
            //    alert(index+'=yyyyyyyyyyyyyyyyyyyyy=');
            // 多选题 在点击下一题的时候 判断题目对错
            var ans = localStorage.getItem('answerC'+index);
            if (multiAnswer === 0){
                // 下一题

            }else {
                // 判断是否选择正确
                if (multiAnswer === ans){
                    // 记录答题结果正确
                    myAnswers[index-1] = 1;
                }else {
                    // 记录本题答题错误
                    myAnswers[index-1] = 2;
                }


                switch(ans)
                {
                    // 1 2 4 8
                    // 3 5 6 ,7 9 10, 11 12 13, 14 15
                    case '3':
                        // ab
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        break;
                    case '5':
                        // aC
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        break;
                    case '6':
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        break;
                    case '7':
                        // ABC
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        break;
                    case '9':
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        break;
                    case '10':
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        break;
                    case '11':
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        break;
                    case '12':
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        break;
                    case '13':
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        break;
                    case '14':
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        break;
                    case '15':
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        break;
                    default:
                        break;
                }
                multiAnswer = 0;
                return;
            }
        }
// alert(index+'====--------===');
//--------------------====================

        var ad1 = document.getElementById('hc');
        ad1.pause();

        // var s = document.getElementById('ss');
        //   s.play();
        //  var pic = document.getElementById('mainPic');
        //  pic.src = 'http://5b0988e595225.cdn.sohucs.com/images/20180111/7c9dd8972ee047c193131bf843b34ec1.jpeg';
        //
        //     alert('index');
        if (index<totalCount){

            index ++;
// alert(index+'ppppppppp');
            var ques = document.getElementById('question');
            ques.innerHTML = localStorage.getItem("questionTitleC"+index);
            //  alert(localStorage.getItem('questionTitleC'+index));
            var qIndex = document.getElementById('qIndex');
            qIndex.innerHTML = index;

            // var itemStr =   localStorage.getItem('item'+index);

            // var items = itemStr.split("#");


            var pic = document.getElementById('mainPic');
            // 题目类型 1判断 0选择 2多选
            var title_type = localStorage.getItem('title_typeC'+index);
            var cItem = document.getElementById('ccc');
            var dItem = document.getElementById('ddd');
            var t = document.getElementById('wwtype');
            // C D
            //  var C = document.getElementById('cItem');
            //   var D = document.getElementById('dItem');
            //图片地址
            var imgurl = localStorage.getItem('picC'+index);
            //   alert("index");
            if (imgurl.length >10){
// alert('有图片');
                pic.hidden = false;
                pic.src = imgurl;
                //  alert("图片显示"+imgurl);
            }else {
                // alert('无图片');
                pic.hidden = true;
            }

            // 判断题目类型
            if (title_type === '0'){
                // alert('赋值选择题');
                // pic.hidden = false;
                cItem.hidden = false;
                dItem.hidden = false;
                C.hidden     = false;
                D.hidden     = false;
                t.innerHTML = '选择题';
                document.getElementById('aaa').innerHTML =' : '+ localStorage.getItem('answer_aC'+index);
                document.getElementById('bbb').innerHTML =' : '+ localStorage.getItem('answer_bC'+index);
                document.getElementById('ccc').innerHTML =' : '+ localStorage.getItem('answer_cC'+index);
                document.getElementById('ddd').innerHTML =' : '+ localStorage.getItem('answer_dC'+index);
//alert(localStorage.getItem('answer_aC'+index));

            }
            if (title_type === '2'){

                //     alert('多选题');
                cItem.hidden = false;
                dItem.hidden = false;
                C.hidden     = false;
                D.hidden     = false;
                t.innerHTML = '多选题';
                document.getElementById('aaa').innerHTML =' : '+ localStorage.getItem('answer_aC'+index);
                document.getElementById('bbb').innerHTML =' : '+ localStorage.getItem('answer_bC'+index);
                document.getElementById('ccc').innerHTML =' : '+ localStorage.getItem('answer_cC'+index);
                document.getElementById('ddd').innerHTML =' : '+ localStorage.getItem('answer_dC'+index);
            }
            if (title_type === '1'){
                // alert('判断');
                // pic.hidden = true;
                cItem.hidden = true;
                dItem.hidden = true;
                C.hidden     = true;
                D.hidden     = true;
                t.innerHTML = '判断题';
                document.getElementById('aaa').innerHTML =' : '+ localStorage.getItem('answer_aC'+index);
                document.getElementById('bbb').innerHTML =' : '+ localStorage.getItem('answer_bC'+index);
                // document.getElementById('ccc').innerHTML =' : '+ localStorage.getItem('answer_c'+index);
                // document.getElementById('ddd').innerHTML =' : '+ localStorage.getItem('answer_d'+index);
            }
            //    alert(localStorage.getItem("question"+index));


        }else {
            // index --;
            alert('这是最后一道题了');
        }
        //恢复选项的状态
        var AD = document.getElementById('A');
        var BD = document.getElementById('B');
        var CD = document.getElementById('C');
        var DD = document.getElementById('D');
        //    var A = document.getElementById('aItem');
        //    var B = document.getElementById('bItem');
        AD.style.backgroundColor = 'ghostwhite';
        BD.style.backgroundColor = 'ghostwhite';
        CD.style.backgroundColor = 'ghostwhite';
        DD.style.backgroundColor = 'ghostwhite';

        A.style.color = 'black';
        A.style.backgroundColor = 'white';
        A.innerHTML = 'A';
        B.style.color = 'black';
        B.style.backgroundColor = 'white';
        B.innerHTML = 'B';
        C.style.color = 'black';
        C.style.backgroundColor = 'white';
        C.innerHTML = 'C';
        D.style.color = 'black';
        D.style.backgroundColor = 'white';
        D.innerHTML  = 'D';
        // 当前答道哪一题
        var ti = document.getElementById('testIndex');
        ti.innerHTML = index+'/'+totalCount;


        var tex = localStorage.getItem('explainC'+index);
        // var tex = '对赫罗纳的比赛，梅西、苏亚雷斯乃至库蒂尼奥都成为了令人瞩目的主角，这几位球员都取得了进球';
        // var eTex = encodeURI(tex);
        // document.write(eTex);
        var url = "./testDeal.php?tex="+tex;
        $.get(url,function(data,status){
            // alert('77777777777');
            //      alert("数据: " + data + "\n状态: " + status);

        });
        //    alert('success');
    }


    // 选中答案
    function answerAction(sItem) {
        // 1.判断选项对错  2.对、错选项显示

        var aI = document.getElementById('aaa');
        var bI = document.getElementById('bbb');
        var cI = document.getElementById('ccc');
        var dI = document.getElementById('ddd');

        sItem.style.backgroundColor = 'lightskyblue';

        var A = document.getElementById('aItem');
        var B = document.getElementById('bItem');
        var C = document.getElementById('cItem');
        var D = document.getElementById('dItem');

        var picked = sItem.getAttribute('id');
        var ans = localStorage.getItem('answerC'+index);
//========================================

// 题目类型 1判断 0选择 2多选
        var title_type = localStorage.getItem('title_typeC'+index);
        if (title_type === '2'){
            // 多选
            switch(picked)
            {
                case 'A':
                    //   alert('a'+'。。'+ans);
                    multiAnswer +=1;

                    break;
                case 'B':
                    //  alert('b');
                    multiAnswer+=2;

                    break;
                case 'C':
                    //  alert('c');
                    multiAnswer+=4;

                    break;
                case 'D':
                    //  alert('d');
                    multiAnswer+=8;

                    break;
                default:
            }// 记录答案累加值


        }else {

            switch(picked)
            {
                case 'A':
                    //   alert('a'+'。。'+ans);
                    if ('1' === ans || '16' === ans){
                        //       alert('cccc');
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';
                        myAnswers[index-1] = 1;
                    }else {

                        A.innerHTML = 'X';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'red';
                        myAnswers[index-1] = 2;
                    }


                    break;
                case 'B':
                    //  alert('b');
                    if ('2' === ans || '17' === ans){

                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';
                        myAnswers[index-1] = 1;
                    }else {

                        B.innerHTML = 'X';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'red';
                        myAnswers[index-1] = 2;
                    }

                    break;
                case 'C':
                    //  alert('c');
                    if ('4' === ans){
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';
                        myAnswers[index-1] = 1;

                    }else {
                        C.innerHTML = 'X';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'red';
                        myAnswers[index-1] = 2;
                    }

                    break;
                case 'D':
                    //  alert('d');
                    if ('8' === ans){

                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';
                        myAnswers[index-1] = 1;

                    }else {

                        D.innerHTML = 'X';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'red';
                        myAnswers[index-1] = 2;
                    }

                    break;
                default:
            }

            switch(ans)
            {
                case '1':
                    // alert('a');
                    A.innerHTML = '√';
                    A.style.color = 'white';
                    A.style.backgroundColor = 'green';

                    break;
                case '2':
                    //  alert('b');
                    B.innerHTML = '√';
                    B.style.color = 'white';
                    B.style.backgroundColor = 'green';

                    break;
                case '4':
                    //  alert('c');
                    C.innerHTML = '√';
                    C.style.color = 'white';
                    C.style.backgroundColor = 'green';

                    break;
                case '8':
                    //  alert('d');
                    D.innerHTML = '√';
                    D.style.color = 'white';
                    D.style.backgroundColor = 'green';

                    break;
                default:
            }
        }// 非多选题型

// ========================================
        /*
                switch(picked)
                {
                    case 'A':
                        //   alert('a'+'。。'+ans);
                        if ('1' === ans || '16' === ans){
                            //       alert('cccc');
                            A.innerHTML = '√';
                            A.style.color = 'white';
                            A.style.backgroundColor = 'green';
                            myAnswers[index-1] = 1;
                        }else {

                            A.innerHTML = 'X';
                            A.style.color = 'white';
                            A.style.backgroundColor = 'red';
                            myAnswers[index-1] = 2;
                        }


                        break;
                    case 'B':
                        //  alert('b');
                        if ('2' === ans || '17' === ans){

                            B.innerHTML = '√';
                            B.style.color = 'white';
                            B.style.backgroundColor = 'green';
                            myAnswers[index-1] = 1;
                        }else {

                            B.innerHTML = 'X';
                            B.style.color = 'white';
                            B.style.backgroundColor = 'red';
                            myAnswers[index-1] = 2;
                        }

                        break;
                    case 'C':
                        //  alert('c');
                        if ('4' === ans){
                            C.innerHTML = '√';
                            C.style.color = 'white';
                            C.style.backgroundColor = 'green';
                            myAnswers[index-1] = 1;

                        }else {
                            C.innerHTML = 'X';
                            C.style.color = 'white';
                            C.style.backgroundColor = 'red';
                            myAnswers[index-1] = 2;
                        }

                        break;
                    case 'D':
                        //  alert('d');
                        if ('8' === ans){

                            D.innerHTML = '√';
                            D.style.color = 'white';
                            D.style.backgroundColor = 'green';
                            myAnswers[index-1] = 1;

                        }else {

                            D.innerHTML = 'X';
                            D.style.color = 'white';
                            D.style.backgroundColor = 'red';
                            myAnswers[index-1] = 2;
                        }

                        break;
                    default:
                }

                switch(ans)
                {
                    case '1':
                        // alert('a');
                        A.innerHTML = '√';
                        A.style.color = 'white';
                        A.style.backgroundColor = 'green';

                        break;
                    case '2':
                        //  alert('b');
                        B.innerHTML = '√';
                        B.style.color = 'white';
                        B.style.backgroundColor = 'green';

                        break;
                    case '4':
                        //  alert('c');
                        C.innerHTML = '√';
                        C.style.color = 'white';
                        C.style.backgroundColor = 'green';

                        break;
                    case '8':
                        //  alert('d');
                        D.innerHTML = '√';
                        D.style.color = 'white';
                        D.style.backgroundColor = 'green';

                        break;
                    default:
                }
        */
    }
    // 交卷
    function submitAction() {
        jiaojuan = 1;
        //  alert('交卷');
// 弹窗 但不显示图片
        var  ppic = document.getElementById('explainPic');
        ppic.hidden = true;
// 对
        var right=0;
        // 错
        var wrong=0;
        // 未做
        var virgin=0;
        //  alert(myAnswers);
        myAnswers.forEach(function (value) {
            if (value ===1){
                right++;
            }
            if (value === 2){
                wrong ++;
            }
            if (value == 0){
                virgin ++;
            }
        });

        selfAction('答对'+right+'道，'+'打错'+wrong+'道，'+'未完成'+virgin+'道。');

    }

    // 自定义弹窗
    function createPrompt()
    {
        //  var divSp = document.createElement("div");    //弹出对话框
        //  var newMask = document.createElement("div");  //遮罩层，用来屏蔽灰掉背部界面
        // // var btnSub = document.createElement("input"); // 弹出对话框中按钮
        //  var inner;

//alert('*******自定义弹窗********');
//alert(myAnswers);
//alert('*******自定义弹窗********');

        var mask = document.createElement('div');
        mask.id = "mask";
        mask.style.backgroundColor = 'lightblue';
        mask.style.width = "100%";
        mask.style.height = "100%";
        mask.style.position = "absolute";
        mask.style.top  = "0px";
        mask.style.left = "0px";
        document.body.appendChild(mask);



        var iframe = document.createElement('iframe');
        iframe.style.position = "absolute";
        iframe.style.height = "60%";
        iframe.style.width  = "90%";
        iframe.style.backgroundColor = "lightblue";
        iframe.style.top = "5%";
        iframe.style.left = "5%";
        iframe.style.border = "white";
        //iframe.href('examDetail.html');
        iframe.src=("examDetail.html?count="+totalCount);
        //alert(totalCount+'cc');
        mask.appendChild(iframe);

//  alert('弹窗:'+myAnswer);
//alert('弹窗'+myAnswers);
        localStorage.setItem('myAnswers',myAnswers);

        var  btn = document.createElement('button');
        btn.style.position = "absolute";
        btn.style.width = "40%";
        btn.style.height = "36px";
        btn.innerHTML = "返回考试";
        btn.style.color = "black";
        btn.style.border = "white";
        btn.style.fontSize = "15px";
        btn.style.top = "72%";
        btn.style.left = "30%";
        btn.style.backgroundColor = "white";
        btn.addEventListener("click",removeAlert);
        mask.appendChild(btn);

        //      alert('createPromotexxx');
        //      alert(totalCount);


        //  var myStr11 = localStorage.getItem('myAnswers');
        //  var myAnswers = myStr.split(',');
        //  alert(myStr11);

    }
    // 移除弹窗（考试详情）
    function removeAlert() {

        var mask = document.getElementById('mask');

        document.body.removeChild(mask);
    }



</script>


</html>
