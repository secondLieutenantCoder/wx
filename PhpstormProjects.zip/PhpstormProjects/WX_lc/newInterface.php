<?php

require 'gxyzm.php';

//=================
//$yzmUtil = new YZMUtil();
//$yzm =$yzmUtil->getzcmAction("10000100010001");
$newc = 5;
$cishu = str_pad($newc,4,"0",STR_PAD_LEFT);
$shulian = str_pad(9,4,"0",STR_PAD_LEFT);
$gxMID = "000001";
$DATA1 = $gxMID.$cishu.$shulian;

$yzmUtil = new YZMUtil();
$yzm =$yzmUtil->getzcmAction( $DATA1);
// accesstoken

//$jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

// get accessToken
//$accessToken = $jssdk->getAccessToken();
$yzmUtil ->getNewTicket("o7XC90jGgVsu2ra0omYf2UY900Yo","9_pnwyajevBdGlYMa2gC7zAQSOfeBkpJv5ZVuPKkD50I2QswryQtqzagA84ZROeQ62UZDi68Hin0fP11b9-3dN0EkxHaVf4eEQzhP0Y4Lz0Ik2AQQ7Y2L6HqqWGf0FB_mCv9JoBh7ddyEk7eEcWAHbAIACGN",$yzm);
