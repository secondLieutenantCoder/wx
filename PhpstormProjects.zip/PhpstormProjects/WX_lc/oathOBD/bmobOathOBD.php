<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/5/22
 * Time: 09:29
 */


require "../lib/BmobObject.class.php";

// 1.取bmob数据
$bmobObj = new BmobObject("Person");
//  $timestamp = time()+7000;
//  $objID = 'a0c44d19d4';
//  $openid = $resObj-> openid;

$usernameid = $_GET["username"];
$kind = $_GET["kind"];
//$usernameid = $_POST["no"];

//$studentID = "o7XC90jGgVsu2ra0omYf2UY900Yo";
$queryStr = "where={\"username\":\"{$usernameid}\"}";
$res=$bmobObj->get("",array("$queryStr"));
$res1 = $res->results;

$obj = $res1[0];

//var_dump($obj);

//echo 'xxxxxxxxxxxx';

$objectId = $obj->objectId;
if ($kind*1 == 1){

    $upRes = $bmobObj->update($objectId,array("isOBD"=>1,));
    $date = $upRes->updatedAt;
    if (strlen($date) > 1){
        echo 'success';
    }else{

        echo 'fail';
    }
}else{

    $upRes = $bmobObj->update($objectId,array("isOBDCGQ"=>1,));

    $date = $upRes->updatedAt;

    if (strlen($date) > 1){
        echo 'success';
    }else{

        echo 'fail';
    }
}



//$isSuccess =
//var_dump($upRes);
/*
$GX_res = $bmobObj->get("Ktq95556");

// 总课时 proxy_name
// 总收益  coach_id
//var_dump($res);
$GX_time = $GX_res->proxy_name;

$GX_money = $GX_res->coach_id;

$GX_newtime = $GX_time + 1;
$GX_newmoney = $GX_money+ 10;

$bmobObj->update("Ktq95556",array("proxy_name"=>"$GX_newtime","coach_id"=>"$GX_newmoney"));
*/


?>