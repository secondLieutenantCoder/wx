<?php
//$a = '111111';
// 科目一科目四首页

$xxx = 'xxxxxxx';
$authObj = new htmlAuth();
// 获取用户的 openID
$openid = $authObj->getWXAccesstoken();
//$wwTest = '000';

$authToken = $authObj->getToken();
//echo '-----'.$authToken;
// 拉取用户信息
$url="https://api.weixin.qq.com/sns/userinfo?access_token=$authToken&openid=$openid&lang=zh_CN";
$html = file_get_contents($url);

$htmlObj = json_decode($html);
//  echo $html;
//echo "====--===";
//echo $htmlObj->nickname;
$authObj->saveUserInfo($openid,$htmlObj->nickname,$htmlObj->province,$htmlObj->headimgurl);
$phone  =   $authObj->phone;
//echo $htmlObj;
//echo $phone;
//$userObjID = $html->objectId;
//echo $userObjID;
$isVIP = $authObj->isVip;
//var_dump($authObj);
$parent = $authObj->topOpenID;


class htmlAuth {
    var $token;
    var $isVip;
    var $phone;
// 我的上级的     openID
    var $topOpenID;

    public function __construct() {

    }
    function getToken (){

        return $this->token;
    }

// 写入用户信息==================1111===================

    public function saveUserInfo ($oid,$name,$province,$hurl){
//echo '写入用户信息';
        require "./wxResource/bmobPhpSdk/lib/BmobObject.class.php";
        // 1.取bmob数据
        $bmobObj = new BmobObject("WX_user");
        //  $timestamp = time()+7000;
        //  $objID = 'a0c44d19d4';
        //  $openid = $resObj-> openid;

        $currentOpenID = $oid;
//echo $oid;
        $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
        $res=$bmobObj->get("",array("$queryStr"));
        $res1 = $res->results;
        $currentObj =  $res1[0];
//var_dump($res);
        $endTime = $currentObj->endTime;
//echo $endTime;
        // objectIda
        $cObjID = $currentObj->objectId;
        //  往Bmob写用户数据
        $res=$bmobObj->update($cObjID, array("nickname"=>$name,"province"=>$province,"headimgurl"=>$hurl));
        //  获取到当前的会员状态，是否已经开通？ 是否已经过期？
//var_dump($currentObj);
//$isVIP= 0;
        $this->phone = $currentObj->phone;
        $this->topOpenID = $currentObj->p1;
//echo 'phone';
//echo   $currentObj->phone;
        if ($endTime < time()){
            // 过期
            $this->isVip = 0;
        }else{
            // 木过期
            $this->isVip = 1;
        }

    }

    // ==================- 获取网页授权 access-token -=============
    public function getWXAccesstoken(){

        $authCode = $_GET['code'];
        $authState = $_GET['state'];

        $appID = "wx62732b3c3460b3b1";
        $appSecret = 'cc05112ee2e8f53d80970d0d988398cd';
//        $accessUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appID.'&secret='.$appSecret;
        $accessUrl = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appID.'&secret='.$appSecret.'&code='.$authCode.'&grant_type=authorization_code';

        $pageInfo  = file_get_contents($accessUrl);

        $infoObj   = json_decode($pageInfo);

        $this->token = $infoObj->access_token;

        $expireIn    = $infoObj->expires_in;
        $reat        = $infoObj->refresh_token;
        $scope       = $infoObj->scope;

        $opID = $infoObj->openid;

        return $opID;
    }//getWXAccessToken end
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <title>龙创交规</title>
    <script type="text/javascript" src="wxResource/bmob_jssdk/jquery.min.js"></script>
    <script type="text/javascript" src="wxResource/bmob_jssdk/bmob.js"></script>

</head>



<style>

    @media screen and (max-width: 500px) {

        #centerBtn{

            width: 30vw;
            height: 30vw;
            background: deepskyblue;
            top: 65px;
            left: 35%;
        }
        .titleMoney{

            width: 20vw;
            height: 20vw;
            color: white;
            margin-left: 10vw;
            /*width: 25%;*/
            /*padding-bottom: 100%;*/

        }

        /*body{*/
        /*text-align: center;*/
        /*background-color: yellow;*/
        /*}*/

    }
    @media screen and (min-width: 500px) {

        #centerBtn{
            text-align: center;
            left: 38%;
            width:  130px;
            height: 130px;
            background: deepskyblue;
            top: 65px;
        }
        .titleMoney{

            width: 85px;
            height: 85px;
            color: white;
            /*width: 25%;*/
            /*padding-bottom: 100%;*/
        }
        #firCircle{

            margin-left: 145px;
        }
    }


    .title1{

        width: 19%;
        height: 30px;
        font-size: 10px;
        font-size-adjust: inherit;
        background: cornflowerblue;
    }
    .title1:active{

        color: white;
        background-color: lightskyblue;

    }

    /*sudo apachectl -k start    启动apache*/
    .fourItem{
        box-shadow: 1px 1px 3px  deepskyblue;
        width: 30%;
        margin-left: 2.5%;
        height: 50px;
        margin-top: 30px;
        background: white;
        border:white;
        margin-bottom: 30px;
        font-size: 20px;


    }

    /*底部导航*/
    .nav {
        background: deepskyblue;
        padding: 10px 0 6px 0;
        width: 100%;
        position: fixed;
        left: 0;
        bottom: 0;
        /*z-index: 99;*/
    }
    .nav ul {
        height: 0;
    }
    .nav ul li {
        float: left;
        width: 50%;
        text-align: center;
        list-style-type: none;
        margin: 0;
        padding: 0;

    }
    .nav ul li span {
        display: block;
        color: white;
        font-size: 14px;
        /*font-family: "微软雅黑";*/
        line-height: 22px;
    }
    a {
        color: #000;
        text-decoration: none;
    }
    * {
        padding: 0;
        margin: 0;
        list-style: none;
        font-weight: normal;
    }

</style>

<body background="wxResource/imgs/background.png" onload="loadData()">


<!--<h1>服务号选择页面</h1>-->
<!--<h2> Apache 服务器 </h2>-->
<!--/Library/WebServer/Documents-->


<!-- 权限 -->
<!--<div>-->


<!--<button onclick="freeAction()"; class="fourItem" style="">免费体验</button>-->
<!--<button onclick="vipAction()"; class="fourItem" style="width: 30%;">开通系统</button>-->
<!--<button onclick="shareAction()"; class="fourItem" style="width: 30%;">分享好友</button>-->

<!--</div>-->

<div style="margin-top: 20px;">

    <img onclick="freeAction()" style="width: 20%; height: 20%;margin-left: 10%;" src="wxResource/imgs/freeuse.png">

    <img onclick="vipAction()" style="width: 20%; height: 20%;margin-left: 10%;" src="wxResource/imgs/beVip.png">

    <img onclick="shareAction()" style="width: 20%; height: 20%;margin-left: 10%;" src="wxResource/imgs/share.png">
</div>

<div style="width: 90%; height: 150px; background: #DBF1FE; margin-left: 5%">

    <h3 style="width: 50%;margin-left: 25%; height: 25px;font-size: 18px;text-align: center;color: dodgerblue;margin-top: 20px">科目一</h3>

    <button id="zx" onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 5%;color: white;font-size: 18px">专项练习</button>
    <button id="jc"  onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 20%;color: white;font-size: 18px">基础练习</button>
    <button id="mn"  onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 5%;margin-top: 25px;color: white;font-size: 18px">模拟考试</button>
    <button id="ct" onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 20%;margin-top: 25px;color: white;font-size: 18px">错题练习</button>

</div>

<div style="width: 90%; height: 150px; background: #DBF1FE; margin-left: 5%">

    <h3 style="width: 50%;margin-left: 25%; height: 25px;font-size: 18px;text-align: center;color: dodgerblue;margin-top: 20px">科目四</h3>

    <button  id="qh"  onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 5%;color: white;font-size: 18px;margin-top: 30px;">基础练习</button>
    <button  id="mn4" onclick="typeAction(this)"  style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 20%;color: white;font-size: 18px;margin-top: 30px;">模拟考试</button>

    <!--<button id="ct4" onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 5%;margin-top: 25px;color: white;font-size: 18px">错题练习</button>-->

    <!--<button onclick="typeAction(this)" style="background-image: url(wxResource/imgs/button.png);background-size: 100% 100%;width: 35%; height: 35px;border: white;margin-left: 20%;margin-top: 25px;color: white;font-size: 18px">11</button>-->

</div>



<!--底部导航-->
<div class="nav">
    <ul>

        <li onclick="contactusAction()">
            <a href="#"><span><img src="wxResource/imgs/11111.png" height="20"></span><span>联系龙创 </span></a>
        </li>
        <li style="position:relative;" onclick="customManagerAction()">
            <a href="#"><span><img src="wxResource/imgs/22222.png" height="20"></span><span>我的学员</span></a>
        </li>
        <!--    <li onclick="customManagerAction()">-->
        <!--<audio src=""></audio>-->

        <!--      <a href="#"><span><img src="wxResource/imgs/33333333.png" height="20"></span><span>我的订单</span></a>-->
        <!--      </li>-->

    </ul>
</div>




</body>


<script type="text/javascript">

    function loadData() {

//alert('11111111111');
        var currentOpenID = '<?php  echo $openid; ?>';
//alert(currentOpenID);
        localStorage.setItem('currentOpenID',currentOpenID);
//alert('22222222');

        var userobjID = '<?php  echo $userObjID  ?>';
        localStorage.setItem('userObjID', userobjID);

        var phone = '<?php echo $phone ?>';
        localStorage.setItem('phone',phone);


        var parentID = '<?php echo $parent;  ?>';
        localStorage.setItem('parentID',parentID);

// alert(parentID);

//alert(phone);
    }

    // 是否已经开通了系统  0 未  1  开

    var sub1F,sub2F,zxF,jcF,qhF,mnF;

    // 免费试用题
    function freeAction () {

        location.href = 'chooseWithPic.html';

    }
    // 分享
    function shareAction ()  {
        //       alert('000000');
        //     var phoneWW = "<?php  echo $phone;  ?>";
        //       alert('11111111');
        //      var isPhone = isPoneAvailable(phoneWW);
        //       alert('222222');
// alert(phoneWW);
        //       if (isPhone === true){
        //   alert('电话合法');
//localStorage.setItem('phone',phoneWW);
        //      }else{
        //      alert('电话不合法！');
//localStorage.setItem('phone',phoneWW);
//selfAction();
        //      }

        location.href = "share.php?openid="+'<?php  echo $openid; ?>';

    }
    // 正则表达式 验证手机号码
    function isPoneAvailable(str) {
        var myreg=/^[1][3,4,5,7,8][0-9]{9}$/;
        if (!myreg.test(str)) {
            return false;
        } else {
            return true;
        }
    }


    // 科目一 科目四 选择
    function subAction(b) {

        var sub1 = document.getElementById('sub1');
        var sub2 = document.getElementById('sub2');

        if (b === sub1){
            sub1F = true;
            sub2F = false;

            sub1.style.backgroundColor = 'darkblue';
            sub2.style.backgroundColor = 'lightskyblue';
        }
        if (b === sub2){
            sub2F = true;
            sub1F = false;

            sub1.style.backgroundColor = 'lightskyblue';
            sub2.style.backgroundColor = 'darkblue';
        }
    }
    // 联系龙创
    function contactusAction(){
        location.href = 'contactus.html';
    }

    // 下线管理
    function customManagerAction(){
        location.href = "myStudents.html?openid="+'<?php  echo $openid; ?>';
    }

    // 练习类型 选择
    function typeAction(t) {

//alert('isOpen');
        var isOpen = <?php echo "$isVIP"; ?>;
//alert(isOpen);
        if (isOpen === 1){

            var zx = document.getElementById('zx');
            var jc = document.getElementById('jc');
            var qh = document.getElementById('qh');
            var mn = document.getElementById('mn');
            var ct = document.getElementById('ct');
            var ct4= document.getElementById('ct4');
            var mn4 = document.getElementById('mn4');

            // if (sub1F !== true && sub2F !== true){
            //
            //    alert('请先选择您要学习的科目,科目一or科目四？')
            // }else {
            // 科目一
            if (t === zx ){
                location.href = 'specialItem.html?sub=1&item=zx';
            }
            if (t === jc){
                location.href = 'primaryExercise.html?sub=1&item=jc';
            }

            if (t === mn){
                location.href = 'mockExam.php';
            }
            if (t === ct){
                location.href = 'wrongRecord.html';
            }

            // 科目四
            if (t === qh){
                location.href = 'hardExercise.html?sub=4&item=qh';
            }
            if (t === ct4){

            }
            if (t === mn4){
                location.href = 'mockExamFour.php';
            }
            // }

        }else {
            alert('请先开通系统');

        }

    }


</script>

<script>
    // 获取网页授权信息
    localStorage.setItem('openid','<?php echo $openid; ?>');
</script>

<script language="JavaScript" type="text/javascript">
    /// 弹窗
    function clickFunction() {
        alert("点击按钮");
    }
    /// 跳转
    function goNextFunc() {

        window.location.href='index.html';
    }

    /// 后退
    function backFunc() {

        history.back();
    }

    // button的选中效果
    function selectedFunc(a) {

        var b1 = document.getElementById('km1');
        var b2 = document.getElementById('km4');
        var b3 = document.getElementById('ctlx');
        var b4 = document.getElementById('zxhf');
        var b5 = document.getElementById('zgz');
        b1.style.color = 'black';
        b2.style.color = 'black';
        b3.style.color = 'black';
        b4.style.color = 'black';
        b5.style.color = 'black';

        b1.style.backgroundColor = 'cornflowerblue';
        b2.style.backgroundColor = 'cornflowerblue';
        b3.style.backgroundColor = 'cornflowerblue';
        b4.style.backgroundColor = 'cornflowerblue';
        b5.style.backgroundColor = 'cornflowerblue';

        a.style.backgroundColor = 'blue';
        a.style.color = 'white';

        //  alert(a.value);
        // alert(a.value);
    }

    // 开通系统
    function vipAction() {
        location.href = './beVIP.php';
    }
    // 分类学习
    function regularTest() {
        window.location.assign("./xuanze/chooseWithPic.html"+'?'+'p1='+'regular'+'&'+'p2='+'sick');
    }
    // 模拟考试
    function temptTest() {
        alert('模拟考试');
    }

    // 错题重做
    function reAction() {
        alert('错题重做');
    }

    // 模拟成绩
    function gradeAction() {
        alert('模拟成绩');
    }

    // 中间圆形按钮
    function centerAction() {

        // window.open('detailClass.html');
        window.location.href = 'detailClass.html';
    }


</script>

</html>