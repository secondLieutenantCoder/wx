<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/5/17
 * Time: 09:55
 */

// 微信企业付款到零钱


$payUtil = new payChange();

$payUtil->payAction("wwopenid",100);

class payChange{

    private $key = 'qwertyuiopasdfghjklzxcvbnmqwerty';
    private $mchid = '1497773332';
    private $appid = 'wx62732b3c3460b3b1';
    private $secret = 'cc05112ee2e8f53d80970d0d988398cd';
    private $url = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
    private $params;

    function __construct()
    {

    }

    // 签名
    public function sign(){


        return $this->setSign($this->params);
    }
    public function setSign($arr){
        $arr['sign'] = $this->getSign($arr);
        return $arr;
    }
    public function getSign($arr){
        //去除空值
        $arr = array_filter($arr);
        if(isset($arr['sign'])){
            unset($arr['sign']);
        }
        //按照键名字典排序
        ksort($arr);
        //生成url格式的字符串
        $str = $this->arrToUrl($arr) . '&key=' . $this->key;
        return strtoupper(md5($str));
    }
    public function arrToUrl($arr){
        return urldecode(http_build_query($arr));
    }

    public function payAction($openid,$money){

        $this->params = array(
            'mch_appid'         => $this->appid,//APPid,
            'mchid'             => $this->mchid,//商户号,
            'nonce_str'         => md5(time()), //随机字符串
            'partner_trade_no'  => date('YmdHis'), //商户订单号
            'openid'            => $openid, //用户openid
            'check_name'        => 'NO_CHECK',//校验用户姓名选项 NO_CHECK：不校验真实姓名 FORCE_CHECK：强校验真实姓名
            //'re_user_name'    => '',//收款用户姓名  如果check_name设置为FORCE_CHECK，则必填用户真实姓名
            'amount'            => $money,//金额 单位分
            'desc'              => '测试付款',//付款描述
            'spbill_create_ip'  => $_SERVER['SERVER_ADDR'],//调用接口机器的ip地址
        );

      //  var_dump($this->params);

        $this->send($this->url);
}

    public function send($url){
        $res = $this->sign();
        echo '***res=';
        var_dump($res);
        echo '***';
        $xml = $this->ArrToXml($res);
        $returnData = $this->postData($url, $xml);

        echo '<br>';
        echo '&';
        var_dump($this->XmlToArr($returnData));
        echo '&';
        return $this->XmlToArr($returnData);
    }

    function postData($url,$postfields){
       echo '<br>';
       echo '=======';
        echo $postfields;
        echo '<br>';
        $ch = curl_init();
        $params[CURLOPT_URL] = $url;    //请求url地址
        $params[CURLOPT_HEADER] = false; //是否返回响应头信息
        $params[CURLOPT_RETURNTRANSFER] = true; //是否将结果返回
        $params[CURLOPT_FOLLOWLOCATION] = true; //是否重定向
        $params[CURLOPT_POST] = true;
        $params[CURLOPT_POSTFIELDS] = $postfields;
        $params[CURLOPT_SSL_VERIFYPEER] = false;
        $params[CURLOPT_SSL_VERIFYHOST] = false;
        //以下是证书相关代码
        $params[CURLOPT_SSLCERTTYPE] = 'PEM';
        $params[CURLOPT_SSLCERT] = './cert/apiclient_cert.pem';
        $params[CURLOPT_SSLKEYTYPE] = 'PEM';
        $params[CURLOPT_SSLKEY] = './cert/apiclient_key.pem';

        curl_setopt_array($ch, $params); //传入curl参数
        $content = curl_exec($ch); //执行
        curl_close($ch); //关闭连接
        return $content;
    }

    //数组转xml
    function ArrToXml($arr)
    {
        /*
        if(!is_array($arr) || count($arr) == 0) return '';

        $xml = "<xml>";
        foreach ($arr as $key=>$val)
        {
            if (is_numeric($val)){
                $xml.="<".$key.">".$val."</".$key.">";
            }else{
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
            }
        }
        $xml.="</xml>";
        return $xml;
        */
        $xmlModal = "<xml>
<mch_appid><![CDATA[%s]]></mch_appid>
<mchid>%s</mchid>
<nonce_str><![CDATA[%s]]></nonce_str>
<partner_trade_no>%s</partner_trade_no>
<openid><![CDATA[%s]]></openid>
<check_name><![CDATA[%s]]></check_name>
<amount>%s</amount>
<desc><![CDATA[%s]]></desc>
<spbill_create_ip><![CDATA[%s]]></spbill_create_ip>
<sign><![CDATA[%s]]></sign>
</xml>";
      $xml = printf($xmlModal,$arr["mch_appid"],$arr['mchid'],$arr['nonce_str'],$arr['partner_trade_no'],$arr['openid'],$arr['check_name'],$arr['amount'],$arr['desc'],$arr['spbill_create_ip'],$arr['sign']);
       // echo $xml;
        return $xml;
    }

    //Xml转数组
    function XmlToArr($xml)
    {
        if($xml == '') return '';
        libxml_disable_entity_loader(true);
        $arr = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
        return $arr;
    }


}
/*
  /*
        $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName>
<FromUserName><![CDATA[%s]]></FromUserName>
 <CreateTime>%s</CreateTime>
<MsgType><![CDATA[%s]]></MsgType>
<ArticleCount>1</ArticleCount>
<Articles><item><Title><![CDATA[%s]]></Title>
<Description><![CDATA[%s]]></Description><PicUrl>
<![CDATA[%s]]></PicUrl><Url><![CDATA[%s]]></Url></item></Articles></xml>";
                    $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$title,$desc,$picUrl,$url);
                    echo $responseSubsxribe;

 *
 *
<xml>
<mch_appid><![CDATA[wx62732b3c3460b3b1]]></mch_appid>
<mchid>1497773332</mchid>
<nonce_str><![CDATA[2784771ba3480c0551491b61ea085518]]></nonce_str>
<partner_trade_no>20180517143550</partner_trade_no>
<openid><![CDATA[o7XC90jGgVsu2ra0omYf2UY900Yo]]></openid>
<check_name><![CDATA[NO_CHECK]]></check_name>
<amount>100</amount>
<desc><![CDATA[测试付款]]></desc>
<spbill_create_ip><![CDATA[121.40.121.43]]></spbill_create_ip>
<sign><![CDATA[7303689F83433FAA27228450E4186FF5]]></sign>
</xml>
*/