<?php
//结算
require '../wxResource/bmobPhpSdk/lib/BmobObject.class.php';

// 提现种类 1 交规 2 共享
$kind = $_POST['kind'];

$fAmount =  $_POST['amount'];
$amount   =  $fAmount*100;
$name =  $_POST['name'];
$openid = $_POST['openid'];

/// ============================================
// 1 交规 提现   2 共享提现
///require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";
///$openID = $_GET['openID'];
///$kind = $_GET['kind'];

// 查询 可提现 金额
$userObj1 = new BmobObject("WX_user");

//   $openID = 'o7XC90jGgVsu2ra0omYf2UY900Yo';
$queryStr1 = "where={\"openID\":\"{$openid}\"}";
$res2=$userObj1->get("",array("$queryStr1"));
$res3 = $res2->results;
$currentObj1 =  $res3[0];

// 交规的总钱数
$money1 = $currentObj1->money;
//echo 'money='.$money;
$tokenMoney1 = $currentObj1->tokenMoney;
//echo 'tokenMoney ='.$tokenMoney;
$jgAccess = $money1 - $tokenMoney1;

// 共享的总钱数
$gxMoney2 = $currentObj1->gxTotalMoney;
//echo 'gxTotalMoney ='.$gxMoney;

$gxToken2 = $currentObj1->gxToken;
//echo 'tgxToken ='.$gxToken;
$gxAccess = $gxMoney2 - $gxToken2;

if($kind == 1 && ($fAmount*1> $jgAccess*1)){

    $data=array(
        'mch_appid'=>'wx62732b3c3460b3b1',//商户账号appid
        'mchid'=>'1497773332',//商户号
        'nonce_str'=>md5(time()), //随机字符串
        'partner_trade_no'=>date('YmdHis'), //商户订单号
        'openid'=>$openid,//用户openid
        'check_name'=>'FORCE_CHECK',//校验用户姓名选项, NO_CHECK  FORCE_CHECK
        're_user_name'=>$name,//收款用户姓名
        'amount'=>$amount,//金额
        'desc'=>'龙创科技提现',//企业付款描述信息
        'spbill_create_ip'=>$_SERVER['SERVER_ADDR'],//Ip地址
    );
    $secrect_key='qwertyuiopasdfghjklzxcvbnmqwerty';///这个就是个API密码。32位的。。随便MD5一下就可以了
    $data=array_filter($data);
    ksort($data);
    $str='';
    foreach($data as $k=>$v) {
        $str.=$k.'='.$v.'&';
    }
    $str.='key='.$secrect_key;
    $data['sign']=md5($str);
    $xml=arraytoxml($data);
// echo $xml;
    $url='https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';

// ========  发起请求 =================
    $res=curl($xml,$url);
// ==    网络请求结果
    $return=xmltoarray($res);

// 根据结果 执行下一步的操作
    $return_code = $return['return_code'];
    $result_code = $return['result_code'];
//$return_code = 'SUCCESS';
//$result_code = 'SUCCESS';
    if (strcmp($return_code,'SUCCESS') == 0 && strcmp($result_code,'SUCCESS')==0){

        // 提现成功
        // 写 提现记录
        // 将提成记录添加到 提成记录表中
        $bmobObjC = new BmobObject("WXCashRecord");

        $p_no = $return['payment_no'];
        $resR = $bmobObjC->create(array("openID"=>"$openid","name"=>"$name","payment_no"=>"$p_no ","cash"=>"$fAmount"));
        // 修改已提现金额
        $userObj = new BmobObject("WX_user");
        $currentOpenID = $openid;
        $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
        $res=$userObj->get("",array("$queryStr"));
        $res1 = $res->results;
        $currentObj =  $res1[0];

        $objId   = $currentObj->objectId;

        if($kind == 1){
//  交规
            $money = $currentObj->money;
            $tokenMoney = $currentObj->tokenMoney;
            $newToken    = $tokenMoney + $fAmount;
            $updatep2 = $userObj->update($objId,array("tokenMoney"=>$newToken,));

        }else if($kind == 2){
            // 共享
            $money = $currentObj->gxTotalMoney;
            $tokenMoney = $currentObj->gxToken;
            $newToken    = $tokenMoney + $fAmount;
            $updatep2 = $userObj->update($objId,array("gxToken"=>$newToken,));

        }
// SUCCESS 成功
    }

//======  对请求网页返回结果 =========
    $jsonReturn = json_encode($return);
    print_r($jsonReturn);

}else if($kind == 2 &&($fAmount*1 >$gxAccess*1)){

    $data=array(
        'mch_appid'=>'wx62732b3c3460b3b1',//商户账号appid
        'mchid'=>'1497773332',//商户号
        'nonce_str'=>md5(time()), //随机字符串
        'partner_trade_no'=>date('YmdHis'), //商户订单号
        'openid'=>$openid,//用户openid
        'check_name'=>'FORCE_CHECK',//校验用户姓名选项, NO_CHECK  FORCE_CHECK
        're_user_name'=>$name,//收款用户姓名
        'amount'=>$amount,//金额
        'desc'=>'龙创科技提现',//企业付款描述信息
        'spbill_create_ip'=>$_SERVER['SERVER_ADDR'],//Ip地址
    );
    $secrect_key='qwertyuiopasdfghjklzxcvbnmqwerty';///这个就是个API密码。32位的。。随便MD5一下就可以了
    $data=array_filter($data);
    ksort($data);
    $str='';
    foreach($data as $k=>$v) {
        $str.=$k.'='.$v.'&';
    }
    $str.='key='.$secrect_key;
    $data['sign']=md5($str);
    $xml=arraytoxml($data);
// echo $xml;
    $url='https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';

// ========  发起请求 =================
    $res=curl($xml,$url);
// ==    网络请求结果
    $return=xmltoarray($res);

// 根据结果 执行下一步的操作
    $return_code = $return['return_code'];
    $result_code = $return['result_code'];
//$return_code = 'SUCCESS';
//$result_code = 'SUCCESS';
    if (strcmp($return_code,'SUCCESS') == 0 && strcmp($result_code,'SUCCESS')==0){

        // 提现成功
        // 写 提现记录
        // 将提成记录添加到 提成记录表中
        $bmobObjC = new BmobObject("WXCashRecord");

        $p_no = $return['payment_no'];
        $resR = $bmobObjC->create(array("openID"=>"$openid","name"=>"$name","payment_no"=>"$p_no ","cash"=>"$fAmount"));
        // 修改已提现金额
        $userObj = new BmobObject("WX_user");
        $currentOpenID = $openid;
        $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
        $res=$userObj->get("",array("$queryStr"));
        $res1 = $res->results;
        $currentObj =  $res1[0];

        $objId   = $currentObj->objectId;

        if($kind == 1){
//  交规
            $money = $currentObj->money;
            $tokenMoney = $currentObj->tokenMoney;
            $newToken    = $tokenMoney + $fAmount;
            $updatep2 = $userObj->update($objId,array("tokenMoney"=>$newToken,));

        }else if($kind == 2){
            // 共享
            $money = $currentObj->gxTotalMoney;
            $tokenMoney = $currentObj->gxToken;
            $newToken    = $tokenMoney + $fAmount;
            $updatep2 = $userObj->update($objId,array("gxToken"=>$newToken,));

        }
// SUCCESS 成功
    }

//======  对请求网页返回结果 =========
    $jsonReturn = json_encode($return);
    print_r($jsonReturn);

}else{
    // 请求的金额 > 实际可提现的金额时
    $data1=array(

        'result_code'=>'FAIL',//企业付款描述信息
        'err_code_des'=>'提现金额有误，请检查！',//Ip地址
    );

    $return1 = json_encode($data1);
    print_r($return1);


}

/// ==========




// echo getcwd().'/cert/apiclient_cert.pem';die;
function unicode() {
    $str = uniqid(mt_rand(),1);
    $str=sha1($str);
    return md5($str);
}
function arraytoxml($data){
    $str='<xml>';
    foreach($data as $k=>$v) {
        $str.='<'.$k.'>'.$v.'</'.$k.'>';
    }
    $str.='</xml>';
    return $str;
}
function xmltoarray($xml) {
    //禁止引用外部xml实体
    libxml_disable_entity_loader(true);
    $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
    $val = json_decode(json_encode($xmlstring),true);
    return $val;
}

function curl($param="",$url) {

    $postUrl = $url;
    $curlPost = $param;
    $ch = curl_init();                                      //初始化curl
    curl_setopt($ch, CURLOPT_URL,$postUrl);                 //抓取指定网页
    curl_setopt($ch, CURLOPT_HEADER, 0);                    //设置header
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);            //要求结果为字符串且输出到屏幕上
    curl_setopt($ch, CURLOPT_POST, 1);                      //post提交方式
    curl_setopt($ch, CURLOPT_TIMEOUT,10);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);           // 增加 HTTP Header（头）里的字段
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);        // 终止从服务端进行验证
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch,CURLOPT_SSLCERT,'./cert/apiclient_cert.pem'); //这个是证书的位置绝对路径
    curl_setopt($ch,CURLOPT_SSLKEY,'./cert/apiclient_key.pem'); //这个也是证书的位置绝对路径
    $data = curl_exec($ch);                                 //运行curl
    curl_close($ch);
    return $data;
}
?>