<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/1/26
 * Time: 14:58
 */
//include_once 'lib/BmobObject.class.php';
//include_once 'lib/BmobUser.class.php';
//include_once 'lib/BmobBatch.class.php';
//include_once 'lib/BmobFile.class.php';
//include_once 'lib/BmobImage.class.php';
//include_once 'lib/BmobRole.class.php';
//include_once 'lib/BmobPush.class.php';
//include_once 'lib/BmobPay.class.php';
//include_once 'lib/BmobSms.class.php';
//include_once 'lib/BmobApp.class.php';
//include_once 'lib/BmobSchemas.class.php';
//include_once 'lib/BmobTimestamp.class.php';
//include_once 'lib/BmobCloudCode.class.php';
//include_once 'lib/BmobBql.class.php';


// $xxxx = '';

//  require_once 'lib/BmobObject.class.php';

// $wwOpenid = $_GET['openid'];

//require_once "./localPhp/jssdk.php";
//require_once './jssdk1.php';
//$jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");
//$signPackage = $jssdk->GetSignPackage();


// get accessToken
//$accessToken = $jssdk->getAccessToken();
echo '===== Token =====';
//echo $accessToken;
echo '----------';
// 首先判断二维码的ticket是否过期


$accessToken = "9_pnwyajevBdGlYMa2gC7zAQSOfeBkpJv5ZVuPKkD50I2QswryQtqzagA84ZROeQ62UZDi68Hin0fP11b9-3dN0EkxHaVf4eEQzhP0Y4Lz0Ik2AQQ7Y2L6HqqWGf0FB_mCv9JoBh7ddyEk7eEcWAHbAIACGN";
$qrUtil = new qrClass();

$ww_ticket =$qrUtil->getNewTicket("o7XC90jGgVsu2ra0omYf2UY900Yo",$accessToken,"Hello Workd!");
echo $ww_ticket;

class qrClass {

    public function __construct() {

    }


    function getNewTicket($wwOpenid,$accessTokenR,$contentStr){

      //  echo $wwOpenid;
        echo $accessTokenR;

      //  $jsonData2 = '{"kf_account": "GXKF@LongChuangDriveExam", "nickname": "共享考车客服", "password":"gongxiangkf"}';
        $jsonData2 = '{"touser":'."\"".$wwOpenid."\"".', "msgtype": "text", "text":{"content":'."\"".$contentStr."\"".'}}';

        //echo '********';
echo $jsonData2;
//echo '********';
//$jj = json_encode($jsonData2);
//$jsonData = "{'expire_seconds': 604800, 'action_name': 'QR_STR_SCENE', 'action_info': {'scene': {'scene_str': {$openidWW}}}}";
       // $qrURL = "https://api.weixin.qq.com/customservice/kfaccount/add?access_token=$accessTokenR";
        $qrURL = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=$accessTokenR";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "$qrURL");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// 跟踪重定向属性
        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Expect:'));

        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData2 );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
        }

        curl_close($ch);

//echo $tmpInfo;

    }
}




/*
$openidWW = "\"<script type=\"text/javascript\">  var openidLocal1 = localStorage.getItem(\"openid\"); document.write(openidLocal1)</script>\"";
//echo "<script type=\"text/javascript\">document.write(openidLocal1)</script>";
echo "==-==".$openidWW.'==-==';
$jsonData1 = '{"expire_seconds": 604800, "action_name": "QR_STR_SCENE", "action_info": {"scene": {"scene_str": "shengChengZheID"}}}';
$jsonData2 = '{"expire_seconds": 604800, "action_name": "QR_STR_SCENE", "action_info": {"scene": {"scene_str":'."\"".$openidWW."\"".'}}}';
echo '********';
echo $jsonData2;
echo '********';
$jj = json_encode($jsonData2);
$jjj = json_decode($jj);
$jsonData = "{'expire_seconds': 604800, 'action_name': 'QR_STR_SCENE', 'action_info': {'scene': {'scene_str':\"{$openidWW}\"}}}";
$qrURL = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=$accessToken";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "$qrURL");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// 跟踪重定向属性
curl_setopt($ch,CURLOPT_HTTPHEADER,array('Expect:'));

curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData2);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$tmpInfo = curl_exec($ch);
if (curl_errno($ch)) {
    echo curl_error($ch);
}

curl_close($ch);
echo '$$$$$$$$$$$';
echo $tmpInfo;
echo '$$$$$$$$$$$';
$tc = json_decode($tmpInfo);
$ticket = $tc->ticket;
echo '**** Ticket ***';
echo $ticket;
echo '*******';
*/
/*
//$httpUtil = new httpU();
//
//$url =  'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQGa7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAydC13ZHNVSk1lWmkxaHZiUnhxY0YAAgTf0GtaAwSAOgkA';
//$img =  $httpUtil->https_request($url);
//
////echo $img;
//
//// 定义verify  class
//class httpU {
//
//    public function __construct()
//    {
//
//    }
//
//    public function https_request($url, $data = null){
//
//        $curl = curl_init();
//        curl_setopt($curl,CURLOPT_URL,$url);
//        curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,0);
//        curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,0);
//        if (!empty($data)){
//            curl_setopt($curl,CURLOPT_POST,1);
//            curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
//        }
//        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
//        $output = curl_exec($curl);
//        curl_close($curl);
//        return $output;
//    }
//
//    }
*/

//./localPHP/
//$conttent = file_get_contents("access_token.php");
////$data22 = json_decode($conttent);
////echo $data22->
//echo '|=|'.json_encode($conttent);

/*
$ch
    = curl_init();
$timeout
    = 15;
curl_setopt
($ch, CURLOPT_URL, 'http://longchuangkeji.com/lcjg/exam/localPHP/access_token.php');
curl_setopt
($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt
($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
$file_contents = curl_exec($ch);
curl_close($ch);
echo "curl获取数据";
echo $file_contents;
echo '。。。。';
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>分享龙创交规</title>
</head>


<body>

<h3>正在学车，准备学车的朋友请注意！</h3>
<h3>免费试用 技巧学习科目一、科目四</h3>
<br>
<hr>
<br>
<!--http://longchuangkeji.com/lcjg/exam/wxResource/imgs/erweima.jpg-->
<!--https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQG_8DwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyTTIzUHM2Sk1lWmkxZzF3UXhxMWkAAgSB5WpaAwSAOgkA-->
<!--<img style="width: 50%;float: left;" src=--><?php //echo "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".$ww_ticket ?><!-- >-->
<br><br><br>
<label>长按识别图中二维码，或扫描二维码</label>


<div style="float: left;width: 90%;margin-left: 5%">
    <br>
    <hr>
    <h5>龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱</h5>
    <h1 id="hhh"></h1>
</div>


</body>

<script type="text/javascript" >

    var openidLocal = localStorage.getItem("openid");

    var hhh = document.getElementById('hhh');

    hhh.innerHTML = openidLocal;

</script>
</html>
