<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/1/26
 * Time: 14:58
 */
// $xxxx = '';
//require_once 'wxResource/bmobPhpSdk/lib/BmobObject.class.php';
$wwOpenid = $_GET['zID'];

//$token = $_GET['token'];
//$wwOpenid = "000001";
//require_once './localPHP/jssdk.php';
//$jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");
//$signPackage = $jssdk->GetSignPackage();

//$accessToken = $jssdk->getAccessToken();
//echo '===== Token =====';
//echo $accessToken;
//echo '----------';

$qrUtil = new qrClass();

$ww_ticket =$qrUtil->getNewTicket($wwOpenid,'');

//$objIDbmob = $qrUtil->bmobObjId;

class qrClass {

    var $bmobObjId;
    public function __construct() {

    }
/*
    function getQRTicket($openid,$accessToken) {

        // 取数据
        $bmobObj = new BmobObject("WX_user");

        $currentOpenID = $openid;
        $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
        $res    = $bmobObj->get("",array("$queryStr"));
        $res1   = $res->results;
        $currentObj = $res1[0];
        // objectId
        $cObjID = $currentObj->objectId;
        $qr_ticket = $currentObj->qr_ticket;
        $qr_expire = $currentObj->qr_expire;
        //    echo '###########';
        //  echo $qr_ticket;
        // echo $qr_expire;
        $this->bmobObjId = $cObjID;
//echo   $cObjID;

//======------------------======
//var jl = new Bmob.Query(bmobObj);
//jl.equalTo("type2",1);
//var jg = new Bmob.Query(bmobObj);
//jg.equalTo("type2",2);
//var zs = Bmob.Query(bmobObj);
//zs.equalTo("type2",3);

//var zh = new Bmob.Query.or(jl,jg,zs);
//zh.find({
        //       success:function(results){
//var_dump(results);
//},
//error:function(error){
//     echo "Error";
//}
//});


// 模拟随机考试题目
        /*
        require_once 'wxResource/bmobPhpSdk/lib/BmobBql.class.php';
        $bmobBqlX = new BmobBql();
        // SELECT * FROM T_USER  ORDER BY  RAND() LIMIT 10
        // select * from WX_question where type2='860' limit 2
        //  select top N * from tableName order by newid()
        // select  top  10  *  from  表  order  by  newid()
        // SELECT * FROM `table` AS t1 JOIN (SELECT ROUND(RAND() * (SELECT MAX(id) FROM `table`)) AS id) AS t2
         // WHERE t1.id >= t2.id
        //ORDER BY t1.id ASC LIMIT 5
        // SELECT top 1 * FROM [tablename]
        //  where id>=(select max(*) from tablename)*rand()
        $res = $bmobBqlX->query(array('bql'=>"SELECT * FROM WX_question  where type2 = '2' or type2 ='1' or type2 ='3' or type2 ='4' or type2 ='5' or type2 ='6' or type2 ='7' or type2 ='8' limit 1000 "));

        $totalArray = $res->results;
        // 100 个随机索引
        $tmpArray = array_rand($totalArray,100);

        // var_dump($tmpArray);
        // 取出的100道题目
        $wxRes = array();
        foreach ($tmpArray as $index){

            array_push($wxRes,$totalArray[$index]);

        }
        var_dump($wxRes);
        var_dump($tmpArray);
        */
//======-----------------------======

/*
//$data = json_decode(get_php_file("ticket.php"));
//$qr_ticket = $data->qr_ticket;
        if ($currentObj->expire_time < time()) {
//echo '已过期';
// 过期 重新生成  ticket
//    gQEc8TwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyQkNpQnQySk1lWmkxS1NKcDFxY1QAAgQ2s5BaAwSAOgkA


            $qr_ticket = $this->getNewTicket($openid,$accessToken);
//echo '尚未取得ticket';
//echo $qr_ticket;
            if ($qr_ticket) {
//echo '取得ticket';
                //              echo $qr_ticket;
//    $data->expire_time = time() + 7000;
//    $data->jsapi_ticket = $ticket;
//    set_php_file("ticket.php", json_encode($data));
                // 将获取到的的ticket存储起来
                $newExpire_time = time()+604700;
                $res = $bmobObj->update("$cObjID",array("qr_ticket"=>$qr_ticket,"qr_expire"=>$newExpire_time));
            }
            //  return  $ticket;
        } else {
            // ticket 未过期
//        $ticket = $data->jsapi_ticket;
            //    $ticket = $qr_ticket;
        }
//     echo '--';
        //       echo $qr_ticket;
        //     echo '--';
        return $qr_ticket;
    }
*/
    function getNewTicket($wwOpenid,$accessTokenR){
//echo $wwOpenid;
//        echo $accessTokenR;
        // 临时二维码
    //    $jsonData2 = '{"expire_seconds": 604800, "action_name": "QR_STR_SCENE", "action_info": {"scene": {"scene_str":'."\"".$wwOpenid."\"".'}}}';
      // 永久二维码
        $jsonData2 = '{"action_name": "QR_LIMIT_SCENE", "action_info": {"scene": {"scene_str":'."\"".$wwOpenid."\"".'}}}';

        //echo '********';
//echo $jsonData2;
//echo '********';
//$jj = json_encode($jsonData2);
//$jsonData = "{'expire_seconds': 604800, 'action_name': 'QR_STR_SCENE', 'action_info': {'scene': {'scene_str': {$openidWW}}}}";
        $qrURL = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=9_u17n_Jkl9bq4J_rdAHKw-BGAWhY2pHe0MtQkkZG3l19pEJtCIDywu9uq3gGIncmfALGAlgWlbO-aolnF6wdKNafBQ6zATDT3MvLinpzp38u6FnUhW39NOoJqg3HvWf_CCKn50epec0v1WMEGUIUfAFAKYK";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "$qrURL");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// 跟踪重定向属性
        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Expect:'));

        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData2 );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
        }

        curl_close($ch);

echo $tmpInfo;
        $tc = json_decode($tmpInfo);
        $ticket = $tc->ticket;
//    $expire = $tc->expire_seconds;
//echo '**** Ticket ***';
echo $ticket;
//echo '*******';
        return $ticket;

    }
}

//=============================================================================

//$openidWW1 = "<script type=\"text/javascript\">  var openidLocal1 = localStorage.getItem(\"openid\"); document.write(openidLocal1)</script>";
//$openidWW = "\"<script type=\"text/javascript\">  var openidLocal1 = localStorage.getItem(\"openid\"); document.write(openidLocal1)</script>\"";

/*
//echo "<script type=\"text/javascript\">document.write(openidLocal1)</script>";
//echo "==-==".$openidWW.'==-==';

$jsonData2 = '{"expire_seconds": 604800, "action_name": "QR_STR_SCENE", "action_info": {"scene": {"scene_str":'."\"".$wwOpenid."\"".'}}}';
//echo '********';
//echo $jsonData2;
//echo '********';
//$jj = json_encode($jsonData2);
//$jsonData = "{'expire_seconds': 604800, 'action_name': 'QR_STR_SCENE', 'action_info': {'scene': {'scene_str': {$openidWW}}}}";
$qrURL = "https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=$accessToken";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "$qrURL");
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// 跟踪重定向属性
curl_setopt($ch,CURLOPT_HTTPHEADER,array('Expect:'));

curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData2 );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$tmpInfo = curl_exec($ch);
if (curl_errno($ch)) {
    echo curl_error($ch);
}

curl_close($ch);

//echo $tmpInfo;
$tc = json_decode($tmpInfo);
$ticket = $tc->ticket;
//echo '**** Ticket ***';
//echo $ticket;
//echo '*******';
*/
/*
//$httpUtil = new httpU();
//
//$url =  'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQGa7zwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAydC13ZHNVSk1lWmkxaHZiUnhxY0YAAgTf0GtaAwSAOgkA';
//$img =  $httpUtil->https_request($url);
//
//echo $img;
//
// 定义verify  class
//class httpU {
//
//    public function __construct()
//    {
//
//    }
//
//    public function https_request($url, $data = null){
//
//        $curl = curl_init();
//        curl_setopt($curl,CURLOPT_URL,$url);
//        curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,0);
//        curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,0);
//        if (!empty($data)){
//            curl_setopt($curl,CURLOPT_POST,1);
//            curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
//        }
//        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
//        $output = curl_exec($curl);
//        curl_close($curl);
//        return $output;
//    }
//
//    }
*/


?>

<!DOCTYPE html>
<html lang="en">
<head >
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！">
    <meta name="keywords" content="龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！">
    <title>分享龙创交规</title>
    <meta name="author"content="龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！">
    <script type="text/javascript" src="wxResource/bmob_jssdk/jquery.min.js"></script>
    <script type="text/javascript" src="wxResource/bmob_jssdk/bmob.js"></script>
    <script type="text/javascript" src="http://res.wx.qq.com/open/js/jweixin-1.2.0.js"></script>


    <script type="text/javascript" src="thirdHelp/clickimg/zooming.js"></script>
    <link rel="stylesheet" type="text/css" href="thirdHelp/clickimg/zzsc.css">
</head>
<style type="text/css">
    .container {
        margin: 0 auto;
    }

    .content {
        max-width: 660px;
        margin: 0 auto;
    }

    .content img {
        max-width: 100%;
    }

    @media (max-width: 800px) {
        .content {
            max-width: 100%;
            margin: 20px;
        }
    }
</style>

<body onload="shareLoadAction()">

<div class="container">
    <section class="content">
        <!--    <p><button onclick="infoAction()">显示弹窗</button></p>-->

        <h3>正在学车，准备学车的朋友，欢迎关注龙创交规！</h3>
        <h4>免费试用 技巧学习科目一、科目四</h4>
            <br>

            <!--http://longchuangkeji.com/lcjg/exam/wxResource/imgs/erweima.jpg-->
            <!--https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=gQG_8DwAAAAAAAAAAS5odHRwOi8vd2VpeGluLnFxLmNvbS9xLzAyTTIzUHM2Sk1lWmkxZzF3UXhxMWkAAgSB5WpaAwSAOgkA-->
            <img style="width: 50%;float: left;" src=<?php echo "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=".$ww_ticket ?> >
            <h1> <?php  echo '~~~~~~~~~';  ?> </h1>
            <br><br><br>
            <label>长按识别图中二维码，或扫描二维码</label>


            <div style="float: left;width: 90%;margin-left: 5%">
                <br>

                <h5>龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱</h5>
                <h1 id="hhh1"></h1>

                <h3>教练提成规则：</h3>
            </div>

            <img  src="wxResource/newImages/explainLevel.jpg" data-action="zoom" />


    </section
</div>



</body>
<script type="text/javascript" >

    var openidLocal = localStorage.getItem("openid");

    var hhh = document.getElementById('hhh');

    hhh.innerHTML = openidLocal;


    function shareLoadAction() {
//alert('ccccccc');
        var ph = localStorage.getItem('phone');
//alert('*******************');
//alert(ph);
        var isPhone = checkPhone(ph);
        if (isPhone === true){


        }else {

            //    infoAction();
        }
    }

    //--------------==================
    function infoAction() {

        Bmob.initialize("70935608c3e10802d71ff99ba5c0e4ad","319e26040d6e57b68fbf98b972ba6f6e");

        var mask = document.createElement('div');
        mask.id = "mask";
        mask.style.backgroundColor = 'lightblue';
        mask.style.width = "100%";
        mask.style.height = "100%";
        mask.style.position = "absolute";
        mask.style.top  = "0px";
        mask.style.left = "0%";
        //  mask.style.filter = 'alpha(opacity=5%)';
        //        mask.style.opacity=0.4;
        //      mask.style.zIndex = 20;
        mask.style.backgroundColor = "rgba(0,0,0,0.5)";
        document.body.appendChild(mask);


        var alertWin = document.createElement('div');
        alertWin.id = "alertWin";
        alertWin.style.width = "90%";
        alertWin.style.height = "auto";
        //    alertWin.position = "absolute";
        alertWin.style.marginTop = "30%";
        alertWin.style.marginLeft = '5%';
        alertWin.style.backgroundColor = 'lightskyblue';
        alertWin.style.opacity=1;
        alertWin.style.borderRadius = "5px";
        //       alertWin.style.zIndex = 30;
        mask.appendChild(alertWin);

        var space2 = document.createElement('p');
        space2.textContent = ' 2  ';
        space2.style.color = "lightskyblue";
        alertWin.appendChild(space2);

        var title = document.createElement('p');
        title.textContent = "完善个人信息";
        title.style.textAlign = 'center';
        title.style.fontSize = "15px";
        title.style.color = "white";
        alertWin.appendChild(title);



        var tips = document.createElement('label');
        tips.textContent = "请完善您的个人信息，让更多的学员找到您。";
        tips.style.color = 'red';
        tips.style.fontSize = "13px";
        alertWin.appendChild(tips);

        var nameC = document.createElement('p');
        nameC.textContent = " 真实姓名  ";
        nameC.style.marginLeft = "5%";
        nameC.style.color = "white";
        alertWin.appendChild(nameC);

        var nameInput     = document.createElement('input');
        nameInput.name  = 'rName';
        nameInput.id = 'iName';
        nameInput.type    = 'text';
        nameInput.style.width = "60%";
        nameInput.style.height = "30px";
        nameC.appendChild(nameInput);

        var cPhone = document.createElement('p');
        cPhone.textContent = '  手机号码  ';
        cPhone.style.marginLeft = '5%';
        cPhone.style.color = "white";
        //  cPhone.style.height = '30px';
        alertWin.appendChild(cPhone);

        var phone = document.createElement('input');
        phone.name = 'phone';
        phone.type = 'text';
        phone.id = 'iPhone';
        phone.style.width = '60%';
        phone.style.height = "30px";
        cPhone.appendChild(phone);

        var saveBtn = document.createElement('button');
        saveBtn.textContent = "保存";
        saveBtn.style.width = '30%';
        saveBtn.style.marginLeft = '15%';
        saveBtn.style.border = 'white';
        saveBtn.style.height = '36px';
        saveBtn.style.backgroundColor = "ghostwhite";
        saveBtn.style.fontSize = "14px";
        saveBtn.style.color = "darkblue";
        //  saveBtn.style.position = 'ablolute';
        alertWin.appendChild(saveBtn);

        var cancel = document.createElement('button');
        cancel.textContent = "取消";
        cancel.style.border = "white";
        cancel.style.width = "30%";
        cancel.style.height = '36px';
        cancel.style.marginLeft = '10%';
        cancel.style.backgroundColor = "ghostwhite";
        cancel.style.fontSize = "14px";
        cancel.style.color  = "darkblue";
        alertWin.appendChild(cancel);
        cancel.addEventListener('click',cancelAction);
        saveBtn.addEventListener('click',saveAction);

        var space1 = document.createElement('p');
        space1.textContent = ' 1  ';
        space1.style.color = "lightskyblue";
        alertWin.appendChild(space1);

    }

    function saveAction() {

//alert('xxx');
        var name = document.getElementById('iName').value;
        var phone = document.getElementById('iPhone').value;

        var isphone = checkPhone(phone);

        if (isphone === true){



//上传电话和姓名到Bmob


//var objId = localStorage.getItem('userObjID');

            var  WX_user = Bmob.Object.extend("WX_user");
            var  queryWR = new Bmob.Query(WX_user);
            var currentOpenID = window.localStorage.getItem('currentOpenID');
            queryWR.equalTo("openID", currentOpenID);
//alert(currentOpenID);
            //      alert('yyy');
            queryWR.find({
                success:function (results) {

                    var object = results[0];
//alert('qtmlgb');
//alert(JSON.stringify(object));


                    var GameScore = Bmob.Object.extend("WX_user");
                    var query = new Bmob.Query(GameScore);
                    //   alert('save =======!');
                    // 这个 id 是要修改条目的 id，你在生成这个存储并成功时可以获取到，请看前面的文档
                    var wwobjId = '<?php echo  $objIDbmob; ?>';
//    alert(wwobjId);
                    localStorage.setItem('phone',phone);
                    query.get(wwobjId, {
                        success: function(gameScore) {
                            // 回调中可以取得这个 GameScore 对象的一个实例，然后就可以修改它了

//localStorage.setItem('phone',phone);
                            alert('保存成功！');
                            gameScore.set('phone', phone);
                            gameScore.set('realname', name);
                            gameScore.save();
                            cancelAction();

                            // The object was retrieved successfully.
                        },
                        error: function(object, error) {
                            alert(error);
                        }
                    });


                },
                error: function(error) {
                    alert("查询失败: " + error.code + " " + error.message);
                }
            });





        }else {

            alert("请填写正确格式的手机号码！");

        }

    }

    function cancelAction() {

        document.body.removeChild(document.getElementById('mask'));
    }

    function checkPhone(phone){
        //  var phone = document.getElementById('phone').value;
        if(!(/^1[34578]\d{9}$/.test(phone))){
            //     alert("手机号码有误，请重填");
            return false;
        }else {
            return true;
        }
    }

    //======================------
    var imgUrl = 'http://longchuangkeji.com/lcjg/exam/wxResource/imgs/ke1ke4.png';  // 分享后展示的一张图片
    var lineLink = ''; // 点击分享后跳转的页面地址
    var descContent = '龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！';  // 分享后的描述信息
    var shareTitle = '龙创交规分享';  // 分享后的标题
    var appid = '';  // 应用id,如果有可以填，没有就留空

    function shareFriend() {
        WeixinJSBridge.invoke('sendAppMessage',{
            "appid": appid,
            "img_url": imgUrl,
            "img_width": "200",
            "img_height": "200",
            "link": lineLink,
            "desc": descContent,
            "title": shareTitle
        }, function(res) {
            //_report('send_msg', res.err_msg);  // 这是回调函数，必须注释掉
        })
    }
    function shareTimeline() {
        WeixinJSBridge.invoke('shareTimeline',{
            "img_url": imgUrl,
            "img_width": "200",
            "img_height": "200",
            "link": lineLink,
            "desc": descContent,
            "title": shareTitle
        }, function(res) {
            //_report('timeline', res.err_msg); // 这是回调函数，必须注释掉
        });
    }
    function shareWeibo() {
        WeixinJSBridge.invoke('shareWeibo',{
            "content": descContent,
            "url": lineLink,
        }, function(res) {
            //_report('weibo', res.err_msg);
        });
    }
    // 当微信内置浏览器完成内部初始化后会触发WeixinJSBridgeReady事件。
    document.addEventListener('WeixinJSBridgeReady', function onBridgeReady() {
        // 发送给好友
        WeixinJSBridge.on('menu:share:appmessage', function(argv){
            shareFriend();
        });
        // 分享到朋友圈
        WeixinJSBridge.on('menu:share:timeline', function(argv){
            shareTimeline();
        });
        // 分享到微博
        WeixinJSBridge.on('menu:share:weibo', function(argv){
            shareWeibo();
        });
    }, false);

</script>
</html>