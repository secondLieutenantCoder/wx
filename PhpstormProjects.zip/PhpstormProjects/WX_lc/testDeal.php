<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/2/24
 * Time: 16:49
 */

//echo json_encode(array('id'=>001,'name'=>'zhangsan','CC'=>'Hello world!'));


$yyUtil  = new YYUtil();


$data = json_decode($yyUtil->get_php_file('YYToken.php'));
//var_dump($data);
$yyToken = '';
if($data->expire_time < time()){
    // 已过期
    // 获取新的token
// https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=5bXEMyNk9uZ7Rv0rW78Hsaaw&client_secret=ceIitkK8Zj8DjczLvfnqeo4xGfbgf3NH
    $url="https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=5bXEMyNk9uZ7Rv0rW78Hsaaw&client_secret=ceIitkK8Zj8DjczLvfnqeo4xGfbgf3NH";
    $html = file_get_contents($url);

//    echo $html;
    $res = json_decode($html);
    $yyToken = $res->access_token;
    $refrehToken = $res->refresh_token;
    $expire = $res->expires_in;
echo $yyToken;
echo '已过期';
    $data->expire_time = time() + 2591000;
    $data->yyToken = $yyToken;
    $data->refresh_token = $refrehToken;
    $yyUtil->set_php_file("YYToken.php", json_encode($data));
}else{
    //
$yyToken = $data->yyToken;
echo $yyToken;
echo '未过期';
}

class YYUtil{

    public function __construct()
    {
    }

    public function get_php_file($filename) {
        return trim(substr(file_get_contents($filename), 15));
    }
    public function set_php_file($filename, $content) {
        $fp = fopen($filename, "w");
        fwrite($fp, "<?php exit();?>" . $content);
        fclose($fp);
    }
}



$tex = $_GET['tex'];
//echo $tex;
$eTex = urlencode($tex);
$url="http://tsn.baidu.com/text2audio?lan=zh&ctp=1&cuid=abcdxxx&tok=$yyToken&tex=$eTex&vol=9&per=0&spd=5&pit=5";

echo $url;

$html = file_get_contents($url);
//echo $html;
file_put_contents('audio.mp3',$html);

//echo '-------------';


// "{"access_token":"24.b5b35f9689b93cc3372f582c3aa4ae93.2592000.1522129514.282335-10790741","session_key":"9mzdWW83AFo5zJJ9I7YYg1AAIC44U25d03LDzFn+XcxdeRUG8Dv+qYzldWfWSKGAZYT+43ZEVuoIWVpj\/qkYzxzI117jXg==","scope":"public brain_all_scope audio_voice_assistant_get audio_tts_post wise_adapt lebo_resource_base lightservice_public hetu_basic lightcms_map_poi kaidian_kaidian ApsMisTest_Test\u6743\u9650 vis-classify_flower bnstest_fasf lpq_\u5f00\u653e cop_helloScope ApsMis_fangdi_permission","refresh_token":"25.aef15b403891d83c9e1d95d85f312877.315360000.1834897514.282335-10790741","session_secret":"34e3c1ad249d03610c71d1fd3f1bdecb","expires_in":2592000}
//数据: string(654) "{"access_token":"24.69e2c5025b0bf0fc439224f5804e4040.2592000.1522129854.282335-10790741","session_key":"9mzdDc9xyymxifHHsR2JqL2aiBdFn\/USsSsyVh9MbSkbYgBCFscRjz4KnkW1ZjEdVmOdUelaBbhhcKuhEGHciuNQL0VQUA==","scope":"public brain_all_scope audio_voice_assistant_get audio_tts_post wise_adapt lebo_resource_base lightservice_public hetu_basic lightcms_map_poi kaidian_kaidian ApsMisTest_Test\u6743\u9650 vis-classify_flower bnstest_fasf lpq_\u5f00\u653e cop_helloScope ApsMis_fangdi_permission","refresh_token":"25.db36a75d031d1cc0c006155fd8a103e7.315360000.1834897854.282335-10790741","session_secret":"6f10c5954a7ddffd83daee543038db85","expires_in":2592000}