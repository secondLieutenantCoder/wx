<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/5/17
 * Time: 17:52
 */

?>

<!
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    <title>提现</title>
</head>
<script src="https://apps.bdimg.com/libs/jquery/2.1.4/jquery.min.js"></script>
<body style="background-color: ghostwhite">
<br>
<br>
<p style="color: red;">* 请确认您的微信已实名(具备收发红包能力)。</p>
<p><button style="width: 25%;height: 35px;border: white;background: whitesmoke;">姓名:</button><input type="text" name="nameName" id="nameID" style="width: 70%;height: 30px;"></p>
<p style="color: red;">* 提现金额大于1元。</p>
<p><button style="width: 25%;height: 40px;border: white;background: whitesmoke;">提现金额:</button><input type="text" name="nameMoney" id="moneyID" style="width: 70%;height: 30px;"></p>

<button onclick="tixianAction(this)" style="margin-left: 30%;width: 40%;height: 40px;background-color: #8EE5EE;border: white;border-radius: 5px">申请提现</button>

<br>
<br>
<p></p>
<script>

    var a = '36';
    var b = 5;
    if (
        >a){

        alert('5>36');
    }else {

        alert('正常');
    }


    document.oncontextmenu=new Function("return false");
    document.onselectstart=new Function("return false");

    function tixianAction(btn) {
        var name = document.getElementById('nameID').value;
        var money = document.getElementById('moneyID').value;
        var openid = 'o7XC90jGgVsu2ra0omYf2UY900Yo';

        alert(name);
        alert(money.substr(0,1));
        var isMoney = checkCount(money);
       if (name.length < 1){
           alert('请填写实名认证的姓名！');
       }else if(isMoney === false){
           alert('请填写整数金额！');
       }else if(money.substr(0,1) == 0){
            alert('请填写准确金额！');

       }else {

           $.post("../weixinPay/wxChange.php",
               {
                   amount:money,
                   name:name,
                   openid:openid
               },
               function(data,status){
                   alert("数据: \n" + data + "\n状态: " + status);
                   alert("payment_no=="+data[payment_no]);
                   btn.onclick = null;
                   alert('提现');
               });
       }






        // btn.onclick = null;
        // $.post("../weixinPay/wxChange.php",
        //     {
        //         amount:money,
        //         name:name,
        //         openid:openid,
        //         kind:kind,
        //         async: false
        //     },
        //     function(data,status){
        //
        //         if (status == 'success'){
        //
        //             var result = JSON.parse(data);
        //
        //             var result_code = result.result_code;
        //             if (result_code === 'FAIL' ){
        //
        //                 if (result.err_code === 'SENDNUM_LIMIT'){
        //                     alert('每个用户每天限提现一次，您已超过限额次数！');
        //                 }else{
        //                     alert(result.err_code_des);
        //                 }
        //
        //             }else if(result_code === 'SUCCESS'){
        //                 alert('提现成功！');
        //                 parent.WeixinJSBridge.call('closeWindow');
        //             }
        //
        //
        //         }else{
        //
        //             alert('网络错误，请检查网络后重试！');
        //
        //         }
        //
        //     });








    }

    // =====验证整数 - 课时数量 ====
    function checkCount(num) {
        var  pat = /^[0-9]+$/;
        if (pat.test(num)){
            return true;
        }else{
            return false;
        }
    }

</script>

<!--<script type="text/javascript">-->
<!--    // 对浏览器的UserAgent进行正则匹配，不含有微信独有标识的则为其他浏览器-->
<!--    var useragent = navigator.userAgent;-->
<!--    if (useragent.match(/MicroMessenger/i) != 'MicroMessenger') {-->
<!--        // 这里警告框会阻塞当前页面继续加载-->
<!--            document.head.innerHTML = '<title>抱歉，出错了</title><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0"><link rel="stylesheet" type="text/css" href="https://res.wx.qq.com/open/libs/weui/0.4.1/weui.css">';-->
<!--            document.body.innerHTML = '<div class="weui_msg"><div class="weui_icon_area"><i class="weui_icon_info weui_icon_msg"></i></div><div class="weui_text_area"><h4 class="weui_msg_title">请在微信客户端打开链接</h4></div></div>';-->
<!---->
<!--        //alert('已禁止本次访问：您必须使用微信内置浏览器访问本页面！');-->
<!--        // 以下代码是用javascript强行关闭当前页面-->
<!--        var opened = window.open('about:blank', '_self');-->
<!--        opened.opener = null;-->
<!--        opened.close();-->
<!--    }-->
<!--</script>-->


<!--<script type="text/javascript">-->
<!--    var ua = navigator.userAgent.toLowerCase();-->
<!--    var isWeixin = ua.indexOf('micromessenger') != -1;-->
<!--    var isAndroid = ua.indexOf('android') != -1;-->
<!--    var isIos = (ua.indexOf('iphone') != -1) || (ua.indexOf('ipad') != -1);-->
<!--    if (!isWeixin) {-->
<!--        document.head.innerHTML = '<title>抱歉，出错了</title><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=0"><link rel="stylesheet" type="text/css" href="https://res.wx.qq.com/open/libs/weui/0.4.1/weui.css">';-->
<!--        document.body.innerHTML = '<div class="weui_msg"><div class="weui_icon_area"><i class="weui_icon_info weui_icon_msg"></i></div><div class="weui_text_area"><h4 class="weui_msg_title">请在微信客户端打开链接</h4></div></div>';-->
<!--    }-->
<!--</script>-->

</body>
</html>