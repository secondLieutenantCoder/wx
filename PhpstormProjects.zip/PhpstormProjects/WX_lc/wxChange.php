<?php

require './lib/BmobObject.class.php';
//结算
$data=array(
    'mch_appid'=>'wx2d832d1471e5b',//商户账号appid
    'mchid'=>'1261293001',//商户号
    'nonce_str'=>'616516516',//随机字符串
    'partner_trade_no'=>'20170803080216798',//商户订单号
    'openid'=>'oVeFnwEpnLOcLNljD4uIAj07d0R8',//用户openid
    'check_name'=>'NO_CHECK',//校验用户姓名选项,
    're_user_name'=>'蒲松林',//收款用户姓名
    'amount'=>'1',//金额
    'desc'=>'结算www.pusonglin.cn',//企业付款描述信息
    'spbill_create_ip'=>'60.205.45.00',//Ip地址
);
$secrect_key='Zvj4gxGrJvMNUvoEHojOYZuYUuBYn0ZR';///这个就是个API密码。32位的。。随便MD5一下就可以了
$data=array_filter($data);
ksort($data);
$str='';
foreach($data as $k=>$v) {
    $str.=$k.'='.$v.'&';
}
$str.='key='.$secrect_key;
$data['sign']=md5($str);
$xml=arraytoxml($data);
// echo $xml;
$url='https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
$res=curl($xml,$url);
$return=xmltoarray($res);

// strcmp(string1,string2)
//$return_code = $return['return_code'];
//$result_code = $return['result_code'];
$return_code = 'SUCCESS';
$result_code = 'SUCCESS';
$WWReturn = array();
if (strcmp($return_code,'SUCCESS') == 0 && strcmp($result_code,'SUCCESS')==0){

    // 提现成功
    // 写 提现记录
    // 将提成记录添加到 提成记录表中
    $bmobObjC = new BmobObject("WXCashRecord");

    $resR = $bmobObjC->create(array("openID"=>"o7lasdjfoewjy0","name"=>"王伟","payment_no"=>"100020181234654650201236","cash"=>10,));
    // 修改已提现金额

    $userObj = new BmobObject("WX_user");
    $currentOpenID = 'o7XC90jGgVsu2ra0omYf2UY900Yo';
    $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
    $res=$userObj->get("",array("$queryStr"));
    $res1 = $res->results;
    $currentObj =  $res1[0];

    $objId = $currentObj->objectId;
    $money = $currentObj->money;
    $tokenMoney = $currentObj->tokenMoney;
    $newToken = $tokenMoney + 10;
    $updatep2 = $userObj->update($objId,array("tokenMoney"=>$newToken,));

    $WWReturn = array(
        "code" =>'SUCCESS',
        "msg"  =>'0'
    );

}else if(strcmp($return_code,'SUCCESS') == 0 && strcmp($result_code,'FAIL')==0 ){
    // 通信成功 业务失败
    $WWReturn = array(
        "code" =>'FAIL',
        "msg"  =>'1'
    );

}else if(strcmp($return_code,'FAIL') == 0){
    // 请检查网络
    $WWReturn = array(
        "code" =>'FAIL',
        "msg"  =>'2'
    );

}


$jsonReturn = json_encode($return);
print_r($jsonReturn);
// echo getcwd().'/cert/apiclient_cert.pem';die;
function unicode() {
    $str = uniqid(mt_rand(),1);
    $str=sha1($str);
    return md5($str);
}
function arraytoxml($data){
    $str='<xml>';
    foreach($data as $k=>$v) {
        $str.='<'.$k.'>'.$v.'</'.$k.'>';
    }
    $str.='</xml>';
    return $str;
}
function xmltoarray($xml) {
    //禁止引用外部xml实体
    libxml_disable_entity_loader(true);
    $xmlstring = simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA);
    $val = json_decode(json_encode($xmlstring),true);
    return $val;
}

function curl($param="",$url) {

    $postUrl = $url;
    $curlPost = $param;
    $ch = curl_init();                                      //初始化curl
    curl_setopt($ch, CURLOPT_URL,$postUrl);                 //抓取指定网页
    curl_setopt($ch, CURLOPT_HEADER, 0);                    //设置header
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);            //要求结果为字符串且输出到屏幕上
    curl_setopt($ch, CURLOPT_POST, 1);                      //post提交方式
    curl_setopt($ch, CURLOPT_POSTFIELDS, $curlPost);           // 增加 HTTP Header（头）里的字段
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);        // 终止从服务端进行验证
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch,CURLOPT_SSLCERT,MODULE_ROOT.'/WxpayAPI/cert/apiclient_cert.pem'); //这个是证书的位置绝对路径
    curl_setopt($ch,CURLOPT_SSLKEY,MODULE_ROOT.'/WxpayAPI/cert/apiclient_key.pem'); //这个也是证书的位置绝对路径
    $data = curl_exec($ch);                                 //运行curl
    curl_close($ch);
    return $data;
}
?>