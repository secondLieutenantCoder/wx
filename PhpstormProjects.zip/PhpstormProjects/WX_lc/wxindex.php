<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/1/18
 * Time: 08:47
 */
include_once './exam/wxResource/bmobPhpSdk/lib/BmobObject.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobUser.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobBatch.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobFile.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobImage.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobRole.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobPush.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobPay.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobSms.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobApp.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobSchemas.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobTimestamp.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobCloudCode.class.php';
include_once './exam/wxResource/bmobPhpSdk/lib/BmobBql.class.php';
require_once 'exam/localPHP/jssdk.php';




$verifyObj = new verifyClass();

$verifyObj->verifyFunction(); // 配置URL的方法  仅配置时走一次

$verifyObj->responseMsg();   // 回复订阅信息

//$verifyObj->customMenu();   // 自定义菜单
$verifyObj->menuBuild();
$openid = 0;
// 定义verify  class
class verifyClass {

    public function __construct()
    {

    }

    // 配置验证函数
    public function verifyFunction(){
        // 获取参数
        $nonce     = $_GET['nonce'];
        $signature = $_GET['signature'];
        $timestamp = $_GET['timestamp'];
        $token     = 'longchuangjiaogui';
        // 随机生成 需要在配置URL时返回完成验证
        $echostr   = $_GET['echostr'];
        // token timestamp nonce 字典序排序
        $tmpArr    = array($token,$timestamp,$nonce);
        sort($tmpArr,SORT_STRING);
        // 拼接 加密
        $tmpStr    = implode($tmpArr);
        $tmpStr    = sha1($tmpStr);

        // 验证
        if ($tmpStr == $signature && $echostr){// 验证通过

            echo $echostr;
            exit;
        }
        // else{//
        //this->responseMsg();
        //}

    } // verifyFunction end

    // 回复订阅信息

    public function responseMsg(){

        //关注/取消
        /*
         <xml>
        <ToUserName><![CDATA[toUser]]></ToUserName>
        <FromUserName><![CDATA[FromUser]]></FromUserName>
        <CreateTime>123456789</CreateTime>
        <MsgType><![CDATA[event]]></MsgType>
        <Event><![CDATA[subscribe]]></Event>
        </xml>
         */

        // 获取post消息内容
        $postContent = $GLOBALS['HTTP_RAW_POST_DATA'];
        // 解析
        $postObj     = simplexml_load_string($postContent);
        // 检查消息
        if (strtolower($postObj->MsgType) == 'event'){
            echo "event";
            if ($postObj->Event == 'SCAN'){

                $accInfo = $postObj->EventKey;
                // 构建恢复消息
                $toUserName   = $postObj->ToUserName;
                $fromUserName = $postObj->FromUserName;
                $openid = $fromUserName;
                $cTime        = time();
                $msgType      = 'text';
// "欢迎关注龙创交规SaoMa".$openid.'accinfo'.'='.$accInfo;
                $content        =  "欢迎关注龙创交规。龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！";

                $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
                $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
                echo $responseSubsxribe;
            }

            if (strtolower($postObj->Event) == 'subscribe'){// 接收到订阅消息
                echo "subscribe";
                /* 恢复消息的xml 模板
                <xml>

            <ToUserName><![CDATA[toUser]]></ToUserName>

            <FromUserName><![CDATA[fromUser]]></FromUserName>

            <CreateTime>12345678</CreateTime>

            <MsgType><![CDATA[text]]></MsgType>

            <Content><![CDATA[你好]]></Content>

                </xml>
                 */
                // 构建恢复消息
                $toUserName   = $postObj->ToUserName;
                $fromUserName = $postObj->FromUserName;

                $openid = $fromUserName;
                $accInfo = $postObj->EventKey;
                $qrArr   =explode("rscene_",$accInfo);
                $pID     = $qrArr[1];

                $cTime        = time();
                $msgType      = 'text';
                $content      = '欢迎关注龙创交规。龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！';

                $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
                $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
                echo $responseSubsxribe;

                if (strlen("$accInfo")>0){

                    if  (strlen("$pID") == 6){

                        /*
                         *
                         * <xml><ToUserName>< ![CDATA[toUser] ]></ToUserName>
                         * <FromUserName>< ![CDATA[fromUser] ]></FromUserName>
                         * <CreateTime>12345678</CreateTime>
                         * <MsgType>< ![CDATA[news] ]></MsgType>
                         * <ArticleCount>1</ArticleCount>
                         * <Articles>
                         * <item>
                         * <Title>< ![CDATA[title1] ]></Title>
                         * <Description>< ![CDATA[description1] ]></Description>
                         * <PicUrl>< ![CDATA[picurl] ]></PicUrl>
                         * <Url>< ![CDATA[url] ]></Url>
                         * </item>
                         * </Articles>
                         * </xml>
                         * */
                        // 构建回复消息
                        $toUserName   = $postObj->ToUserName;
                        $fromUserName = $postObj->FromUserName;

                        $title = "newsTitle";
                        $desc = "newsDescription";
                        $picUrl = "http://n.sinaimg.cn/translate/33/w500h333/20180504/dpN4-fzyqqiq5871070.jpg";
                        $url = "http://www.longchuangkeji.com/lcjg/exam/chooseWithPic.html".$toUserName;


                       // $openid = $fromUserName;
                    //    $accInfo = $postObj->EventKey;
                     //   $qrArr   =explode("rscene_",$accInfo);
                     //   $pID     = $qrArr[1];

                        $cTime        = time();
                        $msgType      = 'news';
                      //  $content      = '欢迎关注龙创交规。龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！'."$pID";

                        $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><ArticleCount>1</ArticleCount><Articles><item><Title><![CDATA[%s]]></Title><Description><![CDATA[%s]]></Description><PicUrl><![CDATA[%s]]></PicUrl><Url><![CDATA[%s]]></Url></item></Articles></xml>";
                        $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$title,$desc,$picUrl,$url);
                        echo $responseSubsxribe;


                      //  $url = "https://home.firefoxchina.cn/";
                        //Header("Location:$url");

                    }else{

                        // 扫码关注，带场景值（上一级的openID）
                        $preOpenID = $pID;
                        $bmobObj = new BmobObject("WX_user");
                        $queryStr = "where={\"openID\":\"{$preOpenID}\"}";
                        echo $queryStr;
                        $res=$bmobObj->get("",array("$queryStr"));
//
                        var_dump($res);
                        echo '========';
                        $res1 = $res->results;
                        $resObj =  $res1[0];
//echo $resObj->p1;
                        $resp1 = $resObj->p1;
                        $resp2 = $resObj->p2;
//echo $res;
//var_dump($res);
                        echo '---';

//$res2 = $res[0];
// 添加新的关注者 到 数据库
                        $res = $bmobObj->create(array("p1"=>"$preOpenID","openID"=>"$openid","p3"=>"$resp2","p2"=>"$resp1","money"=>"0","lc_state"=>"0","endTime"=>0,"tokenMoney"=>0,));

                    }


                }else{
                    // 搜索关注，没有上级
                    $bmobObj = new BmobObject("WX_user");

                    $res = $bmobObj->create(array("openID"=>"$openid","money"=>"0","lc_state"=>"0","endTime"=>0,"tokenMoney"=>0,));
                }
//$bmobObj = new BmobObject("WX_user");
//$res = $bmobObj->create(array("p1"=>"$pID","openID"=>"ww3666","p2"=>"上上级","money"=>"300","lc_state"=>"0",));

            }else{// unsubscribe 取消关注

                // 构建恢复消息
                $toUserName   = $postObj->ToUserName;
                $fromUserName = $postObj->FromUserName;
                $cTime        = time();
                $msgType      = 'text';
                $content      = "";

                $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
                $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
                echo $responseSubsxribe;
            }
        }else{
            //非推送事件！
            // 构建恢复消息
            $toUserName   = $postObj->ToUserName;
            $fromUserName = $postObj->FromUserName;
            $cTime        = time();
            $msgType      = 'text';
            $content      = '欢迎关注龙创交规。龙创交规，全面技巧语音讲解，技巧灵活，简单易学，文化要求低，轻松学会，省时省力省钱，还有提成拿！';

            $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
            $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
            echo "";
        }


    }//responseMsg end

    //==================- 定义菜单 -=======================
    public function customMenu(){

        header('content-type:text/html;charset=utf-8');
        $accessToken = $this->getWXAccesstoken();
        $postURL     = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$accessToken;
        //构建菜单
        $postMenuArr =array(
            'button'=>array(
                array(
                    'name' => '菜单一',
                    'type'=>'click',
                    'key'  =>'1'
                ), // 第一个一级菜单
                array(
                    'name' => '单页评审',
                    'type' => 'view',
                    'url'  => 'http://1.intcowangwei.applinzi.com/medicalApprove/m_index.html'
                )
            )
        );// 菜单定义 end
        echo $postJson = urldecode(json_encode($postMenuArr));
        // curl 访问
        $a = $this->exeCurl($postURL,'post','json',$postJson);
        echo $a;


    } //customMenu end

    // ==================- 获取 access-token -=============
    public function getWXAccesstoken(){

        /*
                $appID = "wx62732b3c3460b3b1";
                $appSecret = 'cc05112ee2e8f53d80970d0d988398cd';
                $accessUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appID.'&secret='.$appSecret;

                $pageInfo  = file_get_contents($accessUrl);

                $infoObj   = json_decode($pageInfo);

                $accessToken = $infoObj->access_token;
                $expireIn    = $infoObj->expires_in;
        */
        $jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");
        $signPackage = $jssdk->GetSignPackage();
        $accessToken = $jssdk->getAccessToken();
        return $accessToken;
    }//getWXAccessToken end

    // ====================- 执行curl -=================
    public function exeCurl($url,$type,$res,$arr){

        //>1 初始化一个curl 对象
        $ch = curl_init();
        //>2 设置 CURL 的参数
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        if ($type=='post'){// post 的curl 参数配置
            curl_setopt($ch,CURLOPT_POST,1);
            curl_setopt($ch,CURLOPT_POSTFIELDS,$arr);
        }
        //>3 curl 执行
        $output = curl_exec($ch);
        //>4 关闭curl
        //   curl_close($ch);
        echo 'curl';
        echo $res;
        if ($res == 'json'){
            echo curl_errno($ch);
            if (curl_errno($ch)){
                return curl_error($ch);
            }else{
                return json_encode($output,true);
            }
        }

    }

    //------------------------------------------------------------------
    // 自定义菜单 *
    public function menuBuild(){

        echo 'ZDYCD';
        //  $appID     = 'wx87ea4fc3eb058752';
        //$appSecret = '0af3b68f9f1aad44bb1ad926c898e124';

        //$accessUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appID.'&secret='.$appSecret;
        //$output    =$this->https_request($accessUrl);
        //$jsonInfo  = json_decode($output,true);
        //$accessToken = $jsonInfo["access_token"];
        $accessToken = $this->getWXAccesstoken();
        echo $accessToken;

        $jsonMenu = '{  
             "button":[  
             {    
                  "type":"view",  
                  "name":"免费试用题",  
                  "url":"http://www.longchuangkeji.com/lcjg/exam/chooseWithPic.html"  
              },  
              {  
                   "type":"view",  
                   "name":"科一科四",  
                   "url":"https://open.weixin.qq.com/connect/oauth2/authorize?appid=wx62732b3c3460b3b1&redirect_uri=http%3a%2f%2fwww.longchuangkeji.com%2flcjg%2fexam%2fchooseWihPic.php&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect"  
//http://www.longchuangkeji.com/lcjg/exam/menu.html
              },  
              {  
                  "type":"view",
                   "name":"分享",  
                   "url":"http://www.longchuangkeji.com/lcjg/exam/shareQR.php"
               }]  
         }';

        $createURL = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$accessToken;
        $pageInfo1  = file_get_contents($createURL);
//echo '====';
        echo $pageInfo1;
//echo $accessToken;
//echo '-----';
        //         $result =$this->https_request($createURL,$jsonInfo);
        //var_dump($result);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$accessToken);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonMenu);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
        }

        curl_close($ch);

        echo $tmpInfo;

    }

    public function https_request($url, $data = null){

        $curl = curl_init();
        curl_setopt($curl,CURLOPT_URL,$url);
        curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,0);
        curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,0);
        if (!empty($data)){
            curl_setopt($curl,CURLOPT_POST,1);
            curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
        }
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

</body>

<script type="text/javascript" src="./exam/wxResource/bmob_jssdk/bmob-min.js"></script>
<script type="text/javascript" src="./exam/wxResource/bmob_jssdk/bmob.js"></script>

<script type="text/javascript">

    Bmob.initialize("4c2f5fe1bcd717a9232981343a8b8b8e","6a3852634b7483a097d837d49b847c0c");

    var openID = <?php echo $openid ?>;

    var WX_user = Bmob.Object.extend("WX_user");
    alert('xxxxxxx');
    var wx_user = new WX_user;
    wx_user.set("openID","66666333");
    wx_user.set("money","100");

    wx_user.save(null,{
        success: function (object) {

        },
        error:function (model, error) {

        }

    });



</script>
</html>