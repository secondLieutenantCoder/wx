<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/2/3
 * Time: 15:12
 */

require 'YY/AipSpeech.php';

// 你的 APPID AK SK
const APP_ID = '10790741';
const API_KEY = '5bXEMyNk9uZ7Rv0rW78Hsaaw';
const SECRET_KEY = 'ceIitkK8Zj8DjczLvfnqeo4xGfbgf3NH ';

$client = new AipSpeech(APP_ID, API_KEY, SECRET_KEY);

//echo '*****';

$d = date("Y/m/d").'  ----  '.date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d"))));
$t = strtotime($d);
echo '----';
echo time();

echo '---';
$rr = date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d"))));
//echo date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d")));
echo strtotime($rr);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<!--    <meta http-equiv="X-UA-Compatible" content="ie=edge">-->
    <title>语音合成</title>
</head>
<body>

<div>
<hr>
    <h3 id="hhh" style="color: red;">1221</h3>
    <button onclick="madeYYAction()" style="width: 50%;height: 50px;margin-top:50px;margin-left: 25%;background-color: #00FF00;border: white;"> 合成语音 </button>

    <audio id="hc" controls="controls">

        <source src="wrong.mp3" type="audio/mp3">
    </audio>
    <button style="margin-top: 30px;"></button>
</div>

<div>

    <h3 id="redh" style="color: red; font-size: 18px">11111</h3>

    <h3 id="blueh" style="color: blue;font-size: 18px">aaaaa</h3>

    <button onclick="showAction()" style="width: 60%; height: 30px;"> ShowShow </button>
    <button onclick="changeAction()" style="width: 60%; height: 30px;"> 修改语音 </button>

</div>

</body>

<script type="text/javascript" language="JavaScript">

    function changeAction() {

        alert('change');
        // var hhh2 = document.getElementById('hhh');
        // hhh2.innerHTML = 'yyyyyyyyyyy';

        var hc = document.getElementById('hc');

        hc.play();
    }

    function madeYYAction() {

       // alert('开始合成');

        var yy = "<?php
//，2222交警手势题：交警的脸部正对我们是对的，不正对我们的是错的
            $result = $client->synthesis('答错了','zh',1,array(
                'vol' => 5
            ));
            // json_encode($result);
            if(!is_array($result)){

                file_put_contents('wrong.mp3', $result);

            }else{
                echo 'xxx';
//            echo $result->err_no;
//            var_dump($result);
//            $jj = json_encode($result);
//            echo $jj;
                echo $result['err_no'];
            }

            echo 'vvvvv';
            ?>";

        var hhh = document.getElementById('hhh');
        hhh.innerHTML = yy;

    }

    function showAction() {

        localStorage.setItem('redContent','redcontent');

        var bI = document.getElementById('redh');
        bI.innerHTML = localStorage.getItem('redcontent');


        localStorage.setItem('redcontent','bluecontent11111222');

        var redI = document.getElementById('blueh');
        redI.innerHTML = localStorage.getItem('redcontent');
        $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx62732b3c3460b3b1&secret=cc05112ee2e8f53d80970d0d988398cd";
       // echo '---==='.$this-> appId;
       // echo '===---'.$this-> appSecret;
        $res = json_decode($this->httpGet($url));
        $access_token = $res->value;


    }

</script>


</html>
