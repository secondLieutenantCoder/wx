<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/5/28
 * Time: 11:59
 */

require '../lib/BmobObject.class.php';

/*
$bmobObjC = new BmobObject("YZMRecord");

//$cishu = str_pad($newc,4,"0",STR_PAD_LEFT);
//$shulian = str_pad(9,4,"0",STR_PAD_LEFT);
for ($j=1;$j<2;$j++){

    echo 'j==='.$j;
    echo '<br>';
    $masterID = str_pad($j,5,"0",STR_PAD_LEFT);

    $masterID = '0'.$masterID;
    for ($i = 1;$i<100;$i++){

        echo '<br>';
        echo $i;

        $resR = $bmobObjC->create(array("MasterID"=>"$masterID","alreadyRand"=>"-","serNum"=>"$i"));

    }
}
*/


$yzmUtil = new YZMUtil();
// 次数 课时数 主机号
$yzm = $yzmUtil->wwGetYzmAction('040172','000072');

echo '<br>';
echo 'yzm==';
echo $yzm;

  //      生成验证码类
class YZMUtil {

    public function __construct() {

    }

    public function wwGetYzmAction($DATA1,$zhujiid){



     //   $DATA3 = $this->getzcmAction($DATA1,$zhujiid);
        // 验证验证码
        // 查主机号   1-99
// 1.取bmob数据
        $YZMRecordObj = new BmobObject("YZMRecord");

        //  $openID = "o7XC90rRs-eXPUJoBpSgnCs5U1ss";
        $queryStr = "where={\"MasterID\":\"{$zhujiid}\"}";

        $res=$YZMRecordObj->get("",array("$queryStr"));
        $res1 = $res->results;


        $cishu = substr($DATA1,0,2);
        // 次数
        $cishu = $cishu * 1;
        echo 'cishi = '.$cishu;
        if (count($res1) !=  99){
            echo '<<<<<<<<<===99';
            // 没充值生成过验证码
            // 从第一次开始
            // 直接生成验证码 并返回
            // 记录下随机码
            $rand = 0;
            $wZID = $zhujiid * 1;
            if ($wZID <= 20){
                $rand = rand(0, 8);

            }else{
                $rand = rand(0, 9);
            }

            $DATA3 = $this->getzcmAction($DATA1,$zhujiid,$rand);
            $resR = $YZMRecordObj->create(array("MasterID"=>"$zhujiid","alreadyRand"=>"$rand","serNum"=>"$cishu"));            return $DATA3;

        }else {

            echo '>>>>>>>>>>>>99';
            // 第2个100次


            for ($i=0;$i<count($res1);$i++){

                $tmpObj = $res1[$i];
                if ($cishu == $tmpObj->serNum){

                    // 找到当前对应的次数，查看随机码
                    $randStr = $tmpObj->alreadyRand;
                    $cObjId = $tmpObj->objectId;
                    // 如果随机码 = '-' 则 0-9 随机一个生成随机码
                     if (strcmp($randStr,"-") == 0){

                         echo 'w*********w';
                         $rand = 0;
                         $wZID = $zhujiid * 1;
                         if ($wZID <= 20){
                             $rand = rand(0, 8);

                         }else{
                             $rand = rand(0, 9);
                         }

                         $DATA3 = $this->getzcmAction($DATA1,$zhujiid,$rand);
                         $yzmRes = $YZMRecordObj->update($cObjId,array("alreadyRand"=>"$rand"));
                         return $DATA3;

                         // 随机码未使用过
                     }else{

                         $randArr = explode(',',$randStr);
                         $totalRandArr = array();
                         $wZID = $zhujiid * 1;
                         if ($wZID <= 20){
                             // 编号小于20 的主机
                             $totalRandArr = array(0,1,2,3,4,5,6,7,8);

                         }else{
                             // 编号大于 20 的主机
                             $totalRandArr = array(0,1,2,3,4,5,6,7,8,9);


                         }

                         $leftArr = array_diff($totalRandArr,$randArr);

                         $leftArr = array_values($leftArr);

                         $randFake = rand(0,count($leftArr)-1);
                         $rand = $leftArr[$randFake];

                         $DATA3 = $this->getzcmAction($DATA1,$zhujiid,$rand);


                         echo '<br>';
                         echo 'rand===';
                         echo $rand;
                       //  $newRandStr = '';

                         if ($wZID <= 20){
                             // 编号小于20 的主机
                             if (count($randArr) == 8){

                                 $newRandStr = '-';
                                 $yzmRes = $YZMRecordObj->update($cObjId,array("alreadyRand"=>"$newRandStr"));
                             }else{

                                 // 把 本次的随机码记录到Bmob
                                 $newRandStr = $randStr.','.$rand;
                                 $yzmRes = $YZMRecordObj->update($cObjId,array("alreadyRand"=>"$newRandStr"));
                             }

                         }else{
                             // 编号大于 20 的主机

                             if (count($randArr) == 9){

                                 $newRandStr = '-';
                                 $yzmRes = $YZMRecordObj->update($cObjId,array("alreadyRand"=>"$newRandStr"));
                             }else{

                                 // 把 本次的随机码记录到Bmob
                                 $newRandStr = $randStr.','.$rand;
                                 $yzmRes = $YZMRecordObj->update($cObjId,array("alreadyRand"=>"$newRandStr"));
                             }

                         }





                         return$DATA3;
                     }//


                    break;
                }

            }


        }

        // 当前次数已经用过的随机码

        return "\"验证码错误，请联系龙创\"";
        // 使用
    }

    public function getzcmAction($DATA1,$zhujiid,$rand)
    {

        $myrand = array(
            /*	    	0	1	2	3   4	 5	  6	  7	   8	 9	  A	   B	C	 D	  E	   F	*/
            /*0*/	0x07,  0x09,   0x05,   0x03,   0x06,   0x04,   0x02,   0x05,   0x07,   0x08,
            0xf0dfc,0xfeed4,0xfef26,0xf1c32,0xf5334,0xfa375,0xfca7c,0xf7c4c,0xfcc52,0xfC523,
            /*1*/	0x09,   0x05,   0x03,   0x06,   0x04,   0x02,   0x05,   0x07,   0x08, 0x07,
            0xf1adc,0xf23d5,0xf3f18,0xf4c42,0xf6364,0xf7385,0xf9a9c,0xfacac,0xfbcb2,0xfC5c5,
            /*2*/	0x05,   0x03,   0x06,   0x04,   0x02,   0x05,   0x07,   0x08,0x07,  0x09,
            0xf39f8,0xfdee5,0xf9775,0xfa89e,0xfb8e3,0xf3526,0xfca7c,0xf7c4c,0xfcc52,0xfC53c,
            /*3*/	0x03,   0x06,   0x04,   0x02,   0x05,   0x07,   0x08, 0x07,  0x09,   0x05,
            0xf0dfc,0xfeed4,0xfef26,0xf1c32,0xf5334,0xfe27b,0xfac7b,0xfc7c4,0xfb325,0xf6791,
            /*4*/	0x06,   0x04,   0x02,   0x05,   0x07,   0x08, 0x07,  0x09,   0x05,   0x03,
            0xfd0cf,0xf89d5,0xf2343,0xfde32,0xfdfe1,0xf6989,0xf7cac,0xfc47c,0xfbbbb,0xfaaaa,
            /*5*/	0x04,   0x02,   0x05,   0x07,   0x08,0x07,  0x09,   0x05,   0x03,   0x06,
            0xf1234,0xfb5c6,0xfc5b7,0xfa4b6,0xfa8b9,0xfa1b1,0xfa2b2,0xfa3b3,0xfa4b4,0xfa5b5,
            /*6*/	0x02,   0x05,   0x07,   0x08,0x07,  0x09,   0x05,   0x03,   0x06,   0x04,
            0xfb3c3,0xfb4c4,0xfe1f1,0xfe2f2,0xfe3f3,0xfe4f4,0xfe5f5,0xfe6f6,0xfe7f7,0xfe8f8,
            /*7*/	0x05,   0x07,   0x08,  0x07,  0x09,   0x05,   0x03,   0x06,   0x04,   0x02,
            0xf0d1d,0xf1d2d,0xf2d3d,0xf4d5d,0xf5d6d,0xf7d8d,0xfd9c9,0xe5789,0xecc52,0xeC53c,
            /*8*/	0x09,  0x07,   0x03,   0x05,   0x04,   0x06,   0x05,   0x02,   0x08,   0x07,
            0xfacdc,0xfaadd,0xfadcd,0xfa8c9,0xf9876,0xf9963,0xfe791,0xf7e35,0xf52cc,0xf6e5d,
            /*9*/	 0x07,   0x03,   0x05,   0x04,   0x06,   0x05,   0x02,   0x08,   0x07,0x09,
            0xf9876,0xf9963,0xfe791,0xf7e35,0xf52cc,0xf6e5d, 0xfacdc,0xfaadd,0xfadcd,0xfa8c9,
            /*10*/	0x03,   0x05,   0x04,   0x06,   0x05,   0x02,   0x08,   0x07,0x09,  0x07,
            0xfe2f2,0xfe3f3,0xfe4f4,0xfe5f5,0xfe6f6,0xfe7f7,0xfe8f8,0xfb3c3,0xfb4c4,0xfe1f1,
            /*11*/	  0x04,   0x06,   0x05,   0x02,   0x08,   0x07, 0x09,  0x07,   0x03,   0x05,
            0xfa4b4,0xfa5b5,0xf1234,0xfb5c6,0xfc5b7,0xfa4b6,0xfa8b9,0xfa1b1,0xfa2b2,0xfa3b3,
            /*12*/	 0x06,   0x05,   0x02,   0x08,   0x07, 0x09,  0x07,   0x03,   0x05,   0x04,
            0xfb8e3,0xf3519,0xfca7c,0xf7c4c,0xfcc52,0xfC23c, 0xf39f8,0xfdee5,0xf9775,0xfa89e,
            /*13*/	  0x05,   0x02,   0x08,   0x07, 0x09,  0x07,   0x03,   0x05,   0x04,   0x06,
            0xf1c32,0xf5334,0xfe27b,0xfac7b,0xfc7c4,0xfb325,0xf6791, 0xf0dfc,0xfeed4,0xfef26,
            /*14*/	0x02,   0x08,   0x07, 0x09,  0x07,   0x03,   0x05,   0x04,   0x06,   0x05,
            0xfe4f4,0xfe5f5,0xfe6f6,0xfe7f7,0xfe8f8,0xfb3c3,0xfb4c4,0xfe1f1, 0xfe2f2,0xfe3f3,
            /*15*/	0x08,   0x07,0x09,  0x07,   0x03,   0x05,   0x04,   0x06,   0x05,   0x02,
            0xfe8f8,0xfb3c3,0xfb4c4,0xfe1f1, 0xfe2f2,0xfe3f3, 0xfe4f4,0xfe5f5,0xfe6f6,0xfe7f7);

        //  $rand = rand(0,35);

        $caculate = array(0, 0, 0, 0, 0, 0, 0, 0);

        $midB = substr($zhujiid, 2, 2);
        echo $midB;
        $numB = $midB * 1;
        $b = $numB % 16;
        /*
                $wZID = $zhujiid * 1;

                $rand = 0;
                if ($wZID <= 20){
                    $rand = rand(0, 8);

                }else{
                    $rand = rand(0, 9);
                }
                $rand = 7;
                //  $rand = 4;
                echo '<br>';
                echo $rand;
                echo '<br>';
                //rand(0, 9);
                */
        $caculate[3] = $rand;
        $c = $caculate[3] + $b * 20;

        $DATA1 = $DATA1 * 1;

        $DATA3 = $DATA1 * $myrand[$c] + $myrand[$c+10];

        $DATA3 = $this->insertToStr("$DATA3",3,"$rand");

        echo $DATA3;
        $TT = '123456';
        echo '<br>';
        echo '******';
        echo  substr($TT,4,2);

        echo '<br>';
        echo '=============';
//        $w = 100;
//        if ($w > 99){
//
//            $w = 1;
//        }
//        echo $w;
        echo '%';
        echo $DATA3;
        echo '%';

        $t1 = substr($DATA3,0,1);
        $t2 = substr($DATA3,1,1);
        $t3 = substr($DATA3,2,1);
        $t4 = substr($DATA3,3,1);
        $t5 = substr($DATA3,4,1);
        $t6 = substr($DATA3,5,1);
        $t7 = substr($DATA3,6,1);
        $t8 = substr($DATA3,7,1);
//      echo '<br>';
//      echo 'one'.$t1.$t2.$t3.$t4.$t5.$t6.$t7.$t8.'@';

        $wwMid = $t1*1 + $t2*1 + $t3*1+ $t4*1+ $t5*1+ $t6*1+ $t7*1+ $t8*1;
        $ttMid = $wwMid%10;

        echo '<br>';
        echo $ttMid;

        // 获取到验证码
        $DATA5 = $this->insertToStr($DATA3,4,"$ttMid");





        return  $DATA5;
    }

    public  function insertToStr($str, $i, $substr){
        //指定插入位置前的字符串
        $startstr="";
        for($j=0; $j<$i; $j++){
            $startstr .= $str[$j];
        }
        //指定插入位置后的字符串
        $laststr="";
        for ($j=$i; $j<strlen($str); $j++){
            $laststr .= $str[$j];
        }
        //将插入位置前，要插入的，插入位置后三个字符串拼接起来
        $str = $startstr . $substr . $laststr;
        //返回结果
        return $str;
    }


}



//----------------------------------------------
/*



 */
