<?php

libxml_disable_entity_loader(true);


ini_set('date.timezone','Asia/Shanghai');
error_reporting(E_ERROR);

// Bmob
//require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";

require_once "./paylib/WxPay.Api.php";
require_once './paylib/WxPay.Notify.php';
require_once "../localPHP/jssdk.php";

//require_once 'log.php';

//初始化日志
//$logHandler= new CLogFileHandler("../logs/".date('Y-m-d').'.log');
//$log = Log::Init($logHandler, 15);

class PayNotifyCallBack extends WxPayNotify
{
    //查询订单
    public function Queryorder($transaction_id)
    {
        $input = new WxPayOrderQuery();
        $input->SetTransaction_id($transaction_id);
        $result = WxPayApi::orderQuery($input);
        //	Log::DEBUG("query:" . json_encode($result));
        if(array_key_exists("return_code", $result)
            && array_key_exists("result_code", $result)
            && $result["return_code"] == "SUCCESS"
            && $result["result_code"] == "SUCCESS")
        {
            return true;
        }
        return false;
    }

    //重写回调处理函数
    public function NotifyProcess($data, &$msg)
    {
        //	Log::DEBUG("call back:" . json_encode($data));
        $notfiyOutput = array();

        if(!array_key_exists("transaction_id", $data)){
            $msg = "输入参数不正确";
            return false;
        }
        //查询订单，判断订单真实性
        if(!$this->Queryorder($data["transaction_id"])){
            $msg = "订单查询失败";
            return false;
        }
        return true;
    }
}

// =========  读写 函数 ============
function get_php_file($filename) {
    return trim(substr(file_get_contents($filename), 15));
}
function set_php_file($filename, $content) {
    $fp = fopen($filename, "w");
    fwrite($fp, "<?php exit();?>" . $content);
//    echo 'Content==='.$content;
    fclose($fp);
}


// Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle(false);
$resParam = $notify->GetValues();

//echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
if ($resParam['return_code'] === 'SUCCESS' && $resParam['return_msg'] === 'OK'){

// echo 'SUCCESS';
//echo 'SUCCESS';
    libxml_disable_entity_loader(true);
    echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";

    $raw_xml = file_get_contents("php://input");
    libxml_disable_entity_loader(true);
    // $res = json_decode(json_encode(simplexml_load_string($raw_xml,'simpleXMLElement',LIBXML_NOCDATA)));
    $resObj = simplexml_load_string($raw_xml);
// 商户订单号
    $orderid = $resObj->out_trade_no;


//读出缓存
//    $orderR = json_decode(get_php_file('orders.php'));
//    $isSuccess = in_array("$orderid",$orderR);
//    if ($isSuccess){
//        // 已存在订单号
//        echo 'SUCCESS';
//
//    }else{
//        // 不存在订单号
//        $orderCount = array_unshift($orderR,"$orderid");
//        if ($orderCount>10){
//            array_pop($orderR);
//        }
//        //缓存
//        set_php_file('orders.php',json_encode($orderR));

// 处理业务逻辑

        require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";
        // 1.取bmob数据
        $bmobObj = new BmobObject("WX_user");
        //  $timestamp = time()+7000;
        //  $objID = 'a0c44d19d4';
        //  $openid = $resObj-> openid;

        $currentOpenID = $resObj->openid;
        $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
        $res=$bmobObj->get("",array("$queryStr"));
        $res1 = $res->results;
        $currentObj =  $res1[0];
// 学员的实际缴费 39 、65
        $fee = $resObj->total_fee;
        $fee1 = $fee/100;


// Attach   龙创交规 / 共享考车
        $attach =  $resObj->attach;


        if (strpos($attach, '共享考车') !== false){

            $gxArr   =explode("-",$attach);
            //    $gxAttach     = $gxArr[0];
            $gxMID        =   $gxArr[1];
            $classCount = $gxArr[2];
// 验证码次数
            //     $yzmTime  = $gxArr[3];
            // ProxyOBDMaster      ProxyPayrecord
            $gxBmobObj = new BmobObject("ProxyPayrecord");


// 验证
            $queryStrX = "where={\"orderID\":\"{$orderid}\"}";
            $resQueryX = $gxBmobObj->get("",array("$queryStrX"));
            $res1X = $resQueryX->results;
            if (count($res1X)>0){
                echo 'SUCCESS';
//libxml_disable_entity_loader(true);
                echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
            }else{
                echo 'SUCCESS';
//libxml_disable_entity_loader(true);
                echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
// ====== - 1 - =========
// 查询 验证码次数 并 + 1
                $masterBmobObj =  new BmobObject("ProxyOBDMaster");
                $queryMaster = "where={\"MasterID\":\"{$gxMID}\"}";
                $masterRes = $masterBmobObj->get("",array("$queryMaster"));
                $mRes1 = $masterRes->results;
                $masterObj =  $mRes1[0];
                $masterObjId =  $masterObj->objectId;
// 验证码次数
                $yzmNum =  $masterObj->yzm_num;
                $newNum = $yzmNum +1;
                if ($newNum > 99){
                    $newNum = 1;
                }
// 主机总课时
                $classC = $masterObj->classCount;
// 当前教练课时
                $coachClassC = $masterObj->coachClassCount;

                $newCoachCount = $classCount + $coachClassC*1;
                $newCount = $classCount +$classC;
                //$masterUpdatae  = $masterBmobObj->update("yzm_num"=>$newNum,));

//===*********==
                require 'newYZM.php';
//=================
//$yzmUtil = new YZMUtil();
//$yzm =$yzmUtil->getzcmAction("10000100010001");
//$newc = 5;


                $cishu = str_pad($newNum,2,"0",STR_PAD_LEFT);
                $shulian = str_pad($classCount,2,"0",STR_PAD_LEFT);
                $subMID = substr($gxMID,4,2);

                $DATA1 = $cishu.$shulian.$subMID;

                $yzmUtil = new YZMUtil();
                $yzm =$yzmUtil-> wwGetYzmAction( $DATA1,$gxMID);

//  wwGetYzmAction    getzcmAction
// accesstoken

// 填写充值记录
                $gxRes = $gxBmobObj->create(array("studentID"=>"$currentOpenID","class_count"=>"$classCount","MasterID"=>"$gxMID","orderID"=>"$orderid","yzm"=>"$yzm","yzm_num"=>$newNum,"chongzhi_money"=>"$fee1"));



                $jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");
//echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
// get accessToken
                $accessToken = $jssdk->getAccessToken();
                $yzmStr = "【龙创科技】".$gxMID."号共享考车的验证码是：".$yzm."。 ";
                $yzmUtil ->getNewTicket($currentOpenID,$accessToken,$yzmStr);

//===********===
//"orderID"=>"$orderid",
                $masterUpdatae  = $masterBmobObj->update($masterObjId,array("yzm_num"=>$newNum,"coachClassCount"=>"$newCoachCount","classCount"=>$newCount ,));
//======= 6 ========
// == 共享考车的总课时 和 总收益

                $GX_res = $masterBmobObj->get("Ktq95556");

// 总课时 proxy_name
// 总收益  coach_id
//var_dump($res);
                $GX_time = $GX_res->proxy_name;

                $GX_money = $GX_res->coach_id;

                $GX_newtime = $GX_time*1 + $classCount*1;
                $GX_newmoney = $GX_money*1+ $classCount*4;

                $GX_UPRes = $masterBmobObj->update("Ktq95556",array("proxy_name"=>"$GX_newtime","coach_id"=>"$GX_newmoney"));
// ====== 2 ======
// 主机的累计课时数量




// ====== - 3 - =========
// 查询本主机对应的 教练 和 代理 分别提成
                $coachID = $masterObj->coach_id;
                $proxyID = $masterObj->proxy_id;

// 从微信user中查询
                $coachQuery = "where={\"openID\":\"{$coachID}\"}";
                $coachRes=$bmobObj->get("",array("$coachQuery"));
                $coachRes1 = $coachRes->results;
                $coachObj =  $coachRes1[0];
                $coachObjId =  $coachObj->objectId;
// 原来的金额
                $coachTotal =  $coachObj->gxTotalMoney;
                //  $fee2 = "30";
                $wwHours = 7.5*$classCount;
                $coachFee = $fee1-$wwHours;
                $newTotal = $coachTotal +  $coachFee;
                $coachUpdate  = $bmobObj->update($coachObjId,array("gxTotalMoney"=>$newTotal,));


// 代理提  7 元

                $proxyQuery =  "where={\"openID\":\"{$proxyID}\"}";
                $proxyRes=$bmobObj->get("",array("$proxyQuery"));
                $proxyRes1 = $proxyRes->results;
                $proxyObj =  $proxyRes1[0];
                $proxyObjId =  $proxyObj->objectId;
// 原来的金额
                $proxyTotal =  $proxyObj->gxTotalMoney;
                $wwSevenHours = 3.5*$classCount;
                $newProxy = $proxyTotal + $wwSevenHours;
                $proxyUpdate  = $bmobObj->update($proxyObjId,array("gxTotalMoney"=>$newProxy,));


// ====== - 4 - =========
// 发送验证码消息
                /*
                 $cishu = str_pad($newNum,4,"0",STR_PAD_LEFT);
                $shulian = str_pad($classCount,4,"0",STR_PAD_LEFT);
                 $DATA1 = $gxMID.$cishu.$shulian;
                 $masterUpdatae110  = $masterBmobObj->update($masterObjId,array("proxy_tel"=>"$DATA1"));
                */

//require 'gxyzm.php';
                /*
                require 'newYZM.php';
                //=================
                //$yzmUtil = new YZMUtil();
                //$yzm =$yzmUtil->getzcmAction("10000100010001");
                //$newc = 5;


                $cishu = str_pad($newNum,2,"0",STR_PAD_LEFT);
                $shulian = str_pad($classCount,2,"0",STR_PAD_LEFT);
                 $subMID = substr($gxMID,4,2);

                $DATA1 = $cishu.$shulian.$subMID;

                $yzmUtil = new YZMUtil();
                $yzm =$yzmUtil-> wwGetYzmAction( $DATA1,$gxMID);


                //  wwGetYzmAction    getzcmAction
                // accesstoken

                $jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

                // get accessToken
                $accessToken = $jssdk->getAccessToken();
                $yzmStr = "【龙创科技】".$gxMID."号共享考车的验证码是：".$yzm."。 ";
                $yzmUtil ->getNewTicket($currentOpenID,$accessToken,$yzmStr);
                */
// ====== - 2 - =========
// 填写充值记录
                //  $gxRes = $gxBmobObj->create(array("studentID"=>"$currentOpenID","class_count"=>"$classCount","MasterID"=>"$gxMID","orderID"=>"$orderid","yzm"=>"$yzm","yzm_num"=>$newNum,"chongzhi_money"=>"$fee1"));

                /*
                $yzmUtil = new YZMUtil();
                $yzm =$yzmUtil->getzcmAction( $DATA1);
                // accesstoken

                $jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

                // get accessToken
                $accessToken = $jssdk->getAccessToken();
                $yzm = "$gxMID"."号共享考车第".$cishu."次充值验证码未:".$yzm."。请按照充值次数使用验证码！ ";
                $yzmUtil ->getNewTicket($currentOpenID,$accessToken,$yzm);
                */
            }// 第一次支付结果通知

        }// 共享考车的支付结果回调



        if($attach == "龙创交规"){

            // objectId
            $cObjID = $currentObj->objectId;

// 过期时间戳
            $endT = 0;
// 三级提成
            $oneFee =9;
            $twoFee = 99;
            $threeFee = 999;
            if ($fee1 == 39){
                $endT = strtotime(date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d")))));
                $oneFee = 15;
                $twoFee = 8;
                $threeFee = 5;
            }else{
                $endT = strtotime(date("Y/m/d",strtotime("+60 days",strtotime(date("Y/m/d")))));
                $oneFee = 24;
                $twoFee = 12;
                $threeFee = 8;
            }

            //$res=$bmobObj->get("",array('where={"orderID":"$orderid"}'));

            $queryStr = "where={\"orderID\":\"{$orderid}\"}";
            $resQuery = $bmobObj->get("",array("$queryStr"));
            $res1Q = $resQuery->results;
            if (count($res1Q)>0){
                // 本次回调的订单号已经填写到Bmob 不做操作
                //   echo 'SUCCESS';
                echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";

            }else{

                $resUpdatae  = $bmobObj->update($cObjID,array("lc_state"=>"1","orderID"=>"$orderid","endTime"=>$endT,));

// 给"我"的上级提成
                $p1  = $currentObj->p1;
                $queryp1 = "where={\"openID\":\"{$p1}\"}";
                $resp1 = $bmobObj->get("",array($queryp1));
                $resp11 = $resp1->results;
                $objp1  = $resp11[0];
                $objidp1 = $objp1->objectId;
                $moneyp1 = $objp1->money;
                $newmoneyp1 = $moneyp1+$oneFee;
                $updatep1 = $bmobObj->update($objidp1,array("money"=>"$newmoneyp1"));

// 将提成记录添加到 提成记录表中
                $bmobObjR = new BmobObject("WX_percentageRecord");
                if(strlen($p1)>10){

                    $resR = $bmobObjR->create(array("stuOpenID"=>"$currentOpenID","coachOpenID"=>"$p1","levelRelationship"=>"一级学员","topUpMoney"=>"$fee1","orderID"=>"$orderid","percentMoney"=>$oneFee,));


                }

                $p2  = $currentObj->p2;
                $queryp2 = "where={\"openID\":\"{$p2}\"}";
                $resp2 = $bmobObj->get("",array($queryp2));
                $resp22 = $resp2->results;
                $objp2  = $resp22[0];
                $objidp2 = $objp2->objectId;
                $moneyp2 = $objp2->money;
                $newmoneyp2 = $moneyp2+$twoFee;
                $updatep2 = $bmobObj->update($objidp2,array("money"=>"$newmoneyp2"));

                if(strlen($p2)>10){

                    //       $bmobObj = new BmobObject("WX_percentageRecord");
                    $resR2 = $bmobObjR->create(array("stuOpenID"=>"$currentOpenID","coachOpenID"=>"$p2","levelRelationship"=>"二级学员","topUpMoney"=>"$fee1","orderID"=>"$orderid","percentMoney"=>$twoFee,));


                }

                $p3  = $currentObj->p3;
                $queryp3 = "where={\"openID\":\"{$p3}\"}";
                $resp3 = $bmobObj->get("",array($queryp3));
                $resp33 = $resp3->results;
                $objp3  = $resp33[0];
                $objidp3 = $objp3->objectId;
                $moneyp3 = $objp3->money;
                $newmoneyp3 = $moneyp3+$threeFee;
                $updatep3 = $bmobObj->update($objidp3,array("money"=>"$newmoneyp3"));


                if(strlen($p3)>10){

                    //   $bmobObj = new BmobObject("WX_percentageRecord");
                    $resR3 = $bmobObjR->create(array("stuOpenID"=>"$currentOpenID","coachOpenID"=>"$p3","levelRelationship"=>"三级学员","topUpMoney"=>"$fee1","orderID"=>"$orderid","percentMoney"=>$threeFee,));

                }

            } // bmob记录中未查询到本次回调的订单号


// 开通龙创交规 支付回调
        }else{

            //  $gxArr   =explode("-",$attach);
//   $gxAttach     = $gxArr[0];
            //  $gxMID =   $gxArr[1];
            //   $gxBmobObj = new BmobObject("ProxyPayrecord"):

//   $gxRes = $gxBmobObj->create(array("studentID"=>"$currentOpenID","class_count"=>"10","MasterID"=>"gxMID","orderID"=>"$orderid","chongzhiMoney"=>20,));
        }




   // }







} // 支付成功 success OK

/*
//=================
//$yzmUtil = new YZMUtil();
//$yzm =$yzmUtil->getzcmAction("10000100010001");

class YZMUtil {

    public function __construct() {

    }
//=========================================== 生成验证码 =========================================
    public function getzcmAction($DATA1) {

        $myrand= array(
            '0x96','0xD5','0xAC','0xC6','0x92','0xDB','0xF6','0x78','0xC0','0xE1','0x6D','0x52','0x9B','0x80','0xCB','0x24',
            '0x3C','0xA7','0x7C','0x4C','0x52','0x3C','0xFB','0x5D','0xA9','0x66','0xC1','0x0B','0xEF','0xD4','0x5F','0xDA',
            '0xDF','0xD3','0x57','0x89','0x45','0xF9','0x83','0x2C','0xD9','0x19','0x44','0x97','0x62','0xBD','0xE9','0x54',
            '0x9F','0xCC','0xA3','0x81','0x9D','0x39','0xFB','0x77','0xC8','0x2A','0x71','0xD7','0x91','0x15','0xC8','0xAA',
            '0x23','0x53','0xA0','0x85','0x0B','0x64','0xF5','0x20','0x76','0x9F','0x79','0xCF','0xC9','0xD6','0x52','0x73',
            '0xC3','0x62','0xA3','0x7C','0xD7','0xFB','0xC7','0x24','0x49','0xC6','0xE6','0x79','0x89','0x26','0xBC','0xF5',
            '0x1D','0x88','0xBF','0x9C','0x21','0xB9','0xB9','0xED','0xE3','0x68','0xE2','0x30','0xBF','0x95','0x56','0x23',
            '0x43','0xC5','0x2A','0xDE','0xBA','0x29','0xE2','0x67','0x9D','0xB3','0xE2','0x33','0x93','0xC9','0xA2','0x3D',
            '0x71','0x18','0x65','0x43','0xF1','0xAF','0x45','0xE7','0x5E','0x22','0x24','0x5E','0x53','0xED','0x34','0x9A',
            '0x75','0x49','0x56','0x63','0x69','0xA5','0xBD','0x43','0xDE','0xAA','0xD2','0xD7','0x5D','0x4B','0x82','0xBE',
            '0x91','0xDB','0xAD','0x9D','0xE8','0xDC','0xA3','0x33','0x8C','0x4F','0x76','0x9C','0xF5','0x23','0xF9','0x16',
            '0xD1','0xB2','0x1F','0xAF','0xEC','0x40','0xD9','0x4A','0x35','0x80','0x6B','0x57','0xF0','0x46','0xBE','0x13',
            '0xF0','0xEA','0x8C','0xAE','0x0F','0x9C','0x5A','0x8E','0xF6','0x94','0x78','0x32','0xE5','0x0B','0xEE','0xCD',
            '0xDE','0x42','0x60','0x0D','0xD2','0xD4','0x26','0x7F','0xF3','0x23','0xCF','0x47','0x66','0xDF','0x65','0x45',
            '0xA1','0x99','0xDF','0x71','0x0B','0xAF','0x75','0xB9','0x7C','0xAB','0x38','0x99','0x3D','0x4A','0x9F','0x8F',
            '0x2F','0x6B','0x86','0x2C','0xFF','0x97','0xD0','0x11','0xAF','0x4A','0x3E','0xCF','0x21','0x80','0x13','0x2A');

        $rand = rand(0,35);

        $caculate = array(0,0,0,0,0,0,0,0,0,0,0,0);
// rand  $rand
$caculate[11] = 10;
$DATA1 = $DATA1 *1;
//    DATA1 = 0;
$DATA1 = $DATA1 + 10000000000000;
//   DATA1 = "20000100040002";
$cs1 = $myrand[$caculate[11]];
$deHex = hexdec($cs1);
$DATA3 = $DATA1 * $deHex;

$caculate[0] =  floor(($DATA3/pow(36, 10)));
$caculate[1] =  floor(($DATA3%pow(36, 10)/pow(36, 9)));
$caculate[2] =  floor(($DATA3%pow(36, 9)/pow(36, 8)));
$caculate[3] =  floor(($DATA3%pow(36, 8)/pow(36, 7)));
$caculate[4] =  floor(($DATA3%pow(36, 7)/pow(36, 6)));
$caculate[5] =  floor(($DATA3%pow(36, 6)/pow(36, 5)));
$caculate[6] =  floor(($DATA3%pow(36, 5)/pow(36, 4)));
$caculate[7] =  floor(($DATA3%pow(36, 4)/pow(36, 3)));
$caculate[8] =  floor(($DATA3%pow(36, 3)/pow(36, 2)));
$caculate[9] =  floor(($DATA3%pow(36, 2)/pow(36, 1)));
$caculate[10] = floor(($DATA3%pow(36, 1)/pow(36, 0)));

$zf = ["0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"];
//alert(caculate);
$return_data ="";
for($j = 0;$j < count($caculate);$j++)
{

    $return_data .= $zf[$caculate[$j]];
}
return 	$return_data;

}

// =======================发送客服消息 ==================
public function getNewTicket($wwOpenid,$accessTokenR,$contentStr){

      //  echo $wwOpenid;
        echo $accessTokenR;

      //  $jsonData2 = '{"kf_account": "GXKF@LongChuangDriveExam", "nickname": "共享考车客服", "password":"gongxiangkf"}';
        $jsonData2 = '{"touser":'."\"".$wwOpenid."\"".', "msgtype": "text", "text":{"content":'."\"".$contentStr."\"".'}}';

        //echo '********';
echo $jsonData2;
//echo '********';
//$jj = json_encode($jsonData2);
//$jsonData = "{'expire_seconds': 604800, 'action_name': 'QR_STR_SCENE', 'action_info': {'scene': {'scene_str': {$openidWW}}}}";
       // $qrURL = "https://api.weixin.qq.com/customservice/kfaccount/add?access_token=$accessTokenR";
        $qrURL = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=$accessTokenR";

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "$qrURL");
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// 跟踪重定向属性
        curl_setopt($ch,CURLOPT_HTTPHEADER,array('Expect:'));

        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData2 );
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
        }

        curl_close($ch);

//echo $tmpInfo;
    }

}
*/