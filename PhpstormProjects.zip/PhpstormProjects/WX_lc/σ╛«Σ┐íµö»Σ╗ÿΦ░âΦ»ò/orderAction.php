<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/9/14
 * Time: 13:59
 */

//$orders = array();
// array_push($orders,"zhao");
// array_push($orders,"qian");
// array_push($orders ,"sun");
// array_push($orders,"li");
// array_push($orders,"zhou");
// array_push($orders,"wu");
// array_push($orders,"zheng");
// array_push($orders,"wang");

//  149777333220180914152237

//缓存
//if(false!==fopen('orders.txt','w+')){
//    file_put_contents('orders.txt',serialize($orders));//写入缓存
//}
////读出缓存
//$handle=fopen('orders.txt','r');
//$cacheArray=unserialize(fread($handle,filesize('orders.txt')));
//
//
//
//echo count($cacheArray);
//var_dump($cacheArray);
////array_pop($cacheArray);
//
//var_dump($cacheArray);
//
//$isWang = in_array("wang",$cacheArray);
//
//
//
////echo $orders;
//if ($isWang){
//    echo "youWang!";
//}else{
//    echo "youwang!!!!!";
//
//}
$orderid = "14977733322018091415223c";
$orderR = json_decode(get_php_file('ccnm.php'));

$isSuccess = in_array($orderid,$orderR);
if ($isSuccess){

    echo 'success!';

}else{

    echo 'fail';
    // 不存在订单号
    $orderCount = array_unshift($orderR,$orderid);
    if ($orderCount>10){
        array_pop($orderR);
    }
    set_php_file('ccnm.php',json_encode($orderR));
}



function get_php_file($filename) {
    return trim(substr(file_get_contents($filename), 15));
}
function set_php_file($filename, $content) {
    $fp = fopen($filename, "w");
    fwrite($fp, "<?php exit();?>" . $content);
//    echo 'Content==='.$content;
    fclose($fp);
}

// file_put_contents('orders.txt',$orders);
//
// $aOrders = file_get_contents('orders.txt');
// echo $aOrders;
////array_pop($aOrders);
////$isWang = in_array("wang",$aOrders);
//
//
//
////echo $orders;
//if ($isWang){
//    echo "youWang!";
//}else{
//    echo "youwang!!!!!";
//
//}