<?php

libxml_disable_entity_loader(true);


ini_set('date.timezone','Asia/Shanghai');
error_reporting(E_ERROR);

// Bmob
//require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";

require_once "./paylib/WxPay.Api.php";
require_once './paylib/WxPay.Notify.php';
require_once "../localPHP/jssdk.php";

//require_once 'log.php';

//初始化日志
//$logHandler= new CLogFileHandler("../logs/".date('Y-m-d').'.log');
//$log = Log::Init($logHandler, 15);

class PayNotifyCallBack extends WxPayNotify
{
    //查询订单
    public function Queryorder($transaction_id)
    {
        $input = new WxPayOrderQuery();
        $input->SetTransaction_id($transaction_id);
        $result = WxPayApi::orderQuery($input);
        //	Log::DEBUG("query:" . json_encode($result));
        if(array_key_exists("return_code", $result)
            && array_key_exists("result_code", $result)
            && $result["return_code"] == "SUCCESS"
            && $result["result_code"] == "SUCCESS")
        {
            return true;
        }
        return false;
    }

    //重写回调处理函数
    public function NotifyProcess($data, &$msg)
    {
        //	Log::DEBUG("call back:" . json_encode($data));
        $notfiyOutput = array();

        if(!array_key_exists("transaction_id", $data)){
            $msg = "输入参数不正确";
            return false;
        }
        //查询订单，判断订单真实性
        if(!$this->Queryorder($data["transaction_id"])){
            $msg = "订单查询失败";
            return false;
        }
        return true;
    }
}



// Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle(false);
$resParam = $notify->GetValues();

if ($resParam['return_code'] === 'SUCCESS' && $resParam['return_msg'] === 'OK'){

// echo 'SUCCESS';
    libxml_disable_entity_loader(true);
    echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";

    $raw_xml = file_get_contents("php://input");
    libxml_disable_entity_loader(true);
    // $res = json_decode(json_encode(simplexml_load_string($raw_xml,'simpleXMLElement',LIBXML_NOCDATA)));
    $resObj = simplexml_load_string($raw_xml);



    $orderid = $resObj->out_trade_no;

    //$orders = array();
//    array_push($orders,"zhao");
//    array_push($orders,"qian");
//    array_push($orders ,"sun");
//    array_push($orders,"li");
//    array_push($orders,"zhou");
//    array_push($orders,"wu");
//    array_push($orders,"zheng");
//    array_push($orders,"wang");



//缓存
//    if(false!==fopen('orders.txt','w+')){
//        file_put_contents('orders.txt',serialize($orders));//写入缓存
//    }
//读出缓存
    $handle=fopen('orders.txt','r');
    $cacheArray=unserialize(fread($handle,filesize('orders.txt')));


    if (in_array($orderid,$cacheArray)){
        // 已存在订单号


    }else{
        // 不存在订单号
        $orderCount = array_push($cacheArray,$orderid);
        if ($orderCount>10){
            array_pop($cacheArray);
        }
        //缓存
    if(false!==fopen('orders.txt','w+')){
        file_put_contents('orders.txt',serialize($orders));//写入缓存
    }



    }

    echo count($cacheArray);
    var_dump($cacheArray);
//array_pop($cacheArray);

    var_dump($cacheArray);

    $isWang = in_array("wang",$cacheArray);



//echo $orders;
    if ($isWang){
        echo "youWang!";
    }else{
        echo "youwang!!!!!";

    }




    require "../wxResource/bmobPhpSdk/lib/BmobObject.class.php";
    // 1.取bmob数据
    $bmobObj = new BmobObject("WX_user");
    //  $timestamp = time()+7000;
    //  $objID = 'a0c44d19d4';
    //  $openid = $resObj-> openid;

    $currentOpenID = $resObj->openid;
    $queryStr = "where={\"openID\":\"{$currentOpenID}\"}";
    $res=$bmobObj->get("",array("$queryStr"));
    $res1 = $res->results;
    $currentObj =  $res1[0];
// 学员的实际缴费 39 、65
    $fee = $resObj->total_fee;
    $fee1 = $fee/100;
// 商户订单号


// Attach   龙创交规 / 共享考车
    $attach =  $resObj->attach;


    if (strpos($attach, '共享考车') !== false){

        $gxArr   =explode("-",$attach);
        //    $gxAttach     = $gxArr[0];
        $gxMID        =   $gxArr[1];
        $classCount = $gxArr[2];
// 验证码次数
        //     $yzmTime  = $gxArr[3];

        $gxBmobObj = new BmobObject("ProxyPayrecord");

// 验证
        $queryStrX = "where={\"orderID\":\"{$orderid}\"}";
        $resQueryX = $gxBmobObj->get("",array("$queryStrX"));
        $res1X = $resQueryX->results;
        if (count($res1X)>0){
//echo 'SUCCESS';
            echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
        }else{

// ====== - 1 - =========
// 查询 验证码次数 并 + 1
            $masterBmobObj =  new BmobObject("ProxyOBDMaster");
            $queryMaster = "where={\"MasterID\":\"{$gxMID}\"}";
            $masterRes = $masterBmobObj->get("",array("$queryMaster"));
            $mRes1 = $masterRes->results;
            $masterObj =  $mRes1[0];
            $masterObjId =  $masterObj->objectId;
// 验证码次数
            $yzmNum =  $masterObj->yzm_num;
            $newNum = $yzmNum +1;
            if ($newNum > 99){
                $newNum = 1;
            }
// 主机总课时
            $classC = $masterObj->classCount;
// 当前教练课时
            $coachClassC = $masterObj->coachClassCount;

            $newCoachCount = $classCount + $coachClassC*1;
            $newCount = $classCount +$classC;
            //$masterUpdatae  = $masterBmobObj->update("yzm_num"=>$newNum,));

//===*********==
            require 'newYZM.php';
//=================
//$yzmUtil = new YZMUtil();
//$yzm =$yzmUtil->getzcmAction("10000100010001");
//$newc = 5;


            $cishu = str_pad($newNum,2,"0",STR_PAD_LEFT);
            $shulian = str_pad($classCount,2,"0",STR_PAD_LEFT);
            $subMID = substr($gxMID,4,2);

            $DATA1 = $cishu.$shulian.$subMID;

            $yzmUtil = new YZMUtil();
            $yzm =$yzmUtil-> wwGetYzmAction( $DATA1,$gxMID);

//  wwGetYzmAction    getzcmAction
// accesstoken
            // 填写充值记录
            $gxRes = $gxBmobObj->create(array("studentID"=>"$currentOpenID","class_count"=>"$classCount","MasterID"=>"$gxMID","orderID"=>"$orderid","yzm"=>"$yzm","yzm_num"=>$newNum,"chongzhi_money"=>"$fee1"));



            $jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

// get accessToken
            $accessToken = $jssdk->getAccessToken();
            $yzmStr = "【龙创科技】".$gxMID."号共享考车的验证码是：".$yzm."。 ";
            $yzmUtil ->getNewTicket($currentOpenID,$accessToken,$yzmStr);

//===********===



            $masterUpdatae  = $masterBmobObj->update($masterObjId,array("yzm_num"=>$newNum,"coachClassCount"=>"$newCoachCount","orderID"=>"$orderid","classCount"=>$newCount ,));
//======= 6 ========
// == 共享考车的总课时 和 总收益

            $GX_res = $masterBmobObj->get("Ktq95556");

// 总课时 proxy_name
// 总收益  coach_id
//var_dump($res);
            $GX_time = $GX_res->proxy_name;

            $GX_money = $GX_res->coach_id;

            $GX_newtime = $GX_time*1 + $classCount*1;
            $GX_newmoney = $GX_money*1+ $classCount*4;

            $GX_UPRes = $masterBmobObj->update("Ktq95556",array("proxy_name"=>"$GX_newtime","coach_id"=>"$GX_newmoney"));
// ====== 2 ======
// 主机的累计课时数量




// ====== - 3 - =========
// 查询本主机对应的 教练 和 代理 分别提成
            $coachID = $masterObj->coach_id;
            $proxyID = $masterObj->proxy_id;

// 从微信user中查询
            $coachQuery = "where={\"openID\":\"{$coachID}\"}";
            $coachRes=$bmobObj->get("",array("$coachQuery"));
            $coachRes1 = $coachRes->results;
            $coachObj =  $coachRes1[0];
            $coachObjId =  $coachObj->objectId;
// 原来的金额
            $coachTotal =  $coachObj->gxTotalMoney;
            //  $fee2 = "30";
            $wwHours = 7.5*$classCount;
            $coachFee = $fee1-$wwHours;
            $newTotal = $coachTotal +  $coachFee;
            $coachUpdate  = $bmobObj->update($coachObjId,array("gxTotalMoney"=>$newTotal,));


// 代理提  7 元

            $proxyQuery =  "where={\"openID\":\"{$proxyID}\"}";
            $proxyRes=$bmobObj->get("",array("$proxyQuery"));
            $proxyRes1 = $proxyRes->results;
            $proxyObj =  $proxyRes1[0];
            $proxyObjId =  $proxyObj->objectId;
// 原来的金额
            $proxyTotal =  $proxyObj->gxTotalMoney;
            $wwSevenHours = 3.5*$classCount;
            $newProxy = $proxyTotal + $wwSevenHours;
            $proxyUpdate  = $bmobObj->update($proxyObjId,array("gxTotalMoney"=>$newProxy,));


// ====== - 4 - =========
// 发送验证码消息
            /*
             $cishu = str_pad($newNum,4,"0",STR_PAD_LEFT);
            $shulian = str_pad($classCount,4,"0",STR_PAD_LEFT);
             $DATA1 = $gxMID.$cishu.$shulian;
             $masterUpdatae110  = $masterBmobObj->update($masterObjId,array("proxy_tel"=>"$DATA1"));
            */

//require 'gxyzm.php';
            /*
            require 'newYZM.php';
            //=================
            //$yzmUtil = new YZMUtil();
            //$yzm =$yzmUtil->getzcmAction("10000100010001");
            //$newc = 5;


            $cishu = str_pad($newNum,2,"0",STR_PAD_LEFT);
            $shulian = str_pad($classCount,2,"0",STR_PAD_LEFT);
             $subMID = substr($gxMID,4,2);

            $DATA1 = $cishu.$shulian.$subMID;

            $yzmUtil = new YZMUtil();
            $yzm =$yzmUtil-> wwGetYzmAction( $DATA1,$gxMID);


            //  wwGetYzmAction    getzcmAction
            // accesstoken

            $jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

            // get accessToken
            $accessToken = $jssdk->getAccessToken();
            $yzmStr = "【龙创科技】".$gxMID."号共享考车的验证码是：".$yzm."。 ";
            $yzmUtil ->getNewTicket($currentOpenID,$accessToken,$yzmStr);
            */
// ====== - 2 - =========
// 填写充值记录
            $gxRes = $gxBmobObj->create(array("studentID"=>"$currentOpenID","class_count"=>"$classCount","MasterID"=>"$gxMID","orderID"=>"$orderid","yzm"=>"$yzm","yzm_num"=>$newNum,"chongzhi_money"=>"$fee1"));

            /*
            $yzmUtil = new YZMUtil();
            $yzm =$yzmUtil->getzcmAction( $DATA1);
            // accesstoken

            $jssdk = new JSSDK("wx62732b3c3460b3b1", "cc05112ee2e8f53d80970d0d988398cd");

            // get accessToken
            $accessToken = $jssdk->getAccessToken();
            $yzm = "$gxMID"."号共享考车第".$cishu."次充值验证码未:".$yzm."。请按照充值次数使用验证码！ ";
            $yzmUtil ->getNewTicket($currentOpenID,$accessToken,$yzm);
            */
        }// 第一次支付结果通知

    }// 共享考车的支付结果回调



    if($attach == "龙创交规"){

        // objectId
        $cObjID = $currentObj->objectId;

// 过期时间戳
        $endT = 0;
// 三级提成
        $oneFee =9;
        $twoFee = 99;
        $threeFee = 999;
        if ($fee1 == 39){
            $endT = strtotime(date("Y/m/d",strtotime("+30 days",strtotime(date("Y/m/d")))));
            $oneFee = 15;
            $twoFee = 8;
            $threeFee = 5;
        }else{
            $endT = strtotime(date("Y/m/d",strtotime("+60 days",strtotime(date("Y/m/d")))));
            $oneFee = 24;
            $twoFee = 12;
            $threeFee = 8;
        }

        //$res=$bmobObj->get("",array('where={"orderID":"$orderid"}'));

        $queryStr = "where={\"orderID\":\"{$orderid}\"}";
        $resQuery = $bmobObj->get("",array("$queryStr"));
        $res1Q = $resQuery->results;
        if (count($res1Q)>0){
            // 本次回调的订单号已经填写到Bmob 不做操作
            //   echo 'SUCCESS';
            echo "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";

        }else{

            $resUpdatae  = $bmobObj->update($cObjID,array("lc_state"=>"1","orderID"=>"$orderid","endTime"=>$endT,));

// 给"我"的上级提成
            $p1  = $currentObj->p1;
            $queryp1 = "where={\"openID\":\"{$p1}\"}";
            $resp1 = $bmobObj->get("",array($queryp1));
            $resp11 = $resp1->results;
            $objp1  = $resp11[0];
            $objidp1 = $objp1->objectId;
            $moneyp1 = $objp1->money;
            $newmoneyp1 = $moneyp1+$oneFee;
            $updatep1 = $bmobObj->update($objidp1,array("money"=>"$newmoneyp1"));

// 将提成记录添加到 提成记录表中
            $bmobObjR = new BmobObject("WX_percentageRecord");
            if(strlen($p1)>10){

                $resR = $bmobObjR->create(array("stuOpenID"=>"$currentOpenID","coachOpenID"=>"$p1","levelRelationship"=>"一级学员","topUpMoney"=>"$fee1","orderID"=>"$orderid","percentMoney"=>$oneFee,));


            }

            $p2  = $currentObj->p2;
            $queryp2 = "where={\"openID\":\"{$p2}\"}";
            $resp2 = $bmobObj->get("",array($queryp2));
            $resp22 = $resp2->results;
            $objp2  = $resp22[0];
            $objidp2 = $objp2->objectId;
            $moneyp2 = $objp2->money;
            $newmoneyp2 = $moneyp2+$twoFee;
            $updatep2 = $bmobObj->update($objidp2,array("money"=>"$newmoneyp2"));

            if(strlen($p2)>10){

                //       $bmobObj = new BmobObject("WX_percentageRecord");
                $resR2 = $bmobObjR->create(array("stuOpenID"=>"$currentOpenID","coachOpenID"=>"$p2","levelRelationship"=>"二级学员","topUpMoney"=>"$fee1","orderID"=>"$orderid","percentMoney"=>$twoFee,));


            }

            $p3  = $currentObj->p3;
            $queryp3 = "where={\"openID\":\"{$p3}\"}";
            $resp3 = $bmobObj->get("",array($queryp3));
            $resp33 = $resp3->results;
            $objp3  = $resp33[0];
            $objidp3 = $objp3->objectId;
            $moneyp3 = $objp3->money;
            $newmoneyp3 = $moneyp3+$threeFee;
            $updatep3 = $bmobObj->update($objidp3,array("money"=>"$newmoneyp3"));


            if(strlen($p3)>10){

                //   $bmobObj = new BmobObject("WX_percentageRecord");
                $resR3 = $bmobObjR->create(array("stuOpenID"=>"$currentOpenID","coachOpenID"=>"$p3","levelRelationship"=>"三级学员","topUpMoney"=>"$fee1","orderID"=>"$orderid","percentMoney"=>$threeFee,));

            }

        } // bmob记录中未查询到本次回调的订单号


// 开通龙创交规 支付回调
    }else{

        //  $gxArr   =explode("-",$attach);
//   $gxAttach     = $gxArr[0];
        //  $gxMID =   $gxArr[1];
        //   $gxBmobObj = new BmobObject("ProxyPayrecord"):

//   $gxRes = $gxBmobObj->create(array("studentID"=>"$currentOpenID","class_count"=>"10","MasterID"=>"gxMID","orderID"=>"$orderid","chongzhiMoney"=>20,));
    }




} // 支付成功 success OK

