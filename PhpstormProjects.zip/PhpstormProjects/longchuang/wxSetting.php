<?php
/**
 * Created by PhpStorm.
 * User: pc
 * Date: 2018/1/22
 * Time: 08:34
 */
$verifyObj = new verifyClass();

$verifyObj->verifyFunction(); // 配置URL的方法  仅配置时走一次

$verifyObj->responseMsg();   // 回复订阅信息

//$verifyObj->customMenu();   // 自定义菜单
$verifyObj->menuBuild();

// 定义verify  class
class verifyClass {

    public function __construct()
    {

    }

    // 配置验证函数
    public function verifyFunction(){
        // 获取参数
        $nonce     = $_GET['nonce'];
        $signature = $_GET['signature'];
        $timestamp = $_GET['timestamp'];
        $token     = 'longchuangjiaogui';
        // 随机生成 需要在配置URL时返回完成验证
        $echostr   = $_GET['echostr'];
        // token timestamp nonce 字典序排序
        $tmpArr    = array($token,$timestamp,$nonce);
        sort($tmpArr,SORT_STRING);
        // 拼接 加密
        $tmpStr    = implode($tmpArr);
        $tmpStr    = sha1($tmpStr);

        // 验证
        if ($tmpStr == $signature && $echostr){// 验证通过

            echo $echostr;
            exit;
        }
        // else{//
        //this->responseMsg();
        //}

    } // verifyFunction end

    // 回复订阅信息

    public function responseMsg(){

        //关注/取消
        /*
         <xml>
        <ToUserName><![CDATA[toUser]]></ToUserName>
        <FromUserName><![CDATA[FromUser]]></FromUserName>
        <CreateTime>123456789</CreateTime>
        <MsgType><![CDATA[event]]></MsgType>
        <Event><![CDATA[subscribe]]></Event>
        </xml>
         */

        // 获取post消息内容
        $postContent = $GLOBALS['HTTP_RAW_POST_DATA'];
        // 解析
        $postObj     = simplexml_load_string($postContent);
        // 检查消息
        if (strtolower($postObj->MsgType) == 'event'){
            echo "event";

            if (strtolower($postObj->Event) == 'subscribe'){// 接收到订阅消息
                echo "subscribe";
                /* 恢复消息的xml 模板
                <xml>

            <ToUserName><![CDATA[toUser]]></ToUserName>

            <FromUserName><![CDATA[fromUser]]></FromUserName>

            <CreateTime>12345678</CreateTime>

            <MsgType><![CDATA[text]]></MsgType>

            <Content><![CDATA[你好]]></Content>

                </xml>
                 */
                // 构建恢复消息
                $toUserName   = $postObj->ToUserName;
                $fromUserName = $postObj->FromUserName;
                $cTime        = time();
                $msgType      = 'text';
                $content      = '欢迎关注Intco龙创交规123';

                $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
                $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
                echo $responseSubsxribe;


            }else{// unsubscribe 取消关注

                // 构建恢复消息
                $toUserName   = $postObj->ToUserName;
                $fromUserName = $postObj->FromUserName;
                $cTime        = time();
                $msgType      = 'text';
                $content      = "";

                $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
                $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
                echo $responseSubsxribe;
            }
        }else{
            //非推送事件！
            // 构建恢复消息
            $toUserName   = $postObj->ToUserName;
            $fromUserName = $postObj->FromUserName;
            $cTime        = time();
            $msgType      = 'text';
            $content      = "龙创交规";

            $xmlModal     = "<xml><ToUserName><![CDATA[%s]]></ToUserName><FromUserName><![CDATA[%s]]></FromUserName> <CreateTime>%s</CreateTime> <MsgType><![CDATA[%s]]></MsgType><Content><![CDATA[%s]]></Content></xml>
                ";
            $responseSubsxribe = printf($xmlModal,$fromUserName,$toUserName,$cTime,$msgType,$content);
            echo "";
        }


    }//responseMsg end

    //==================- 定义菜单 -=======================
    public function customMenu(){

        header('content-type:text/html;charset=utf-8');
        $accessToken = $this->getWXAccesstoken();
        $postURL     = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$accessToken;
        //构建菜单
        $postMenuArr =array(
            'button'=>array(
                array(
                    'name' => '菜单一',
                    'type'=>'click',
                    'key'  =>'1'
                ), // 第一个一级菜单
                array(
                    'name' => '单页评审',
                    'type' => 'view',
                    'url'  => 'http://1.intcowangwei.applinzi.com/medicalApprove/m_index.html'
                )
            )
        );// 菜单定义 end
        echo $postJson = urldecode(json_encode($postMenuArr));
        // curl 访问
        $a = $this->exeCurl($postURL,'post','json',$postJson);
        echo $a;


    } //customMenu end

    // ==================- 获取 access-token -=============
    public function getWXAccesstoken(){

        $appID = "wx62732b3c3460b3b1";
        $appSecret = 'cc05112ee2e8f53d80970d0d988398cd';
        $accessUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appID.'&secret='.$appSecret;

        $pageInfo  = file_get_contents($accessUrl);

        $infoObj   = json_decode($pageInfo);

        $accessToken = $infoObj->access_token;
        $expireIn    = $infoObj->expires_in;
        return $accessToken;
    }//getWXAccessToken end

    // ====================- 执行curl -=================
    public function exeCurl($url,$type,$res,$arr){

        //>1 初始化一个curl 对象
        $ch = curl_init();
        //>2 设置 CURL 的参数
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        if ($type=='post'){// post 的curl 参数配置
            curl_setopt($ch,CURLOPT_POST,1);
            curl_setopt($ch,CURLOPT_POSTFIELDS,$arr);
        }
        //>3 curl 执行
        $output = curl_exec($ch);
        //>4 关闭curl
        //   curl_close($ch);
        echo 'curl';
        echo $res;
        if ($res == 'json'){
            echo curl_errno($ch);
            if (curl_errno($ch)){
                return curl_error($ch);
            }else{
                return json_encode($output,true);
            }
        }

    }

    //------------------------------------------------------------------
    // 自定义菜单 *
    public function menuBuild(){

        echo 'ZDYCD';
        //  $appID     = 'wx87ea4fc3eb058752';
        //$appSecret = '0af3b68f9f1aad44bb1ad926c898e124';

        //$accessUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$appID.'&secret='.$appSecret;
        //$output    =$this->https_request($accessUrl);
        //$jsonInfo  = json_decode($output,true);
        //$accessToken = $jsonInfo["access_token"];
        $accessToken = $this->getWXAccesstoken();
        echo $accessToken;

        $jsonMenu = '{  
             "button":[  
             {    
                  "type":"view",  
                  "name":"免费试用题",  
                  "url":"http://www.baidu.com/"  
              },  
              {  
                   "type":"view",  
                   "name":"科一科四",  
                   "url":"http://www.baidu.com/"  
              },  
              {  
                  "type":"view",
                   "name":"分享",  
                   "url":"http://www.baidu.com/"
               }]  
         }';

        $createURL = 'https://api.weixin.qq.com/cgi-bin/menu/create?access_token='.$accessToken;
        $pageInfo1  = file_get_contents($createURL);
        echo '====';
        echo $pageInfo1;
        echo $accessToken;
        echo '-----';
        //         $result =$this->https_request($createURL,$jsonInfo);
        //var_dump($result);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$accessToken);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

        curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonMenu);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $tmpInfo = curl_exec($ch);
        if (curl_errno($ch)) {
            echo curl_error($ch);
        }

        curl_close($ch);

        echo $tmpInfo;

    }

    public function https_request($url, $data = null){

        $curl = curl_init();
        curl_setopt($curl,CURLOPT_URL,$url);
        curl_setopt($curl,CURLOPT_SSL_VERIFYPEER,0);
        curl_setopt($curl,CURLOPT_SSL_VERIFYHOST,0);
        if (!empty($data)){
            curl_setopt($curl,CURLOPT_POST,1);
            curl_setopt($curl,CURLOPT_POSTFIELDS,$data);
        }
        curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
}
?>