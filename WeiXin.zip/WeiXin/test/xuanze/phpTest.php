<?php

$a = '111111';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>龙创交规 带图片选择题</title>
    <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <script type="text/javascript" src="../bmob_jssdk/bmob-min.js"></script>
    <script type="text/javascript" src="../bmob_jssdk/bmob.js"></script>
</head>

<style>

    .nav {
        background: lightskyblue;
        padding: 10px 0 6px 0;
        width: 100%;
        position: fixed;
        left: 0;
        bottom: 0;
        /*z-index: 99;*/
    }
    .nav ul {
        height: 0;
    }
    .nav ul li {
        float: left;
        width: 20%;
        text-align: center;
        list-style-type: none;
        margin: 0;
        padding: 0;

    }
    .nav ul li span {
        display: block;
        color: black;
        font-size: 14px;
        /*font-family: "微软雅黑";*/
        line-height: 22px;
    }
    a {
        color: #000;
        text-decoration: none;
    }
    * {
        padding: 0;
        margin: 0;
        list-style: none;
        font-weight: normal;
    }
    .content{

        /*margin: 0 auto;*/
        bottom: 35px;

    }
    a:hover{text-decoration:underline;color:#227bd6;}
    .item{

        padding: 5px;
        width  : 100%;
        /*font-size: 16px;*/
    }
    .index{
        /*A B C D样式*/
        width: 23px;
        height: 23px;
        border-radius: 50%;
        border-width: 0.5px;
        border-style: solid;
        text-align: center;
        font-size: 15px;
        /*background: ;*/
    }
    #yy{
        color: orangered;
        font-size: 15px;
        font-weight: bold;
    }


</style>

<body onload="loadData()">

<div>
    <button onclick="submitAction()" style="width: 30%; height: 30px; background: lightskyblue; color: white; float: right;border-radius: 5px;border: wheat;margin-right: 3px;margin-top: 3px">交卷</button>
    <button id="time" style="width: 30%;height: 30px;color: white;background: lightskyblue;border: gainsboro; float: right;border-radius: 5px; margin-right: 5px;margin-top: 3px;" >考试计时</button>
</div>

<div class="content" style="width: 100%;height: auto;background-color: ghostwhite">

    <br>
    <!-- 隐藏横向滚动条  overflow-x: hidden  -->
    <div id="scrollContent" style="margin-top: 20px;width: 100%; position: relative;overflow: auto;overflow-x: hidden;overflow-y: inherit">
        <div style="padding-left: 5px;"><label id="qIndex">1</label>. <button id="wwtype" style="border-width: 1px;width: 50px;height: 20px;border-color: gray;border-style: solid;border-radius: 5px;padding: 2px;"> 选择题 </button><label id="question">夜间驾驶机动车通过人行横道时，需要交替使用远近光灯。</label> </div>
        <br>
        <br>
        <a><img id="mainPic" style="margin-left: 20%;width: 60%;" src="http://sucimg.itc.cn/sblog/j6wrf2Dr3Px"></a>
        <br>
        <div onclick="answerAction(this)" id="A" class="item"><button class="index" id="aItem">A</button><label id="aaa" > 对向可能有车辆驶来。</label></div>

        <div onclick="answerAction(this)" id="B" class="item"><button class="index" id="bItem">B</button><label id="bbb" > 前方骑自行车者可能由于上坡等原因突然改变方向。</label></div>

        <div onclick="answerAction(this)" id="C" class="item"><button class="index" id="cItem">C</button><label id="ccc" > 山区弯道可能转弯半径较小，车速过快容易引起车辆失控。 </label></div>

        <div onclick="answerAction(this)" id="D" class="item"><button class="index" id="dItem">D</button><label id="ddd" > 转完后路面可能存在落石、凹陷等特殊路况。</label></div>

    </div>
    <!--controls="controls"-->
    <audio id="tip">
        <source src="./test.mp3" type="audio/mp3">
    </audio>
    <audio id="ss">
        <source src="./jiaoAoDeShaoNian.mp3" type="audio/mp3" >
    </audio>

</div>
<!--底部导航栏-->
<div class="nav">
    <ul>

        <li onclick="previousAction()">
            <a href="#"><span><img src="../../imgs/pre.png" height="20"></span><span style="color: white;">上一题'<?php echo '000' ?>'</span></a>
        </li>
        <li style="position:relative;" onclick="createPrompt()">
            <a href="#"><span><img src="../../imgs/detail.png" height="20"></span><span id="testIndex" style="color: white;">1/100</span></a>
        </li>
        <li onclick="examDetaileAction()">
            <!--<audio src=".../imgs/jiao"></audio>-->

            <a href="#"><span><img src="../../imgs/yy.png" height="20"></span><span id="yy">技巧讲解</span></a>
        </li>
        <li onclick="helpTipsAction()">
            <a href="#"><span><img src="../../imgs/help.png" height="20"></span><span style="color: white;">帮助</span></a>
        </li>
        <li onclick="nextAction()">
            <a href="#"><span><img src="../../imgs/next.png" height="20"></span><span style="color: white;">下一题</span></a>
        </li>
    </ul>
</div>

<script type="text/javascript">

    // var sc = document.getElementById('scrollContent');
    // sc.style.height = "100%-50px";

    var isReload; // 是否刷新界面
    Bmob.initialize("4c2f5fe1bcd717a9232981343a8b8b8e","6a3852634b7483a097d837d49b847c0c");

    // 建立数组，记录答题的对错情况
    var myAnswers = [];
    // 页面加载的时候读取数据
    function loadData() {

        var WX_freeContent = Bmob.Object.extend("WX_freeContent");
        var query = new Bmob.Query(WX_freeContent);
        // 查询所有数据
        // 最大条数
        query.limit(1000);
        // 升序排列 wwID 数据库字段
        query.ascending('wwID');
        query.find({
            success: function(results) {
                //  alert("bmob");
                //   alert("共查询到 " + results.length + " 条记录");
                //   alert('创建成功');
                totalCount = results.length;
                var i;
                for (i = 0;i<results.length;i++){

                    var obj = results[i];
                    var j = i+1;
                    // 题干
                    localStorage.setItem('question'+j,obj.get('question'));
                    // 选项
                    localStorage.setItem('item'+j,obj.get('chooseItem'));
                    // 图片
                    localStorage.setItem('img'+j,obj.get('imgURL'));
                    // 是不是选择题
                    localStorage.setItem('isXuanZe'+j,obj.get('isXuanZe'));
                    // 答案
                    localStorage.setItem('answer'+j ,obj.get('answer'));
                    // 是否多选
                    localStorage.setItem('isDuoXuan'+j ,obj.get('isDuoXuan'));
                    // 答题提示
                    localStorage.setItem('tips'+j,obj.get('tips'));
                    // alert('img'+j);
                }

                nextAction();
                // 答题状态 0 未答  1 答对 2 打错
                // 初始值 全部赋值 0 未答
                for (var a=0;a<totalCount;a++){
                    myAnswers[a] = "0";

                }
                // 当前答道第几道题目
                var ti = document.getElementById('testIndex');
                ti.innerHTML = '1/'+totalCount;

                //  alert(myAnswers);
            },
            error: function(error) {
                //  alert("bmob");
                alert("查询失败: " + error.code + " " + error.message);
            }
        });

        // 设置答题区 frame
        // var content = document.getElementsByClassName('content');
        // var sh = document.body.offsetHeight;
        // alert(sh);
        // content.style.height = sh-35+'px';
        // alert('xxx');

        // 页面跳转信息
        var furl = location.href;
        var pStr = furl.split('?')[1];
        var ps1 = pStr.split('&')[0];
        var ps2 = pStr.split('&')[1];

        var p1 = ps1.split('=')[1];
        var p2 = ps2.split('=')[1];

        alert(p1+p2);

    }
</script>


</body>


<script>

    var index = 0;
    var  totalCount;
    var isNext;


    function goToPage() {
        window.location.href = 'noPic.html';
    }


    function changePic1() {
        var pic = document.getElementById('mainPic');
        // pic.src = 'http://5b0988e595225.cdn.sohucs.com/images/20180111/bef578dea7e44070b3b7b873cd9f83ae.jpeg';

        var freeStr = localStorage.getItem('free');
        var objs =  freeStr.toArray();
        pic.src   = objs.get('imagURL');
        alert('cccccc');
    }
    function changePic2() {

        var a = document.getElementById('tip');
        a.play();

        var pic = document.getElementById('mainPic');
        pic.src = 'http://5b0988e595225.cdn.sohucs.com/images/20180111/e30025124ee642acbb452534a9c82ea3.jpeg';
        //  pic.hidden = true;

    }
    var totalTime = 2700;
    // 计时器
    var timer = setInterval(function (){timerAction()} ,1000);
    // 1s 执行一次
    function timerAction() {
        totalTime --;
        var t = document.getElementById('time');
        if (totalTime<=0){

            t.innerHTML = '00 : 00';
            alert('时间到，考试结束');

            clearInterval(timer);
        }else {
            //var d = new Date();
            //var t = d.toLocaleDateString();
            var min = parseInt(totalTime/60);
            var sec = totalTime%60;
            min = min<10?('0'+min):min;
            sec = sec<10?('0'+sec):sec;
            t.innerHTML = min +' '+':'+' '+sec;
        }

    }
    // 本次考试详情
    function examDetaileAction() {

        //  alert('xxx');
        //  window.location.href = 'examDetail.html';
        // window.navigate("examDetail.html");
        window.location.href = '../examDetail.html';
        // window.open('./examDetail.html');
        // localStorage.setItem('seeDetail','1');
        // this -> createPrompt();


    }
    // 帮助
    function helpTipsAction() {
        var tip = localStorage.getItem('tips'+index);
        alert(tip);
    }

    //上一题
    function previousAction() {

        if (index>1){
            index--;
            //  alert(index);
            var ques = document.getElementById('question');
            ques.innerHTML = localStorage.getItem("question"+index);

            var qIndex = document.getElementById('qIndex');
            qIndex.innerHTML = index;

            var itemStr =   localStorage.getItem('item'+index);
            //   alert(itemStr);
            //  var items = new Array();
            var items = itemStr.split("#");
            document.getElementById('aaa').innerHTML =' : '+ items[0];
            document.getElementById('bbb').innerHTML =' : '+ items[1];
            document.getElementById('ccc').innerHTML =' : '+ items[2];
            document.getElementById('ddd').innerHTML =' : '+ items[3];

            var pic = document.getElementById('mainPic');
            var isXuan = localStorage.getItem('isXuanZe'+index);
            var cItem = document.getElementById('ccc');
            var dItem = document.getElementById('ddd');
            var t = document.getElementById('wwtype');
            // C D
            var C = document.getElementById('cItem');
            var D = document.getElementById('dItem');
            // 图片路径
            var imgurl = localStorage.getItem('img'+index);
            if (imgurl.length >3){

                pic.hidden = false;
                pic.src = imgurl;
            }else {
                pic.hidden = true;
            }
            // 判断题目类型
            if (isXuan === 'true'){

                // pic.hidden = false;

                cItem.hidden = false;
                dItem.hidden = false;
                C.hidden     = false;
                D.hidden     = false;

                t.innerHTML = '选择题';

            }else {

                //  pic.hidden = true;

                cItem.hidden = true;
                dItem.hidden = true;
                C.hidden     = true;
                D.hidden     = true;

                t.innerHTML = '判断题';
            }
            //    alert(localStorage.getItem("question"+index));
            // index --;
        }else {

            // index ++;
            alert('这是第一道题');
        }

        //恢复选项的状态
        var AD = document.getElementById('A');
        var BD = document.getElementById('B');
        var CD = document.getElementById('C');
        var DD = document.getElementById('D');
        var A = document.getElementById('aItem');
        var B = document.getElementById('bItem');
        AD.style.backgroundColor = 'ghostwhite';
        BD.style.backgroundColor = 'ghostwhite';
        CD.style.backgroundColor = 'ghostwhite';
        DD.style.backgroundColor = 'ghostwhite';

        A.style.color = 'black';
        A.style.backgroundColor = 'white';
        A.innerHTML = 'A';
        B.style.color = 'black';
        B.style.backgroundColor = 'white';
        B.innerHTML = 'B';
        C.style.color = 'black';
        C.style.backgroundColor = 'white';
        C.innerHTML = 'C';
        D.style.color = 'black';
        D.style.backgroundColor = 'white';
        D.innerHTML  = 'D';
        // 当前答道哪一题
        var ti = document.getElementById('testIndex');
        ti.innerHTML = index+'/'+totalCount;
    }
    // 下一题
    function nextAction() {
        // var s = document.getElementById('ss');
        //   s.play();
        //  var pic = document.getElementById('mainPic');
        //  pic.src = 'http://5b0988e595225.cdn.sohucs.com/images/20180111/7c9dd8972ee047c193131bf843b34ec1.jpeg';

        //
        if (index<totalCount){
            // alert(index);
            index ++;
            var ques = document.getElementById('question');
            ques.innerHTML = localStorage.getItem("question"+index);

            var qIndex = document.getElementById('qIndex');
            qIndex.innerHTML = index;

            var itemStr =   localStorage.getItem('item'+index);
            //   alert(itemStr);
            //  var items = new Array();
            var items = itemStr.split("#");
            document.getElementById('aaa').innerHTML =' : '+ items[0];
            document.getElementById('bbb').innerHTML =' : '+ items[1];
            document.getElementById('ccc').innerHTML =' : '+ items[2];
            document.getElementById('ddd').innerHTML =' : '+ items[3];

            var pic = document.getElementById('mainPic');
            var isXuan = localStorage.getItem('isXuanZe'+index);
            var cItem = document.getElementById('ccc');
            var dItem = document.getElementById('ddd');
            var t = document.getElementById('wwtype');
            // C D
            var C = document.getElementById('cItem');
            var D = document.getElementById('dItem');

            //图片地址
            var imgurl = localStorage.getItem('img'+index);
            //  alert(imgurl);
            if (imgurl.length >3){

                pic.hidden = false;
                pic.src = imgurl;
                //  alert("图片显示"+imgurl);
            }else {
                pic.hidden = true;
            }

            // 判断题目类型
            if (isXuan === 'true'){

                // pic.hidden = false;

                cItem.hidden = false;
                dItem.hidden = false;
                C.hidden     = false;
                D.hidden     = false;

                t.innerHTML = '选择题';

            }else {

                // pic.hidden = true;

                cItem.hidden = true;
                dItem.hidden = true;
                C.hidden     = true;
                D.hidden     = true;

                t.innerHTML = '判断题';
            }
            //    alert(localStorage.getItem("question"+index));


        }else {
            // index --;
            alert('这是最后一道题了');
        }
        //恢复选项的状态
        var AD = document.getElementById('A');
        var BD = document.getElementById('B');
        var CD = document.getElementById('C');
        var DD = document.getElementById('D');
        var A = document.getElementById('aItem');
        var B = document.getElementById('bItem');
        AD.style.backgroundColor = 'ghostwhite';
        BD.style.backgroundColor = 'ghostwhite';
        CD.style.backgroundColor = 'ghostwhite';
        DD.style.backgroundColor = 'ghostwhite';

        A.style.color = 'black';
        A.style.backgroundColor = 'white';
        A.innerHTML = 'A';
        B.style.color = 'black';
        B.style.backgroundColor = 'white';
        B.innerHTML = 'B';
        C.style.color = 'black';
        C.style.backgroundColor = 'white';
        C.innerHTML = 'C';
        D.style.color = 'black';
        D.style.backgroundColor = 'white';
        D.innerHTML  = 'D';
        // 当前答道哪一题
        var ti = document.getElementById('testIndex');
        ti.innerHTML = index+'/'+totalCount;

    }


    // 选中答案
    function answerAction(sItem) {
        // 1.判断选项对错  2.对、错选项显示

        var aI = document.getElementById('aaa');
        var bI = document.getElementById('bbb');
        var cI = document.getElementById('ccc');
        var dI = document.getElementById('ddd');

        sItem.style.backgroundColor = 'lightskyblue';

        var A = document.getElementById('aItem');
        var B = document.getElementById('bItem');
        var C = document.getElementById('cItem');
        var D = document.getElementById('dItem');

        var picked = sItem.getAttribute('id');
        var ans = localStorage.getItem('answer'+index);
        switch(picked)
        {
            case 'A':
                // alert('a');
                if (picked === ans){

                    A.innerHTML = '√';
                    A.style.color = 'white';
                    A.style.backgroundColor = 'green';
                    myAnswers[index-1] = 1;
                }else {

                    A.innerHTML = 'X';
                    A.style.color = 'white';
                    A.style.backgroundColor = 'red';
                    myAnswers[index-1] = 2;
                }


                break;
            case 'B':
                //  alert('b');
                if (picked === ans){

                    B.innerHTML = '√';
                    B.style.color = 'white';
                    B.style.backgroundColor = 'green';
                    myAnswers[index-1] = 1;
                }else {

                    B.innerHTML = 'X';
                    B.style.color = 'white';
                    B.style.backgroundColor = 'red';
                    myAnswers[index-1] = 2;
                }

                break;
            case 'C':
                //  alert('c');
                if (picked === ans){
                    C.innerHTML = '√';
                    C.style.color = 'white';
                    C.style.backgroundColor = 'green';
                    myAnswers[index-1] = 1;

                }else {
                    C.innerHTML = 'X';
                    C.style.color = 'white';
                    C.style.backgroundColor = 'red';
                    myAnswers[index-1] = 2;
                }

                break;
            case 'D':
                //  alert('d');
                if (picked === ans){

                    D.innerHTML = '√';
                    D.style.color = 'white';
                    D.style.backgroundColor = 'green';
                    myAnswers[index-1] = 1;

                }else {

                    D.innerHTML = 'X';
                    D.style.color = 'white';
                    D.style.backgroundColor = 'red';
                    myAnswers[index-1] = 2;
                }

                break;
            default:
        }

        switch(ans)
        {
            case 'A':
                // alert('a');
                A.innerHTML = '√';
                A.style.color = 'white';
                A.style.backgroundColor = 'green';

                break;
            case 'B':
                //  alert('b');
                B.innerHTML = '√';
                B.style.color = 'white';
                B.style.backgroundColor = 'green';

                break;
            case 'C':
                //  alert('c');
                C.innerHTML = '√';
                C.style.color = 'white';
                C.style.backgroundColor = 'green';

                break;
            case 'D':
                //  alert('d');
                D.innerHTML = '√';
                D.style.color = 'white';
                D.style.backgroundColor = 'green';

                break;
            default:
        }
    }
    // 交卷
    function submitAction() {
        alert('交卷');
    }

    // 自定义弹窗
    function createPrompt()
    {
        //  var divSp = document.createElement("div");    //弹出对话框
        //  var newMask = document.createElement("div");  //遮罩层，用来屏蔽灰掉背部界面
        // // var btnSub = document.createElement("input"); // 弹出对话框中按钮
        //  var inner;

        var mask = document.createElement('div');
        mask.id = "mask";
        mask.style.backgroundColor = 'lightblue';
        mask.style.width = "100%";
        mask.style.height = "100%";
        mask.style.position = "absolute";
        mask.style.top  = "0px";
        mask.style.left = "0px";
        document.body.appendChild(mask);

        var iframe = document.createElement('iframe');iframe.style.position = "absolute";
        iframe.style.height = "60%";
        iframe.style.width  = "90%";
        iframe.style.backgroundColor = "lightblue";
        iframe.style.top = "5%";
        iframe.style.left = "5%";
        iframe.style.border = "white";
        //iframe.href('../examDetail.html');
        iframe.src=("../examDetail.html?count="+totalCount);
        mask.appendChild(iframe);
        localStorage.setItem('myAnswers',myAnswers);

        var  btn = document.createElement('button');
        btn.style.position = "absolute";
        btn.style.width = "40%";
        btn.style.height = "36px";
        btn.innerHTML = "返回考试";
        btn.style.color = "black";
        btn.style.border = "white";
        btn.style.fontSize = "15px";
        btn.style.top = "72%";
        btn.style.left = "30%";
        btn.style.backgroundColor = "white";
        btn.addEventListener("click",removeAlert);
        mask.appendChild(btn);

        // alert('createPromotexxx');

    }
    // 移除弹窗（考试详情）
    function removeAlert() {

        var mask = document.getElementById('mask');

        document.body.removeChild(mask);
    }



</script>



</html>